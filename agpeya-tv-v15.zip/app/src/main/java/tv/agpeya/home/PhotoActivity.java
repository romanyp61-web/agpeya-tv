package tv.agpeya.home;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.util.List;

/**
 * Photos and videos sent from the phone. Right/Left = previous/next, OK = play or pause the slideshow,
 * Down (twice) = delete this one.
 */
public class PhotoActivity extends Activity {
    static final String EXTRA_LAST = "last";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ImageView image;
    private VideoView video;
    private TextView info, empty;
    private List<File> files;
    private int idx;
    private boolean auto = true, armDelete, videoShown;
    private Bitmap current;

    private final Runnable slide = new Runnable() {
        @Override
        public void run() {
            if (auto && files.size() > 1 && !videoShown) step(1);
            handler.postDelayed(this, 8000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Phone.start(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(image, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        video = new VideoView(this);
        video.setVisibility(View.GONE);
        root.addView(video, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH, Gravity.CENTER));
        info = Ui.text(this, "", 24, Ui.CREAM, Ui.alexBold(this));
        info.setGravity(Gravity.CENTER);
        info.setBackgroundColor(0x99000000);
        info.setPadding(Ui.px(this, 20), Ui.px(this, 8), Ui.px(this, 20), Ui.px(this, 8));
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        ip.bottomMargin = Ui.px(this, 24);
        root.addView(info, ip);
        empty = Ui.text(this, "لسه مفيش صور أو فيديوهات.\nافتح صفحة التليفون وابعت من هناك.", 44, Ui.CREAM, Ui.alexBold(this));
        empty.setGravity(Gravity.CENTER);
        root.addView(empty, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH, Gravity.CENTER));
        setContentView(root);
        files = Phone.files(this);
        idx = files.size() - 1;
        showCurrent();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Phone.inboxListener = () -> {
            files = Phone.files(this);
            idx = files.size() - 1;
            showCurrent();
        };
        handler.removeCallbacks(slide);
        handler.postDelayed(slide, 8000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Phone.inboxListener = null;
        handler.removeCallbacks(slide);
        if (video.isPlaying()) video.pause();
    }

    private void step(int d) {
        if (files.isEmpty()) return;
        idx = (idx + d + files.size()) % files.size();
        showCurrent();
    }

    private void showCurrent() {
        armDelete = false;
        video.stopPlayback();
        if (files.isEmpty()) {
            image.setImageDrawable(null);
            video.setVisibility(View.GONE);
            videoShown = false;
            empty.setVisibility(View.VISIBLE);
            info.setVisibility(View.GONE);
            return;
        }
        empty.setVisibility(View.GONE);
        info.setVisibility(View.VISIBLE);
        File f = files.get(Math.max(0, Math.min(idx, files.size() - 1)));
        if (Phone.isVideo(f)) {
            videoShown = true;
            image.setImageDrawable(null);
            video.setVisibility(View.VISIBLE);
            video.setOnCompletionListener(mp -> {
                if (auto && files.size() > 1) step(1);
            });
            video.setOnErrorListener((mp, what, extra) -> {
                Toast.makeText(this, "تعذّر تشغيل هذا الفيديو على التليفزيون", Toast.LENGTH_LONG).show();
                return true;
            });
            video.setVideoURI(Uri.fromFile(f));
            video.start();
        } else {
            videoShown = false;
            video.setVisibility(View.GONE);
            Bitmap bm = decode(f);
            image.setImageBitmap(bm);
            if (current != null && current != bm) current.recycle();
            current = bm;
            if (bm == null) Toast.makeText(this, "تعذّر فتح هذه الصورة", Toast.LENGTH_SHORT).show();
        }
        info.setText(Coptic.ar(idx + 1) + " / " + Coptic.ar(files.size()) + "  ·  OK: "
                + (videoShown ? "تشغيل/إيقاف الفيديو" : (auto ? "إيقاف العرض التلقائي" : "تشغيل العرض التلقائي"))
                + "  ·  ◄ ► للتنقل  ·  ▼ حذف");
    }

    private Bitmap decode(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int s = 1;
            while (o.outWidth / s > 2400 || o.outHeight / s > 1400) s *= 2;
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = s;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), d);
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent ev) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                step(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                step(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (videoShown) {
                    if (video.isPlaying()) video.pause(); else video.start();
                } else {
                    auto = !auto;
                    showCurrent();
                }
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (files.isEmpty()) return true;
                if (!armDelete) {
                    armDelete = true;
                    Toast.makeText(this, "اضغط ▼ مرة تانية لحذفها", Toast.LENGTH_SHORT).show();
                } else {
                    File f = files.get(idx);
                    f.delete();
                    files = Phone.files(this);
                    idx = Math.min(idx, files.size() - 1);
                    showCurrent();
                }
                return true;
            default:
                return super.onKeyDown(code, ev);
        }
    }
}
