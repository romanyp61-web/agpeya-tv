package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Shows the address and code to type on the phone, and opens the gallery of what the phone sent. */
public class PhoneActivity extends Activity {
    private TextView pinView;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Phone.start(this);
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));
        View dim = new View(c);
        dim.setBackgroundColor(0x80000000);
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        FrameLayout stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);
        setContentView(root);

        stage.addView(Ui.box(c, "التحكم من التليفون", 64, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), Ui.at(c, 1000, 40, 850, 90));
        View card = new View(c);
        card.setBackground(Ui.rect(c, Ui.glass(0xD9), 0x59D4AF6A, 1.5f, 28));
        stage.addView(card, Ui.at(c, 200, 170, 1520, 640));

        String ip = Phone.ip();
        int port = Phone.port();
        stage.addView(Ui.box(c, "١) وصّل تليفونك بنفس شبكة الواي فاي بتاعة التليفزيون", 34, Ui.CREAM, Ui.alexBold(c), Ui.GR, 1),
                Ui.at(c, 260, 200, 1400, 60));
        stage.addView(Ui.box(c, "٢) افتح المتصفح في التليفون واكتب العنوان ده:", 34, Ui.CREAM, Ui.alexBold(c), Ui.GR, 1),
                Ui.at(c, 260, 275, 1400, 60));
        String addr = ip == null || port == 0 ? "التليفزيون غير متصل بشبكة" : "http://" + ip + ":" + port;
        TextView a = Ui.box(c, addr, 64, Ui.GOLD, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
        a.setTextDirection(View.TEXT_DIRECTION_LTR);
        stage.addView(a, Ui.at(c, 260, 345, 1400, 90));
        stage.addView(Ui.box(c, "٣) اكتب الرقم السري ده في الصفحة:", 34, Ui.CREAM, Ui.alexBold(c), Ui.GR, 1),
                Ui.at(c, 260, 470, 1400, 60));
        pinView = Ui.box(c, Phone.pin(c), 80, Ui.GOLD, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
        pinView.setTextDirection(View.TEXT_DIRECTION_LTR);
        stage.addView(pinView, Ui.at(c, 260, 535, 1400, 110));
        stage.addView(Ui.box(c, "من الصفحة تقدر تبعت صور وفيديوهات وروابط وتستخدم الريموت جوه أجبية TV.", 28, Ui.MUTED,
                Ui.alex(c), Ui.GR, 2), Ui.at(c, 260, 665, 1400, 100));

        TextView gallery = button("معرض الصور والفيديوهات", 420);
        gallery.setOnClickListener(v -> startActivity(new Intent(c, PhotoActivity.class)));
        stage.addView(gallery, Ui.at(c, 1300, 860, 420, 70));
        TextView renew = button("تغيير الرقم السري", 340);
        renew.setOnClickListener(v -> pinView.setText(Phone.newPin(c)));
        stage.addView(renew, Ui.at(c, 940, 860, 340, 70));
        TextView back = button("رجوع", 200);
        back.setOnClickListener(v -> finish());
        stage.addView(back, Ui.at(c, 200, 860, 200, 70));
        gallery.post(gallery::requestFocus);
    }

    private TextView button(String label, float w) {
        TextView t = Ui.text(this, label, 28, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.FOCUS, Ui.GOLD, 4, 35));
        bg.addState(new int[]{}, Ui.rect(this, Ui.glass(0xB8), Ui.GOLD, 1.5f, 35));
        Ui.button(t, bg);
        return t;
    }
}
