package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.Locale;

/** Dollar and gold in a bit more detail, with the credit the free price service asks for. */
public class PricesActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));
        View dim = new View(c);
        dim.setBackgroundColor(0x80000000);
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        FrameLayout stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);
        setContentView(root);

        stage.addView(Ui.box(c, "الدولار والذهب", 64, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), Ui.at(c, 1000, 40, 850, 90));
        TextView back = Ui.text(c, "رجوع", 24, Ui.CREAM, Ui.alexBold(c));
        back.setGravity(Gravity.CENTER);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, Ui.FOCUS, Ui.GOLD, 4, 29));
        bg.addState(new int[]{}, Ui.rect(c, Ui.glass(0xB8), Ui.GOLD, 1.5f, 29));
        Ui.button(back, bg);
        back.setOnClickListener(v -> finish());
        stage.addView(back, Ui.at(c, 70, 50, 150, 58));
        back.post(back::requestFocus);

        View card = new View(c);
        card.setBackground(Ui.rect(c, Ui.glass(0xD9), 0x59D4AF6A, 1.5f, 28));
        stage.addView(card, Ui.at(c, 260, 170, 1400, 720));

        double[] v = Prices.cached(c);
        String[] rows;
        if (v == null) {
            rows = new String[]{"لا توجد أسعار حديثة. تأكد أن التليفزيون متصل بالإنترنت."};
        } else {
            long g24 = Prices.gram(v, 24), g21 = Prices.gram(v, 21), g18 = Prices.gram(v, 18);
            rows = new String[]{
                    "الدولار: " + Coptic.ar(String.format(Locale.US, "%.2f", v[0])) + " جنيه",
                    g24 > 0 ? "جرام الذهب عيار ٢٤: " + Coptic.ar(g24) + " جنيه" : "الذهب غير متاح الآن",
                    g24 > 0 ? "جرام الذهب عيار ٢١: " + Coptic.ar(g21) + " جنيه" : "",
                    g24 > 0 ? "جرام الذهب عيار ١٨: " + Coptic.ar(g18) + " جنيه" : "",
                    v[1] > 0 ? "أوقية الذهب: " + Coptic.ar(String.format(Locale.US, "%.0f", v[1])) + " دولار" : ""};
        }
        float y = 210;
        for (String r : rows) {
            if (r.isEmpty()) continue;
            stage.addView(Ui.box(c, r, 54, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 1), Ui.at(c, 320, y, 1280, 90));
            y += 100;
        }
        stage.addView(Ui.box(c, "الأسعار عالمية وتقريبية، وسعر الصاغة في مصر بيختلف عنها شوية (مصنعية وضرايب).", 26,
                Ui.MUTED, Ui.alex(c), Ui.GR, 2), Ui.at(c, 320, 730, 1280, 70));
        stage.addView(Ui.box(c, "Rates By Exchange Rate API (exchangerate-api.com) · Gold: xaus.com", 20,
                Ui.MUTED, Ui.alex(c), Ui.GC, 1), Ui.at(c, 320, 820, 1280, 40));
    }
}
