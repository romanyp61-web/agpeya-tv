package tv.agpeya.home;

import android.app.Activity;
import android.app.Application;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * A tiny web server inside the app, so the phone's browser (same Wi-Fi) can act as a remote, send a link or text to
 * the TV, and send photos and videos. Every request needs the 4-digit code shown on the TV.
 */
final class Phone {
    private Phone() {}

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final long MAX_UPLOAD = 400L * 1024 * 1024;
    private static final String[] EXT = {"jpg", "jpeg", "png", "webp", "gif", "mp4", "mkv", "mov", "webm", "3gp"};

    private static ServerSocket server;
    private static volatile int port;
    private static Context app;
    private static volatile Activity top;
    private static boolean callbacksSet;
    private static volatile int fails;

    /** Called on the main thread when a new photo or video has arrived. */
    static volatile Runnable inboxListener;

    static int port() {
        return port;
    }

    static synchronized void start(Context c) {
        app = c.getApplicationContext();
        if (!callbacksSet) {
            callbacksSet = true;
            ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityCreated(Activity a, Bundle b) { }
                @Override public void onActivityStarted(Activity a) { }
                @Override public void onActivityResumed(Activity a) { top = a; }
                @Override public void onActivityPaused(Activity a) { if (top == a) top = null; }
                @Override public void onActivityStopped(Activity a) { }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                @Override public void onActivityDestroyed(Activity a) { }
            });
        }
        if (server != null && !server.isClosed()) return;
        server = null;
        for (int p = 8765; p <= 8775; p++) {
            try {
                server = new ServerSocket(p);
                port = p;
                break;
            } catch (Exception ignored) {
                server = null;
            }
        }
        if (server == null) return;
        final ServerSocket ss = server;
        Thread t = new Thread(() -> {
            while (!ss.isClosed()) {
                try {
                    final Socket s = ss.accept();
                    new Thread(() -> handle(s)).start();
                } catch (Exception e) {
                    return;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    // ------------------------------------------------------------ code and address

    static String pin(Context c) {
        android.content.SharedPreferences p = c.getApplicationContext().getSharedPreferences("agpeya", Context.MODE_PRIVATE);
        String pin = p.getString("phone_pin", "");
        if (pin.length() != 4) pin = newPin(c);
        return pin;
    }

    static String newPin(Context c) {
        String pin = String.format(Locale.US, "%04d", new SecureRandom().nextInt(10000));
        c.getApplicationContext().getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putString("phone_pin", pin).apply();
        return pin;
    }

    /** The TV's address on the home network, or null when it is not connected. */
    static String ip() {
        try {
            Enumeration<NetworkInterface> ifs = NetworkInterface.getNetworkInterfaces();
            while (ifs.hasMoreElements()) {
                NetworkInterface ni = ifs.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> as = ni.getInetAddresses();
                while (as.hasMoreElements()) {
                    InetAddress a = as.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {
            // no address
        }
        return null;
    }

    // ------------------------------------------------------------ files that arrived

    static File inbox(Context c) {
        File d = new File(c.getApplicationContext().getFilesDir(), "inbox");
        d.mkdirs();
        return d;
    }

    /** Oldest first. */
    static List<File> files(Context c) {
        File[] fs = inbox(c).listFiles();
        List<File> out = new ArrayList<>();
        if (fs != null) {
            Arrays.sort(fs, (a, b) -> a.getName().compareTo(b.getName()));
            Collections.addAll(out, fs);
        }
        return out;
    }

    static boolean isVideo(File f) {
        String n = f.getName().toLowerCase(Locale.US);
        return n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".mov") || n.endsWith(".webm") || n.endsWith(".3gp");
    }

    // ------------------------------------------------------------ requests

    private static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int ch;
        while ((ch = in.read()) != -1) {
            if (ch == '\n') break;
            if (ch != '\r') sb.append((char) ch);
            if (sb.length() > 8192) throw new Exception("long");
        }
        return ch == -1 && sb.length() == 0 ? null : sb.toString();
    }

    private static void reply(OutputStream out, int code, String type, byte[] body) throws Exception {
        String head = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Error") + "\r\nContent-Type: " + type
                + "\r\nContent-Length: " + body.length + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        out.write(head.getBytes("UTF-8"));
        out.write(body);
        out.flush();
    }

    private static void json(OutputStream out, int code, String body) throws Exception {
        reply(out, code, "application/json; charset=utf-8", body.getBytes("UTF-8"));
    }

    private static Map<String, String> query(String q) {
        Map<String, String> m = new HashMap<>();
        for (String kv : q.split("&")) {
            int i = kv.indexOf('=');
            if (i <= 0) continue;
            try {
                m.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
            } catch (Exception ignored) {
                // skip
            }
        }
        return m;
    }

    private static String bodyText(InputStream in, long len) throws Exception {
        if (len <= 0 || len > 8192) return "";
        byte[] b = new byte[(int) len];
        int got = 0;
        while (got < b.length) {
            int n = in.read(b, got, b.length - got);
            if (n < 0) break;
            got += n;
        }
        return new String(b, 0, got, "UTF-8").trim();
    }

    private static void handle(Socket s) {
        try {
            s.setSoTimeout(60000);
            BufferedInputStream in = new BufferedInputStream(s.getInputStream(), 65536);
            OutputStream out = s.getOutputStream();
            String line = readLine(in);
            if (line == null) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String method = parts[0], target = parts[1];
            Map<String, String> h = new HashMap<>();
            String l;
            while ((l = readLine(in)) != null && !l.isEmpty()) {
                int i = l.indexOf(':');
                if (i > 0) h.put(l.substring(0, i).trim().toLowerCase(Locale.US), l.substring(i + 1).trim());
            }
            String path = target, q = "";
            int qi = target.indexOf('?');
            if (qi >= 0) {
                path = target.substring(0, qi);
                q = target.substring(qi + 1);
            }
            long len = 0;
            try {
                len = Long.parseLong(h.get("content-length"));
            } catch (Exception ignored) {
                // none
            }

            if (method.equals("GET") && (path.equals("/") || path.equals("/index.html"))) {
                InputStream a = app.getAssets().open("phone.html");
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = a.read(buf)) > 0) bo.write(buf, 0, n);
                a.close();
                reply(out, 200, "text/html; charset=utf-8", bo.toByteArray());
                return;
            }
            if (!path.startsWith("/api/")) {
                json(out, 404, "{\"ok\":false}");
                return;
            }
            if (!pin(app).equals(h.get("x-pin"))) {
                int f = ++fails;
                try {
                    Thread.sleep(Math.min(3000, f * 300L));
                } catch (InterruptedException ignored) {
                    // go on
                }
                json(out, 401, "{\"ok\":false,\"why\":\"pin\"}");
                return;
            }
            fails = 0;
            Map<String, String> qs = query(q);

            switch (path) {
                case "/api/ping":
                    json(out, 200, "{\"ok\":true}");
                    break;
                case "/api/key": {
                    boolean front = top != null;
                    if (front) key(qs.get("c"));
                    else if ("home".equals(qs.get("c"))) goHome();
                    json(out, 200, "{\"ok\":" + (front || "home".equals(qs.get("c"))) + "}");
                    break;
                }
                case "/api/open": {
                    String text = bodyText(in, len);
                    if (text.isEmpty()) {
                        json(out, 200, "{\"ok\":false}");
                        break;
                    }
                    open(qs.get("t"), text);
                    json(out, 200, "{\"ok\":true}");
                    break;
                }
                case "/api/clip": {
                    String text = bodyText(in, len);
                    if (text.isEmpty()) {
                        json(out, 200, "{\"ok\":false}");
                        break;
                    }
                    clip(text);
                    json(out, 200, "{\"ok\":true}");
                    break;
                }
                case "/api/upload": {
                    String name = qs.get("name") == null ? "" : qs.get("name").toLowerCase(Locale.US);
                    String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : "";
                    if (!Arrays.asList(EXT).contains(ext) || len <= 0 || len > MAX_UPLOAD) {
                        json(out, 200, "{\"ok\":false,\"why\":\"type\"}");
                        break;
                    }
                    File f = new File(inbox(app), String.format(Locale.US, "%013d.%s", System.currentTimeMillis(), ext));
                    long got = 0;
                    try (FileOutputStream fo = new FileOutputStream(f)) {
                        byte[] buf = new byte[65536];
                        while (got < len) {
                            int n = in.read(buf, 0, (int) Math.min(buf.length, len - got));
                            if (n < 0) break;
                            fo.write(buf, 0, n);
                            got += n;
                        }
                    }
                    if (got != len) {
                        f.delete();
                        json(out, 200, "{\"ok\":false,\"why\":\"cut\"}");
                        break;
                    }
                    arrived();
                    json(out, 200, "{\"ok\":true}");
                    break;
                }
                default:
                    json(out, 404, "{\"ok\":false}");
            }
        } catch (Exception ignored) {
            // a dropped connection: nothing to do
        } finally {
            try {
                s.close();
            } catch (Exception ignored) {
                // closed
            }
        }
    }

    // ------------------------------------------------------------ actions on the TV

    private static void key(final String code) {
        MAIN.post(() -> {
            Activity a = top;
            if (a == null || code == null) return;
            if (code.equals("back")) {
                a.onBackPressed();
                return;
            }
            if (code.equals("home")) {
                goHome();
                return;
            }
            int k;
            switch (code) {
                case "up": k = KeyEvent.KEYCODE_DPAD_UP; break;
                case "down": k = KeyEvent.KEYCODE_DPAD_DOWN; break;
                case "left": k = KeyEvent.KEYCODE_DPAD_LEFT; break;
                case "right": k = KeyEvent.KEYCODE_DPAD_RIGHT; break;
                case "ok": k = KeyEvent.KEYCODE_DPAD_CENTER; break;
                default: return;
            }
            a.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, k));
            a.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, k));
        });
    }

    private static void goHome() {
        MAIN.post(() -> {
            try {
                app.startActivity(new Intent(app, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
            } catch (Exception ignored) {
                // some TVs do not allow this from the background
            }
        });
    }

    private static void open(final String type, final String text) {
        MAIN.post(() -> {
            try {
                if ("url".equals(type)) {
                    String u = text.startsWith("http://") || text.startsWith("https://") ? text : "https://" + text;
                    app.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } else {
                    Media.search(app, text);
                }
            } catch (Exception e) {
                Toast.makeText(app, "تعذّر فتح الرابط", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static void clip(final String text) {
        MAIN.post(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("phone", text));
                Toast.makeText(app, "وصل نص من التليفون وتم نسخه", Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {
                // no clipboard
            }
        });
    }

    private static void arrived() {
        MAIN.post(() -> {
            Runnable r = inboxListener;
            if (r != null) {
                r.run();
                return;
            }
            try {
                Intent i = new Intent(app, PhotoActivity.class).putExtra(PhotoActivity.EXTRA_LAST, true);
                Activity a = top;
                if (a != null) a.startActivity(i);
                else app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {
                Toast.makeText(app, "وصلت صورة. افتح المعرض من «التحكم من التليفون»", Toast.LENGTH_LONG).show();
            }
        });
    }
}
