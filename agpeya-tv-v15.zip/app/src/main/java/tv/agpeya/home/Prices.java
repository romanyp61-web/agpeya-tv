package tv.agpeya.home;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/**
 * Dollar rate (open.er-api.com) and the world gold price (xaus.com), turned into an approximate Egyptian price.
 * These are world prices, so the local jeweller's price differs a little (workmanship, tax).
 */
final class Prices {
    private Prices() {}

    private static final long FRESH_MS = 12L * 3600 * 1000;
    private static volatile boolean busy;
    private static volatile long lastTry;

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("agpeya", Context.MODE_PRIVATE);
    }

    /** {EGP per dollar, gold dollars per ounce (0 when unknown)} or null when nothing fresh is saved. */
    static double[] cached(Context c) {
        SharedPreferences p = prefs(c);
        long at = p.getLong("pr_at", 0);
        if (at == 0 || System.currentTimeMillis() - at > FRESH_MS) return null;
        try {
            double usd = Double.parseDouble(p.getString("pr_usd", "0"));
            double xau = Double.parseDouble(p.getString("pr_xau", "0"));
            return usd > 0 ? new double[]{usd, xau} : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** Gold price for one gram of the given karat (24, 21, 18) in pounds, or 0 when unknown. */
    static long gram(double[] v, int karat) {
        if (v == null || v[1] <= 0) return 0;
        return Math.round(v[1] / 31.1035 * v[0] * karat / 24.0);
    }

    static String chip(double[] v) {
        String s = "دولار " + Coptic.ar(String.format(Locale.US, "%.2f", v[0]));
        long g = gram(v, 21);
        if (g > 0) s += "  ·  ذهب ٢١: " + Coptic.ar(g);
        return s;
    }

    static void refresh(Context c, final Runnable onDone) {
        final Context app = c.getApplicationContext();
        long now = System.currentTimeMillis();
        if (busy || now - lastTry < 10L * 60 * 1000) return;
        if (now - prefs(app).getLong("pr_at", 0) < 60L * 60 * 1000) return;
        busy = true;
        lastTry = now;
        new Thread(() -> {
            try {
                double usd = new JSONObject(get("https://open.er-api.com/v6/latest/USD"))
                        .getJSONObject("rates").getDouble("EGP");
                double xau = 0;
                try {
                    JSONObject g = new JSONObject(get("https://xaus.com/api/v1/spot"));
                    xau = g.optDouble("spot_usd_oz", 0);
                    if (!(xau > 0) && g.optJSONObject("xau") != null) xau = g.getJSONObject("xau").optDouble("price", 0);
                } catch (Exception ignored) {
                    // the gold price is optional
                }
                SharedPreferences p = prefs(app);
                if (!(xau > 0)) {
                    try {
                        xau = Double.parseDouble(p.getString("pr_xau", "0"));
                    } catch (Exception ignored) {
                        xau = 0;
                    }
                }
                if (usd > 0) {
                    p.edit().putString("pr_usd", String.valueOf(usd)).putString("pr_xau", String.valueOf(xau))
                            .putLong("pr_at", System.currentTimeMillis()).apply();
                }
            } catch (Exception ignored) {
                // offline: the chip keeps the last values, or hides when they are too old
            }
            busy = false;
            if (onDone != null) new android.os.Handler(android.os.Looper.getMainLooper()).post(onDone);
        }).start();
    }

    private static String get(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("User-Agent", "AgpeyaTV/3.2");
        try {
            if (conn.getResponseCode() != 200) throw new Exception("http");
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } finally {
            conn.disconnect();
        }
    }
}
