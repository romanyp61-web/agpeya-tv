package tv.agpeya.home;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * The home screen, laid out on a fixed 1920x1080 stage (scaled to the TV, always fully visible), in the glass style:
 * the photo full screen, clock and date, two glass panels (next prayer, verse of the day), the shortcuts strip,
 * and the favourite apps strip.
 */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout stage;
    private TextView clock, ampm, copticLine, gregLine, fastLine, kicker, banner;
    private TextView nextLabel, nextName, nextCount, nextSub;
    private View nextCard;
    private Widgets.Ring ring;
    private Widgets.StatusIcon wifiIcon, btIcon;
    private Widgets.WxGlyph wxGlyph;
    private TextView wxText;
    private View wxChip;
    private TextView pricesChip;
    private TextView psalmText, psalmRef, verseText, verseRef;
    private TextView planDay, planRead, planStreak, planDone;
    private Widgets.Bar planBar;
    private View quietShade;
    private final List<View> dock = new ArrayList<>();
    private View firstFocus;
    private FrameLayout rootView;
    private StateListDrawable nextNormal, nextGlow;
    private Dots dots;
    private String shownClock = "";
    private int lastDockIdx = -1;

    private float builtScale;
    private int builtTheme;
    private boolean builtPhoto;
    private String shownDay = "";
    private int lastChime = -1;
    private int openHour = 0;
    private int lastSec = -1;
    private boolean glowing;
    private TextView soon;
    private String occasion = "";
    private String shownGreeting = "";

    private static final String HOUSE_VERSE = "«لتكن عيناك مفتوحتين على هذا البيت ليلًا ونهارًا»";

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        builtScale = Ui.fontScale(this);
        builtTheme = Ui.theme(this);
        builtPhoto = Ui.usePhoto(this);
        Phone.start(getApplicationContext());
        setContentView(build());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Ui.fontScale(this) != builtScale || Ui.theme(this) != builtTheme || Ui.usePhoto(this) != builtPhoto) {
            recreate();
            return;
        }
        refreshApps();
        shownDay = "";
        lastSec = -1;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
        // remember which app tile the remote was on, so coming back lands on it and not on the first one
        View f = getCurrentFocus();
        lastDockIdx = f == null ? -1 : dock.indexOf(f);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home pressed while we are already open: stay where the remote was; only fall back to the first tile
        // when nothing is focused.
        if (getCurrentFocus() == null && firstFocus != null) firstFocus.requestFocus();
    }

    @Override
    public void onBackPressed() {
        // This is the home screen; there is nowhere to go back to.
    }

    // ---------------------------------------------------------------- helpers

    private <T extends View> T put(T v, float x, float y, float w, float h) {
        stage.addView(v, Ui.at(this, x, y, w, h));
        return v;
    }

    private void go(Class<?> cls) {
        startActivity(new Intent(this, cls));
    }

    private void openSystem(String action) {
        try {
            startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "غير متاح على هذا التلفزيون", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private TextView pill(String label, float x, float y, float w, float h, boolean on, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 24, on ? Ui.INK : Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused},
                Ui.rect(this, on ? 0xFFF3D698 : Ui.FOCUS, Ui.GOLD, 4, h / 2));
        bg.addState(new int[]{}, on ? Ui.rect(this, Ui.GOLD, Ui.GOLD, 0, h / 2)
                : Ui.rect(this, Ui.glass(0xB8), 0x66D4AF6A, 1.5f, h / 2));
        Ui.button(t, bg);
        t.setOnClickListener(l);
        return put(t, x, y, w, h);
    }

    private void shortcut(int i, String label, int glyph, int color, View.OnClickListener l) {
        float x = 1750, y = 170 + 92 * i;
        FrameLayout f = new FrameLayout(this);
        Ui.button(f, Ui.tile(this, Ui.glass(0xB8), 0x59D4AF6A, 22));
        f.setOnClickListener(l);
        View back = new View(this);
        back.setBackground(Ui.rect(this, color, color, 0, 12));
        f.addView(back, Ui.at(this, 35, 8, 40, 40));
        f.addView(new Widgets.Glyph(this, glyph), Ui.at(this, 35, 8, 40, 40));
        f.addView(Ui.box(this, label, 17, Ui.CREAM, Ui.alexBold(this), Gravity.CENTER_HORIZONTAL, 1), Ui.at(this, 3, 52, 104, 28));
        put(f, x, y, 110, 84);
    }

    /** A card with an arch top; focusable when it opens something. */
    private View card(float x, float y, float w, float h, View.OnClickListener l) {
        View v = new View(this);
        Ui.button(v, Ui.archTile(this, Ui.glass(0x8C), 0x66D4AF6A, 70, 54, 24));
        if (l != null) v.setOnClickListener(l);
        return put(v, x, y, w, h);
    }

    // ---------------------------------------------------------------- layout

    private static final int WHITE = 0xFFFFFFFF, SHADOW = 0xB0190A00, CREAM2 = 0xFFEFE3CB, GOLD2 = 0xFFFFD98A;

    /** A soft dark halo behind text so it stays readable on the bright photo. */
    private <T extends TextView> T shade(T t) {
        t.setShadowLayer(Ui.px(this, 10), 0, Ui.px(this, 2), SHADOW);
        return t;
    }

    private View build() {
        Context c = this;
        FrameLayout root = new FrameLayout(c);
        rootView = root;
        root.setBackground(Ui.glassBackground(c));

        stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        stage.setClipChildren(false);
        root.addView(stage, new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080), Gravity.CENTER));

        buildTopBar();
        buildPanels();
        buildNav();
        buildFavoritesStrip();

        put(shade(Ui.box(c, "بارك يا رب هذا البيت نهارًا وليلًا · إيلينا وكيفين", 23, CREAM2, Ui.alex(c), Ui.GC, 1)),
                360, 1030, 1200, 36);
        put(shade(Ui.box(c, "تنفيذ وتطوير Romany fawzy", 20, CREAM2, Ui.alex(c), Gravity.RIGHT, 1)),
                1310, 1040, 520, 28);

        quietShade = new View(c);
        quietShade.setBackgroundColor(0x4D000000);
        quietShade.setVisibility(View.GONE);
        root.addView(quietShade, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        return root;
    }

    private void buildTopBar() {
        Context c = this;

        // clock and dates, top right
        clock = Ui.box(c, "", 150, WHITE, Ui.alex(c), Gravity.RIGHT, 1);
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        shade(clock);
        put(clock, 1130, 34, 700, 160);
        ampm = Ui.text(c, "", 22, Ui.MUTED, Ui.alex(c)); // kept for the update code, not shown
        gregLine = shade(Ui.box(c, "", 34, WHITE, Ui.alex(c), Ui.GR, 1));
        put(gregLine, 1130, 196, 700, 40);
        copticLine = shade(Ui.box(c, "", 26, GOLD2, Ui.alexBold(c), Ui.GR, 1));
        put(copticLine, 1130, 238, 700, 34);
        fastLine = shade(Ui.box(c, "", 22, 0xFF9BE8B6, Ui.alexBold(c), Ui.GR, 1));
        put(fastLine, 1130, 274, 700, 30);

        // Wi-Fi, Bluetooth, weather, prices, phone: small glass chips, top left (tap Wi-Fi / Bluetooth to open the TV's screens)
        wifiIcon = new Widgets.StatusIcon(c, Widgets.StatusIcon.WIFI);
        Ui.button(wifiIcon, Ui.glassTile(c, 35));
        wifiIcon.setOnClickListener(v -> openSystem(Settings.ACTION_WIFI_SETTINGS));
        put(wifiIcon, 90, 64, 70, 70);
        btIcon = new Widgets.StatusIcon(c, Widgets.StatusIcon.BT);
        Ui.button(btIcon, Ui.glassTile(c, 35));
        btIcon.setOnClickListener(v -> openSystem(Settings.ACTION_BLUETOOTH_SETTINGS));
        put(btIcon, 172, 64, 70, 70);

        FrameLayout chip = new FrameLayout(c);
        chip.setBackground(Ui.glassRect(c, 35));
        wxGlyph = new Widgets.WxGlyph(c);
        chip.addView(wxGlyph, Ui.at(c, 12, 15, 40, 40));
        wxText = shade(Ui.text(c, "", 26, WHITE, Ui.alexBold(c)));
        wxText.setGravity(Gravity.CENTER_VERTICAL);
        wxText.setSingleLine(true);
        chip.addView(wxText, Ui.at(c, 60, 0, 156, 70));
        chip.setVisibility(View.GONE);
        wxChip = chip;
        put(chip, 254, 64, 220, 70);

        pricesChip = Ui.box(c, "", 22, WHITE, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
        pricesChip.setPadding(Ui.px(c, 16), 0, Ui.px(c, 16), 0);
        Ui.button(pricesChip, Ui.glassTile(c, 35));
        pricesChip.setOnClickListener(v -> go(PricesActivity.class));
        pricesChip.setVisibility(View.GONE);
        put(pricesChip, 486, 64, 330, 70);

        TextView phoneChip = Ui.box(c, "التحكم من التليفون", 22, WHITE, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
        phoneChip.setPadding(Ui.px(c, 16), 0, Ui.px(c, 16), 0);
        Ui.button(phoneChip, Ui.glassTile(c, 35));
        phoneChip.setOnClickListener(v -> go(PhoneActivity.class));
        put(phoneChip, 828, 64, 220, 70);

        TextView bgChip = Ui.box(c, "تغيير الخلفية", 22, WHITE, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
        bgChip.setPadding(Ui.px(c, 16), 0, Ui.px(c, 16), 0);
        Ui.button(bgChip, Ui.glassTile(c, 35));
        bgChip.setOnClickListener(v -> {
            if (!Ui.usePhoto(this)) {
                Ui.setUsePhoto(this, true);
                builtPhoto = true;
            }
            int i = Backgrounds.next(this);
            rootView.setBackground(Ui.glassBackground(this));
            Toast.makeText(this, "الخلفية " + Coptic.ar(i + 1) + " من " + Coptic.ar(Backgrounds.count(this)),
                    Toast.LENGTH_SHORT).show();
        });
        put(bgChip, 1060, 64, 220, 70);

        TextView netChip = Ui.box(c, "صور جديدة من النت", 22, WHITE, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
        netChip.setPadding(Ui.px(c, 16), 0, Ui.px(c, 16), 0);
        Ui.button(netChip, Ui.glassTile(c, 28));
        netChip.setOnClickListener(v -> {
            if (Backgrounds.isBusy()) {
                Toast.makeText(this, "جارٍ التنزيل… استنى شوية", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "جارٍ تنزيل صور دينية من النت…", Toast.LENGTH_SHORT).show();
            Backgrounds.fetchMoreAsync(this, n -> {
                if (isFinishing() || isDestroyed()) return;
                if (n > 0) {
                    if (!Ui.usePhoto(this)) {
                        Ui.setUsePhoto(this, true);
                        builtPhoto = true;
                    }
                    Backgrounds.showNewest(this);
                    rootView.setBackground(Ui.glassBackground(this));
                    Toast.makeText(this, "نزّلت " + Coptic.ar(n) + " صور جديدة", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "ما قدرتش أنزّل صور. اتأكد إن التلفزيون متصل بالنت وجرّب تاني",
                            Toast.LENGTH_LONG).show();
                }
            });
        });
        put(netChip, 90, 146, 250, 56);

        // greeting / feast / reminder pill in the middle, with the next family occasion under it
        kicker = shade(Ui.box(c, "", 30, WHITE, Ui.alexBold(c), Ui.GC, 1));
        kicker.setBackground(Ui.rect(c, 0x66190A00, 0x40FFFFFF, 1, 28));
        kicker.setPadding(Ui.px(c, 20), 0, Ui.px(c, 20), 0);
        put(kicker, 560, 150, 620, 56);
        banner = Ui.text(c, "", 24, Ui.INK, Ui.alexBold(c));
        banner.setGravity(Gravity.CENTER);
        banner.setSingleLine(true);
        banner.setBackground(Ui.rect(c, GOLD2, GOLD2, 0, 28));
        banner.setVisibility(View.GONE);
        put(banner, 560, 150, 620, 56);
        soon = shade(Ui.box(c, "", 24, GOLD2, Ui.alexBold(c), Ui.GC, 1));
        put(soon, 560, 214, 620, 34);
    }

    private void buildPanels() {
        Context c = this;
        final float y = 326, h = 348;

        // next prayer (right): tap to read it
        nextNormal = Ui.glassTile(c, 38);
        nextGlow = new StateListDrawable();
        nextGlow.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, 0xE0553018, Ui.GOLD, 5, 38));
        nextGlow.addState(new int[]{}, Ui.rect(c, 0xB0553018, GOLD2, 4, 38));
        nextCard = new View(c);
        Ui.button(nextCard, nextNormal);
        nextCard.setOnClickListener(v -> startActivity(new Intent(this, ReaderActivity.class)
                .putExtra(ReaderActivity.EXTRA_HOUR, openHour)));
        put(nextCard, 1270, y, 560, h);

        nextLabel = shade(Ui.box(c, "الصلاة القادمة", 27, CREAM2, Ui.alex(c), Ui.GR, 1));
        put(nextLabel, 1296, y + 20, 508, 30);
        nextName = shade(Ui.box(c, "", 72, WHITE, Ui.alexBold(c), Ui.GR, 1));
        put(nextName, 1440, y + 52, 364, 88);
        nextSub = shade(Ui.box(c, "", 30, CREAM2, Ui.alex(c), Ui.GR, 1));
        put(nextSub, 1440, y + 142, 364, 40);
        ring = new Widgets.Ring(c);
        put(ring, 1298, y + 48, 132, 132);
        nextCount = shade(Ui.text(c, "", 21, WHITE, Ui.alexBold(c)));
        nextCount.setGravity(Gravity.CENTER);
        nextCount.setSingleLine(true);
        nextCount.setTextDirection(View.TEXT_DIRECTION_LTR);
        put(nextCount, 1298, y + 48, 132, 132);

        dots = new Dots(c);
        put(dots, 1296, y + 204, 508, 26);

        TextView go = Ui.text(c, "افتح الصلاة", 30, 0xFF4A2F06, Ui.alexBold(c));
        go.setGravity(Gravity.CENTER);
        go.setSingleLine(true);
        go.setBackground(Ui.rect(c, WHITE, WHITE, 0, 32));
        put(go, 1296, y + 254, 508, 64);

        // verse of the day (left): tap for its reflection
        View verseCard = new View(c);
        Ui.button(verseCard, Ui.glassTile(c, 38));
        verseCard.setOnClickListener(v -> go(MeditationActivity.class));
        put(verseCard, 90, y, 560, h);
        put(shade(Ui.box(c, "آية اليوم", 27, CREAM2, Ui.alex(c), Ui.GR, 1)), 110, y + 20, 520, 36);
        verseText = shade(Ui.box(c, "", 52, WHITE, Ui.amiri(c), Ui.GR, 4));
        verseText.setLineSpacing(0, 0.9f);
        put(verseText, 110, y + 68, 520, 212);
        verseRef = shade(Ui.box(c, "", 24, GOLD2, Ui.alexBold(c), Ui.GR, 1));
        put(verseRef, 110, y + 292, 520, 40);

        // not shown on the home screen any more (each one has its own button in the strip), but still updated
        psalmText = Ui.box(c, "", 36, Ui.CREAM, Ui.amiri(c), Ui.GR, 2);
        psalmRef = Ui.box(c, "", 18, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        planDay = Ui.box(c, "", 26, Ui.CREAM, Ui.alexBold(c), Ui.GR, 1);
        planRead = Ui.box(c, "", 22, Ui.SOFT, Ui.alex(c), Ui.GR, 1);
        planBar = new Widgets.Bar(c);
        planDone = Ui.text(c, "", 20, Ui.INK, Ui.alexBold(c));
        planStreak = Ui.box(c, "", 18, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
    }

    /** The row of shortcuts, first (right-most) to last. */
    private void buildNav() {
        Context c = this;
        View strip = new View(c);
        strip.setBackground(Ui.glassRect(c, 48));
        put(strip, 90, 690, 1740, 96);

        final String[] names = {"الأجبية", "الكتاب المقدس", "القراءات", "المزامير", "تأملات", "الألحان", "المداخل",
                "إعدادات الشاشة", "الإعدادات"};
        final Runnable[] acts = {
                () -> go(AgpeyaActivity.class),
                () -> go(BibleActivity.class),
                () -> go(ReadingsActivity.class),
                () -> go(PsalmActivity.class),
                () -> go(MeditationActivity.class),
                () -> Media.search(this, "ألحان وتسبحة قبطية أرثوذكسية"),
                () -> go(InputsActivity.class),
                () -> openSystem(Settings.ACTION_DISPLAY_SETTINGS),
                () -> go(SettingsActivity.class)};
        final float inner = 1740 - 24, slot = inner / names.length;
        for (int i = 0; i < names.length; i++) {
            final Runnable act = acts[i];
            final TextView t = Ui.box(c, names[i], 24, WHITE, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
            t.setPadding(Ui.px(c, 8), 0, Ui.px(c, 8), 0);
            Ui.button(t, navFocus(c));
            t.setOnFocusChangeListener((view, has) -> {
                view.animate().scaleX(has ? 1.04f : 1f).scaleY(has ? 1.04f : 1f).setDuration(120).start();
                ((TextView) view).setTextColor(has ? 0xFF4A2F06 : WHITE);
            });
            t.setOnClickListener(v -> act.run());
            // right to left: the first name is the right-most
            put(t, 90 + 12 + inner - (i + 1) * slot + 4, 704, slot - 8, 68);
        }
    }

    private static StateListDrawable navFocus(Context c) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, 0xF2FFFFFF, Ui.GOLD, 3, 34));
        s.addState(new int[]{}, Ui.rect(c, 0x00000000, 0x00000000, 0, 34));
        return s;
    }

    private void buildFavoritesStrip() {
        View strip = new View(this);
        strip.setBackground(Ui.glassRect(this, 44));
        put(strip, 90, 806, 1740, 204);
    }

    // ---------------------------------------------------------------- apps

    private void refreshApps() {
        Context c = this;

        // which favourite had the remote before we rebuild the row (so coming back lands on the same one)
        View f = getCurrentFocus();
        int keep = f == null ? -1 : dock.indexOf(f);
        if (keep < 0) keep = lastDockIdx;
        lastDockIdx = -1;

        for (View v : dock) stage.removeView(v);
        dock.clear();

        final List<Apps.App> all = Apps.list(c);
        List<Apps.App> shown = new ArrayList<>();
        for (String p : Apps.favoritePackages(c, all))
            for (Apps.App a : all) if (a.pkg.equals(p) && !shown.contains(a)) shown.add(a);
        int n = Math.min(9, shown.size());
        int count = n + 1; // + "all apps"
        float gap = 14, total = 1692;
        float w = Math.min(168, (total - gap * (count - 1)) / count);
        float startX = 90 + 24 + (total - (w * count + gap * (count - 1))) / 2f;
        // the first favourite is the right-most (reading order is right to left)
        for (int i = 0; i < n; i++) {
            final Apps.App a = shown.get(i);
            View t = dockTile(a.icon, null, a.label, w);
            t.setOnClickListener(v -> Apps.launch(this, a.pkg));
            put(t, startX + (count - 1 - i) * (w + gap), 818, w, 180);
            dock.add(t);
        }
        View allTile = dockTile(null, new Widgets.Glyph(c, Widgets.Glyph.GRID), "كل التطبيقات", w);
        allTile.setOnClickListener(v -> go(AllAppsActivity.class));
        put(allTile, startX, 818, w, 180);
        dock.add(allTile);

        firstFocus = n > 0 ? dock.get(0) : nextCard;
        if (keep >= 0 && keep < dock.size()) dock.get(keep).requestFocus();
        else if (getCurrentFocus() == null || keep >= 0) firstFocus.requestFocus();
    }

    private View dockTile(android.graphics.drawable.Drawable icon, View glyph, String label, float w) {
        Context c = this;
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, Ui.px(c, 20), 0, 0);
        Ui.button(t, Ui.focusOnly(c, 30));
        if (icon != null) {
            ImageView iv = new ImageView(c);
            iv.setImageDrawable(icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            t.addView(iv, Ui.lp(c, 96, 96));
        } else {
            FrameLayout f = new FrameLayout(c);
            View back = new View(c);
            back.setBackground(Ui.rect(c, 0x40FFFFFF, 0x59FFFFFF, 1.5f, 24));
            f.addView(back, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            f.addView(glyph, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            t.addView(f, Ui.lp(c, 96, 96));
        }
        Ui.gap(c, t, 8);
        TextView lab = shade(Ui.box(c, label, 22, WHITE, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 2));
        t.addView(lab, Ui.lp(c, w - 12, 48));
        return t;
    }

    /** Seven dots for the day's prayers: white = prayed, gold = the one coming up (or due now), faded = not yet. */
    static final class Dots extends View {
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private int mask, next = -1;

        Dots(Context c) {
            super(c);
        }

        void set(int mask, int next) {
            if (mask != this.mask || next != this.next) {
                this.mask = mask;
                this.next = next;
                invalidate();
            }
        }

        @Override
        protected void onDraw(android.graphics.Canvas cv) {
            // from the right: dawn, third, sixth, ninth, sunset, sleep, midnight (Agpeya indexes 1..6, then 0)
            final int[] order = {1, 2, 3, 4, 5, 6, 0};
            float w = getWidth(), h = getHeight(), r = h * 0.30f;
            float step = (w - 2 * r - 12) / 6f;
            for (int k = 0; k < 7; k++) {
                int hour = order[k];
                float cx = w - r - 6 - k * step;
                if (hour == next) {
                    p.setColor(0x55FFD98A);
                    cv.drawCircle(cx, h / 2f, h * 0.5f, p);
                    p.setColor(0xFFFFD98A);
                } else if (((mask >> hour) & 1) == 1) {
                    p.setColor(0xFFFFFFFF);
                } else {
                    p.setColor(0x59FFFFFF);
                }
                cv.drawCircle(cx, h / 2f, r, p);
            }
        }
    }

    // ---------------------------------------------------------------- ticking

    private static String greeting(int hour) {
        if (hour >= 5 && hour < 12) return "صباح الخير يا إيلينا وكيفين";
        if (hour >= 12 && hour < 17) return "نهارك سعيد يا إيلينا وكيفين";
        if (hour >= 17 && hour < 21) return "مساء الخير يا إيلينا وكيفين";
        return "ليلة هادئة يا إيلينا وكيفين";
    }

    private static String minutesWord(int n) {
        if (n <= 1) return "دقيقة واحدة";
        if (n == 2) return "دقيقتين";
        return Coptic.ar(n) + " دقائق";
    }

    private void bindPlan() {
        Plan.Today t = Plan.today(this);
        Ui.setIfChanged(planDay, "اليوم " + Coptic.ar(t.day) + " من " + Coptic.ar(Plan.DAYS));
        Ui.setIfChanged(planRead, t.label);
        planBar.set(t.day / (float) Plan.DAYS);
        Ui.setIfChanged(planStreak, t.streak > 0 ? "متتالية: " + Coptic.ar(t.streak) + " يوم" : "");
        planDone.setText(t.doneToday ? "تمّت اليوم ✓" : "تمّت القراءة ✓");
        planDone.setAlpha(t.doneToday ? 0.55f : 1f);
    }

    private void bindPrices() {
        double[] v = Prices.cached(this);
        if (v == null) {
            pricesChip.setVisibility(View.GONE);
            return;
        }
        pricesChip.setText(Prices.chip(v));
        pricesChip.setVisibility(View.VISIBLE);
    }

    private void bindWeather() {
        String[] w = Weather.cached(this);
        if (w == null) {
            wxChip.setVisibility(View.GONE);
            return;
        }
        wxGlyph.setCode(Integer.parseInt(w[1]));
        Ui.setIfChanged(wxText, "القاهرة " + Coptic.ar(Integer.parseInt(w[0])) + "°");
        wxChip.setVisibility(View.VISIBLE);
    }

    private void update() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        int sec = now.toLocalTime().toSecondOfDay();

        int h = now.getHour(), m = now.getMinute();
        int h12 = h % 12 == 0 ? 12 : h % 12;
        String digits = Coptic.ar(h12 + ":" + (m < 10 ? "0" : "") + m);
        String sfx = h < 12 ? "ص" : "م";
        if (!(digits + sfx).equals(shownClock)) {
            shownClock = digits + sfx;
            android.text.SpannableString sp = new android.text.SpannableString(digits + " " + sfx);
            sp.setSpan(new android.text.style.RelativeSizeSpan(0.34f), digits.length() + 1, sp.length(), 0);
            clock.setText(sp);
        }

        String dayKey = today.toString();
        if (!dayKey.equals(shownDay)) {
            shownDay = dayKey;
            refreshDay(today);
        }

        // Wi-Fi / Bluetooth every few seconds, weather checked once a minute
        if (lastSec < 0 || sec % 5 == 0) {
            wifiIcon.setState(Status.wifi(this));
            btIcon.setState(Status.bluetooth(this));
        }
        if (lastSec < 0 || sec % 60 == 0) {
            Weather.refresh(this, this::bindWeather);
            bindWeather();
            Prices.refresh(this, this::bindPrices);
            bindPrices();
        }
        lastSec = sec;

        // next prayer
        int next = Agpeya.next(this, sec);
        int until = Agpeya.secondsUntil(this, next, sec);
        int since = Agpeya.secondsSince(this, sec);

        // reminder: 10 minutes before an hour, and 15 minutes after it starts
        int prev = 0, best = Integer.MAX_VALUE;
        for (int i = 0; i < 7; i++) {
            int s = sec - Agpeya.minutes(this, i) * 60;
            if (s < 0) s += 86400;
            if (s < best) {
                best = s;
                prev = i;
            }
        }
        boolean prayNow = until > 600 && best <= 900;
        openHour = until <= 600 ? next : (prayNow ? prev : next);

        if (prayNow != glowing) {
            glowing = prayNow;
            Ui.button(nextCard, glowing ? nextGlow : nextNormal);
        }
        if (prayNow) {
            Ui.setIfChanged(nextLabel, "حان وقت الصلاة الآن");
            Ui.setIfChanged(nextName, Agpeya.NAMES[prev]);
            Ui.setIfChanged(nextSub, best < 60 ? "بدأت الآن" : "بدأت من " + minutesWord(best / 60));
        } else {
            Ui.setIfChanged(nextLabel, "الصلاة القادمة");
            Ui.setIfChanged(nextName, Agpeya.NAMES[next]);
            Ui.setIfChanged(nextSub, "الساعة " + Agpeya.clock(Agpeya.minutes(this, next)));
        }
        Ui.setIfChanged(nextCount, Agpeya.countdown(until));
        ring.set(since / (float) Math.max(1, since + until));
        dots.set(Agpeya.mask(this, today), prayNow ? prev : next);

        if (until <= 600) {
            Ui.setIfChanged(banner, "اقترب وقت صلاة " + Agpeya.NAMES[next] + " — بعد " + minutesWord((until + 59) / 60));
            banner.setVisibility(View.VISIBLE);
            kicker.setVisibility(View.INVISIBLE);
        } else if (prayNow) {
            Ui.setIfChanged(banner, "حان وقت صلاة " + Agpeya.NAMES[prev] + " — صلِّ الآن");
            banner.setVisibility(View.VISIBLE);
            kicker.setVisibility(View.INVISIBLE);
        } else {
            banner.setVisibility(View.GONE);
            kicker.setVisibility(View.VISIBLE);
        }

        String g = greeting(h);
        if (!g.equals(shownGreeting)) {
            shownGreeting = g;
            applyKicker(today);
        }

        // soft bell at the start of an hour (daytime only)
        int minuteOfDay = h * 60 + m;
        if (now.getSecond() < 3 && minuteOfDay != lastChime && h >= 5 && h <= 21 && Chime.enabled(this)) {
            for (int i = 0; i < 7; i++) {
                if (Agpeya.minutes(this, i) == minuteOfDay) {
                    lastChime = minuteOfDay;
                    Chime.play(this);
                    break;
                }
            }
        }

        // quiet mode after 9 pm until 5 am
        boolean quiet = Ui.quiet(this) && (h >= 21 || h < 5);
        quietShade.setVisibility(quiet ? View.VISIBLE : View.GONE);
    }

    private void applyKicker(LocalDate d) {
        String feast = Coptic.feast(d);
        kicker.setText(!occasion.isEmpty() ? occasion
                : feast.isEmpty() ? shownGreeting : "كل سنة وإنتم طيبين · " + feast);
    }

    private void refreshDay(LocalDate d) {
        Ui.setIfChanged(copticLine, Coptic.dateLine(d));
        Ui.setIfChanged(gregLine, Coptic.gregorianLine(d));

        String feast = Coptic.feast(d);
        String fast = Coptic.fastToday(d);
        LocalDate tm = d.plusDays(1);
        String tomorrow = Coptic.feast(tm);
        if (tomorrow.isEmpty()) {
            String f = Coptic.fastToday(tm);
            tomorrow = f.isEmpty() ? "بدون صوم" : f;
        }

        // the fast is only a small green line under the date
        if (fast.isEmpty()) {
            fastLine.setVisibility(View.INVISIBLE);
        } else {
            int[] fp = Coptic.fastProgress(d);
            fastLine.setText("● " + fast + (fp[0] == 1 ? " · اليوم " + Coptic.ar(fp[1]) + " من " + Coptic.ar(fp[2]) : ""));
            fastLine.setVisibility(View.VISIBLE);
        }

        occasion = Occasions.today(d);

        String[] ps = Psalms.today(this, d);
        psalmText.setText(ps == null ? "المزامير في الأجبية" : Psalms.preview(ps[1]));
        psalmRef.setText(ps == null ? "" : ps[0]);

        String[] v = Verses.today(d);
        verseText.setText(v[0]);
        verseRef.setText(v[1] + "  ·  اضغط لقراءة التأمل");

        bindPlan();

        String up = Occasions.upcoming(d);
        soon.setText(up);
        soon.setVisibility(up.isEmpty() ? View.INVISIBLE : View.VISIBLE);
        applyKicker(d);
    }
}
