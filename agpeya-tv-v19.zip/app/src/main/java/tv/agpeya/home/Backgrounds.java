package tv.agpeya.home;

// تنفيذ وتطوير Romany fawzy

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.function.IntConsumer;

/**
 * The pictures that can be the background: the golden photo first, then the ones drawn into assets/backgrounds, then
 * the ones downloaded from Wikimedia Commons (old paintings and icons) into the app's own folder.
 */
final class Backgrounds {
    private Backgrounds() {}

    private static final String UA = "AgpeyaTV/3.6 (home screen app for a family TV)";
    private static final int KEEP = 30;           // downloaded pictures kept on the TV
    private static final long MAX_BYTES = 6L * 1024 * 1024;
    private static volatile boolean busy;

    /** What we ask Commons for; one is picked at random each time. */
    private static final String[] SEARCHES = {
            "Jesus Christ painting", "Resurrection of Jesus painting", "Good Shepherd painting",
            "Last Supper painting", "Virgin Mary and Child painting", "Coptic icon", "Christ Pantocrator icon",
            "Nativity of Jesus painting", "Crucifixion painting", "Ascension of Jesus painting",
            "Sermon on the Mount painting", "Baptism of Jesus painting"};

    static File webDir(Context c) {
        File d = new File(c.getApplicationContext().getFilesDir(), "webbg");
        d.mkdirs();
        return d;
    }

    static List<String> names(Context c) {
        List<String> out = new ArrayList<>();
        out.add("bg.jpg");
        try {
            String[] fs = c.getAssets().list("backgrounds");
            if (fs != null) {
                Arrays.sort(fs);
                for (String f : fs) out.add("backgrounds/" + f);
            }
        } catch (Exception ignored) {
            // just the first picture then
        }
        File[] ws = webDir(c).listFiles();
        if (ws != null) {
            Arrays.sort(ws, (a, b) -> a.getName().compareTo(b.getName()));
            for (File f : ws) if (f.getName().endsWith(".jpg")) out.add("web/" + f.getName());
        }
        return out;
    }

    static int count(Context c) {
        return names(c).size();
    }

    static int index(Context c) {
        int i = c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getInt("bgidx", 0);
        return i < 0 || i >= count(c) ? 0 : i;
    }

    static void setIndex(Context c, int i) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putInt("bgidx", i).apply();
    }

    /** Moves to the next picture (and back to the first after the last); returns its number, from 0. */
    static int next(Context c) {
        int i = (index(c) + 1) % count(c);
        setIndex(c, i);
        return i;
    }

    /** The chosen picture, or null if it cannot be read. */
    static Bitmap decode(Context c) {
        String name = names(c).get(index(c));
        try {
            if (name.startsWith("web/")) {
                File f = new File(webDir(c), name.substring(4));
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                int sample = 1;
                while (o.outWidth / (sample * 2) >= 1920 && o.outHeight / (sample * 2) >= 1080) sample *= 2;
                BitmapFactory.Options d = new BitmapFactory.Options();
                d.inSampleSize = sample;
                return BitmapFactory.decodeFile(f.getAbsolutePath(), d);
            }
            try (InputStream in = c.getAssets().open(name)) {
                return BitmapFactory.decodeStream(in);
            }
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------ from the internet

    static boolean isBusy() {
        return busy;
    }

    /**
     * Downloads a few new pictures in the background, then calls {@code done} on the main thread with how many were
     * saved (0 = nothing, e.g. no internet). Does nothing if a download is already running.
     */
    static void fetchMoreAsync(Context ctx, IntConsumer done) {
        if (busy) return;
        busy = true;
        final Context c = ctx.getApplicationContext();
        new Thread(() -> {
            int saved = 0;
            try {
                saved = fetchMore(c, 5);
            } catch (Throwable ignored) {
                // offline or refused: the pictures already there keep working
            }
            busy = false;
            final int n = saved;
            if (done != null) new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> done.accept(n));
        }).start();
    }

    private static int fetchMore(Context c, int want) throws Exception {
        Random rnd = new Random();
        String q = SEARCHES[rnd.nextInt(SEARCHES.length)] + " filetype:bitmap";
        String url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2"
                + "&generator=search&gsrnamespace=6&gsrlimit=40&gsroffset=" + rnd.nextInt(120)
                + "&gsrsearch=" + URLEncoder.encode(q, "UTF-8")
                + "&prop=imageinfo&iiprop=url%7Csize%7Cmime&iiurlwidth=1920";
        JSONObject root = new JSONObject(new String(get(url, 1024 * 1024), "UTF-8"));
        JSONObject query = root.optJSONObject("query");
        if (query == null) return 0;
        JSONArray pages = query.optJSONArray("pages");
        if (pages == null) return 0;

        // keep wide, big, plain JPEGs only (they fill the screen without ugly bars), in a random order
        List<String> urls = new ArrayList<>();
        for (int i = 0; i < pages.length(); i++) {
            JSONArray info = pages.getJSONObject(i).optJSONArray("imageinfo");
            if (info == null || info.length() == 0) continue;
            JSONObject ii = info.getJSONObject(0);
            int w = ii.optInt("width"), h = ii.optInt("height");
            String thumb = ii.optString("thumburl", "");
            if (!"image/jpeg".equals(ii.optString("mime")) || thumb.isEmpty()) continue;
            double ratio = h == 0 ? 0 : w / (double) h;
            if (w < 1400 || h < 700 || ratio < 1.25 || ratio > 2.4) continue;
            urls.add(thumb);
        }
        Collections.shuffle(urls, rnd);

        int saved = 0;
        for (String u : urls) {
            if (saved >= want) break;
            try {
                byte[] data = get(u, MAX_BYTES);
                // make sure it really is a picture before keeping it
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, o);
                if (o.outWidth < 1000) continue;
                File f = new File(webDir(c), String.format(java.util.Locale.US, "%013d.jpg", System.currentTimeMillis()));
                try (FileOutputStream fo = new FileOutputStream(f)) {
                    fo.write(data);
                }
                saved++;
                Thread.sleep(5); // keeps the file names (they are the time) in order
            } catch (Exception ignored) {
                // skip this one
            }
        }
        trim(c);
        return saved;
    }

    /** Keeps only the newest KEEP downloaded pictures. */
    private static void trim(Context c) {
        File[] ws = webDir(c).listFiles();
        if (ws == null || ws.length <= KEEP) return;
        Arrays.sort(ws, (a, b) -> a.getName().compareTo(b.getName()));
        for (int i = 0; i < ws.length - KEEP; i++) ws[i].delete();
    }

    /** Selects the newest downloaded picture. */
    static void showNewest(Context c) {
        List<String> n = names(c);
        setIndex(c, n.size() - 1);
    }

    private static byte[] get(String url, long max) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(20000);
        conn.setRequestProperty("User-Agent", UA);
        try {
            if (conn.getResponseCode() != 200) throw new Exception("http");
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > max) throw new Exception("big");
            }
            return out.toByteArray();
        } finally {
            conn.disconnect();
        }
    }
}
