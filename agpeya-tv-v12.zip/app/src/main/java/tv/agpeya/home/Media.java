package tv.agpeya.home;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

/** Opens a YouTube search (hymns, the Agpeya read aloud) in the TV's YouTube app, or any browser. */
final class Media {
    private Media() {}

    static void search(Context c, String query) {
        Uri u = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query));
        Intent i = new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            i.setPackage("com.google.android.youtube.tv");
            c.startActivity(i);
        } catch (Exception e) {
            try {
                i.setPackage(null);
                c.startActivity(i);
            } catch (Exception e2) {
                Toast.makeText(c, "تطبيق يوتيوب غير متاح", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
