package tv.agpeya.home;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewOutlineProvider;

import java.time.LocalTime;
import java.util.Random;

/**
 * The church picture, drawn in code so it can follow the time of day (night, dawn, day, sunset)
 * and move a little (twinkling stars, a glowing cross). HERO = the church under the cross (home banner),
 * PAGE = the arch with the lamps (Agpeya page and readings background).
 */
final class Scene extends View {
    static final int HERO = 0, PAGE = 1;

    // minute of day, sky top / middle / bottom, star alpha, silhouette colour, window alpha
    private static final int[][] KEYS = {
            {0, 0xFF040918, 0xFF0F2150, 0xFF3A3F78, 255, 0xFF050A1C, 230},
            {270, 0xFF040918, 0xFF0F2150, 0xFF3A3F78, 255, 0xFF050A1C, 230},
            {360, 0xFF1B2A5E, 0xFF7B6AA3, 0xFFF4B07A, 90, 0xFF0E1530, 160},
            {480, 0xFF2D6CB0, 0xFF6FB1E8, 0xFFD3EBF8, 0, 0xFF1B2A4D, 40},
            {960, 0xFF2D6CB0, 0xFF6FB1E8, 0xFFD3EBF8, 0, 0xFF1B2A4D, 40},
            {1080, 0xFF2A2E6B, 0xFFA14F7C, 0xFFF5A552, 40, 0xFF0C1230, 190},
            {1170, 0xFF0C1840, 0xFF2B3B7A, 0xFF7A5E8E, 160, 0xFF080E26, 215},
            {1260, 0xFF040918, 0xFF0F2150, 0xFF3A3F78, 255, 0xFF050A1C, 230},
            {1440, 0xFF040918, 0xFF0F2150, 0xFF3A3F78, 255, 0xFF050A1C, 230},
    };

    private final int mode;
    private int feast;          // 0 none, 1 Nativity, 2 Resurrection and related, 3 other feasts
    private boolean fasting;
    private float phase;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final float[] sx = new float[160], sy = new float[160], sr = new float[160], so = new float[160];
    private int[] pal;
    private int palMinute = -1;
    private boolean running;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            phase += 0.07f;
            invalidate();
            if (running) handler.postDelayed(this, 70);
        }
    };

    Scene(Context c, int mode) {
        super(c);
        this.mode = mode;
        Random r = new Random(7);
        for (int i = 0; i < sx.length; i++) {
            sx[i] = r.nextFloat();
            sy[i] = r.nextFloat();
            sr[i] = 0.6f + r.nextFloat() * 1.6f;
            so[i] = 0.3f + r.nextFloat() * 0.7f;
        }
    }

    void setFeast(int f) {
        feast = f;
    }

    void setFasting(boolean f) {
        fasting = f;
    }

    /** Round the corners of the picture (home banner). */
    void round(final float radiusPx) {
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
        setClipToOutline(true);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        handler.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        handler.removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    // ---------------------------------------------------------------- colours

    private static int lerp(int a, int b, float t) {
        int r = 0;
        for (int s = 0; s <= 24; s += 8) {
            int x = (a >>> s) & 0xFF, y = (b >>> s) & 0xFF;
            r |= (Math.round(x + (y - x) * t) & 0xFF) << s;
        }
        return r;
    }

    private int[] palette(int minute) {
        int i = 0;
        while (i < KEYS.length - 2 && minute >= KEYS[i + 1][0]) i++;
        int[] a = KEYS[i], b = KEYS[i + 1];
        float t = (minute - a[0]) / (float) Math.max(1, b[0] - a[0]);
        int[] o = new int[6];
        for (int k = 0; k < 6; k++) {
            int idx = k + 1;
            o[k] = (k == 3 || k == 5) ? Math.round(a[idx] + (b[idx] - a[idx]) * t) : lerp(a[idx], b[idx], t);
        }
        return o; // top, mid, bottom, starAlpha, silhouette, windowAlpha
    }

    private void ensurePalette() {
        int m = LocalTime.now().toSecondOfDay() / 60;
        if (m != palMinute || pal == null) {
            palMinute = m;
            pal = palette(m);
        }
    }

    // ---------------------------------------------------------------- drawing

    @Override
    protected void onDraw(Canvas cv) {
        ensurePalette();
        if (getWidth() == 0 || getHeight() == 0) return;
        if (mode == HERO) drawHero(cv); else drawPage(cv);
    }

    private void star(Canvas cv, float cx, float cy, float r, int alpha) {
        path.reset();
        for (int i = 0; i < 8; i++) {
            float ang = (float) (Math.PI / 4 * i - Math.PI / 2);
            float rad = (i % 2 == 0) ? r : r * 0.22f;
            float x = cx + (float) Math.cos(ang) * rad, y = cy + (float) Math.sin(ang) * rad;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        path.close();
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFF3C4);
        p.setAlpha(alpha);
        cv.drawPath(path, p);
    }

    private void glow(Canvas cv, float cx, float cy, float r, int color, int alpha) {
        p.setStyle(Paint.Style.FILL);
        p.setAlpha(255); // a shader is dimmed by the paint's old alpha
        p.setShader(new RadialGradient(cx, cy, r, (alpha << 24) | (color & 0xFFFFFF), color & 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawCircle(cx, cy, r, p);
        p.setShader(null);
    }

    private void cross(Canvas cv, float cx, float cy, float s) {
        float a = s / 2f, t = s * 0.16f;
        p.setStyle(Paint.Style.FILL);
        p.setAlpha(255); // the rays before it leave a nearly invisible alpha on the paint
        p.setAlpha(255); // a shader is dimmed by the paint's old alpha
        p.setShader(new LinearGradient(0, cy - a, 0, cy + a,
                new int[]{0xFFFFF0BE, 0xFFE9BE6A, 0xFFB98532}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP));
        rf.set(cx - t / 2, cy - a, cx + t / 2, cy + a);
        cv.drawRoundRect(rf, t * .3f, t * .3f, p);
        rf.set(cx - a, cy - t / 2, cx + a, cy + t / 2);
        cv.drawRoundRect(rf, t * .3f, t * .3f, p);
        cv.drawCircle(cx, cy - a, t * .75f, p);
        cv.drawCircle(cx, cy + a, t * .75f, p);
        cv.drawCircle(cx - a, cy, t * .75f, p);
        cv.drawCircle(cx + a, cy, t * .75f, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(t * .22f);
        p.setColor(0xFFFFE7A8);
        p.setAlpha(255);
        cv.drawCircle(cx, cy, t * 1.15f, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void dome(Canvas cv, float cx, float base, float r) {
        path.reset();
        rf.set(cx - r, base - r * 1.15f, cx + r, base + r * 1.15f);
        path.moveTo(cx - r, base);
        path.arcTo(rf, 180, 180);
        path.close();
        cv.drawPath(path, p);
        cv.drawRect(cx - r * .12f, base - r * 1.15f - r * .38f, cx + r * .12f, base - r * 1.15f + 4, p);
    }

    private void windowArch(Canvas cv, float x, float y, float w, float h) {
        path.reset();
        path.moveTo(x, y + h);
        path.lineTo(x, y + w / 2);
        rf.set(x, y, x + w, y + w);
        path.arcTo(rf, 180, 180);
        path.lineTo(x + w, y + h);
        path.close();
        cv.drawPath(path, p);
    }

    private void drawStars(Canvas cv, float w, float maxY) {
        int sa = pal[3];
        if (sa <= 0) return;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < sx.length; i++) {
            float tw = 0.65f + 0.35f * (float) Math.sin(phase * (0.5f + sr[i] * 0.5f) + i * 1.7f);
            p.setColor(0xFFFFF3D6);
            p.setAlpha(Math.min(255, Math.round(sa * so[i] * tw)));
            cv.drawCircle(sx[i] * w, sy[i] * maxY, sr[i], p);
        }
    }

    private void drawHero(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float s = w / 1600f;
        float vis = h / s;
        int win = pal[5];
        float day = 0.45f + 0.55f * (win / 230f);
        cv.save();
        cv.scale(s, s);
        p.setStyle(Paint.Style.FILL);
        p.setAlpha(255); // a shader is dimmed by the paint's old alpha
        p.setShader(new LinearGradient(0, 0, 0, 600, new int[]{pal[0], pal[1], pal[2]}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, 1600, vis + 2, p);
        p.setShader(null);
        drawStars(cv, 1600, 430);

        // horizon glow
        cv.save();
        cv.scale(1f, 0.37f);
        glow(cv, 520, 600 / 0.37f, 700, 0xFFE7A857, (int) (140 * day));
        cv.restore();

        float cx = 520, cy = 150;
        boolean easter = feast == 2;
        float pulse = 0.9f + 0.1f * (float) Math.sin(phase * 0.9f);
        glow(cv, cx, cy, easter ? 420 : 280, 0xFFFFD98A, (int) (140 * day * pulse));
        // rays
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFE7A8);
        p.setAlpha((int) (9 * day * (easter ? 2 : 1)));
        int rays = easter ? 28 : 20;
        for (int i = 0; i < rays; i++) {
            double a0 = Math.toRadians(i * (360.0 / rays) + phase * 1.5), a1 = a0 + Math.toRadians(3);
            path.reset();
            path.moveTo(cx, cy);
            path.lineTo(cx + (float) Math.cos(a0) * 2600, cy + (float) Math.sin(a0) * 2600);
            path.lineTo(cx + (float) Math.cos(a1) * 2600, cy + (float) Math.sin(a1) * 2600);
            path.close();
            cv.drawPath(path, p);
        }
        float cs = 150 * (1f + 0.02f * (float) Math.sin(phase * 0.9f));
        cross(cv, cx, cy, cs);

        // feast decorations
        if (feast == 1) {
            glow(cv, 1000, 110, 160, 0xFFFFE9A8, (int) (150 * pulse));
            star(cv, 1000, 110, 54, 255);
        } else if (feast == 3) {
            for (int i = 0; i < 6; i++) {
                float ang = phase * 0.3f + i * 1.05f;
                star(cv, cx + (float) Math.cos(ang) * 190, cy + (float) Math.sin(ang) * 120, 16,
                        (int) (140 + 100 * Math.sin(phase + i)));
            }
        }

        // church
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(pal[4]);
        p.setAlpha(255);
        cv.drawRect(120, 300, 230, 600, p);
        dome(cv, 175, 300, 62);
        cv.drawRect(260, 400, 780, 600, p);
        dome(cv, 350, 400, 70);
        dome(cv, 690, 400, 70);
        path.reset();
        rf.set(400, 400 - 138, 640, 400 + 138);
        path.moveTo(400, 400);
        path.arcTo(rf, 180, 180);
        path.close();
        cv.drawPath(path, p);
        cv.drawRect(250, 590, 790, 600, p);
        p.setColor(0xFFF3C56B);
        int base = 0;
        for (float x = 300; x < 760; x += 64) {
            p.setAlpha((int) (win * (0.88f + 0.12f * Math.sin(phase * 0.5f + x))));
            windowArch(cv, x, 450, 30, 64);
            base++;
        }
        p.setAlpha(win);
        windowArch(cv, 155, 360, 40, 70);
        windowArch(cv, 155, 460, 40, 70);
        cv.restore();

        if (fasting) {
            p.setShader(null);
            p.setColor(0x38000000);
            cv.drawRect(0, 0, w, h, p);
        }
    }

    private void drawPage(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float st = Math.min(w / 1920f, h / 1080f);
        float ox = (w - 1920 * st) / 2f, oy = (h - 1080 * st) / 2f;
        int dark = 0xFF060C20;
        int c0 = lerp(pal[0], dark, .55f), c1 = lerp(pal[1], dark, .55f), c2 = lerp(pal[2], dark, .5f);
        p.setStyle(Paint.Style.FILL);
        p.setAlpha(255); // a shader is dimmed by the paint's old alpha
        p.setShader(new LinearGradient(0, 0, 0, h, new int[]{c0, c1, c2}, new float[]{0, .6f, 1}, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, p);
        p.setShader(null);
        drawStars(cv, w, h * 0.4f);

        float day = 0.5f + 0.5f * (pal[5] / 230f);
        cv.save();
        cv.translate(ox, oy);
        cv.scale(st, st);
        // arch lines
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFFD4AF6A);
        float[] rr = {520, 480, 440}, aa = {.9f, .5f, .3f}, ww = {6, 3, 2};
        for (int i = 0; i < 3; i++) {
            path.reset();
            path.moveTo(960 - rr[i], 1100);
            path.lineTo(960 - rr[i], 520);
            rf.set(960 - rr[i], 520 - rr[i], 960 + rr[i], 520 + rr[i]);
            path.arcTo(rf, 180, 180);
            path.lineTo(960 + rr[i], 1100);
            p.setStrokeWidth(ww[i]);
            p.setAlpha((int) (255 * aa[i]));
            cv.drawPath(path, p);
        }
        p.setStyle(Paint.Style.FILL);
        float pulse = 0.9f + 0.1f * (float) Math.sin(phase * 0.9f);
        glow(cv, 960, 470, 340, 0xFFFFD98A, (int) (150 * day * pulse));
        cross(cv, 960, 470, 240 * (1f + 0.015f * (float) Math.sin(phase * 0.9f)));

        // hanging lamps, swaying a little
        float[][] lamps = {{520, 260, 1}, {760, 330, .9f}, {1160, 330, .9f}, {1400, 260, 1}};
        for (int i = 0; i < lamps.length; i++) {
            float x = lamps[i][0], l = lamps[i][1], sc = lamps[i][2];
            float sway = (float) Math.sin(phase * 0.7f + i * 1.3f) * 5f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3);
            p.setColor(0xFF8C6A2B);
            p.setAlpha(255);
            cv.drawLine(x, 0, x + sway, l, p);
            p.setStyle(Paint.Style.FILL);
            glow(cv, x + sway, l + 40, 120, 0xFFFFD98A, (int) (150 * day));
            p.setColor(0xFFE4B35E);
            path.reset();
            path.moveTo(x + sway - 26 * sc, l);
            path.lineTo(x + sway + 26 * sc, l);
            path.lineTo(x + sway + 18 * sc, l + 70 * sc);
            path.lineTo(x + sway - 18 * sc, l + 70 * sc);
            path.close();
            cv.drawPath(path, p);
            p.setColor(0xFFFFF2C4);
            cv.drawCircle(x + sway, l + 34 * sc, 14 * sc, p);
        }

        // floor
        float left = -ox / st - 10, right = 1920 + ox / st + 10, bottom = 1080 + oy / st + 10;
        p.setAlpha(255); // a shader is dimmed by the paint's old alpha
        p.setShader(new LinearGradient(0, 800, 0, bottom, new int[]{0x002C4382, 0x802C4382, 0xE60A1330},
                new float[]{0, .3f, 1}, Shader.TileMode.CLAMP));
        cv.drawRect(left, 800, right, bottom, p);
        p.setShader(null);
        p.setColor(0xFFFFD98A);
        p.setAlpha(60);
        rf.set(700, 874, 1220, 926);
        cv.drawOval(rf, p);
        p.setAlpha(90);
        rf.set(840, 888, 1080, 912);
        cv.drawOval(rf, p);
        cv.restore();
        if (fasting) {
            p.setColor(0x30000000);
            cv.drawRect(0, 0, w, h, p);
        }
    }
}
