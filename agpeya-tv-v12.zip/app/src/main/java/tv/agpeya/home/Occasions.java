package tv.agpeya.home;

import java.time.LocalDate;

/** Family occasions, shown as a gold ribbon on that day. {month, day, year, text, add the number of years?} */
final class Occasions {
    private Occasions() {}

    private static final Object[][] LIST = {
            {10, 20, 2025, "كل سنة وكيفين طيب · عمره ", true},
            {11, 23, 2022, "كل سنة وإيلينا طيبة · عمرها ", true},
            {1, 29, 2022, "كل سنة وإنتم طيبين · ذكرى زواجنا ", true},
            {3, 10, 1996, "كل سنة وتينا طيبة", false},
            {10, 1, 1997, "كل سنة وإنت طيب", false},
    };
    /** Short names for the countdown line, in the same order as LIST. */
    private static final String[] LABEL = {
            "عيد ميلاد كيفين", "عيد ميلاد إيلينا", "ذكرى زواجنا", "عيد ميلاد تينا", "مناسبة عائلية",
    };

    private static String daysWord(int n) {
        if (n == 1) return "غدًا";
        if (n == 2) return "بعد يومين";
        return "بعد " + Coptic.ar(n) + (n <= 10 ? " أيام" : " يومًا");
    }

    /**
     * The nearest coming family occasion or feast within 60 days, e.g. "عيد ميلاد إيلينا بعد ٢٨ يومًا".
     * Empty when there is nothing close. A family occasion wins a tie with a feast.
     */
    static String upcoming(LocalDate d) {
        int bestDays = 61;
        String best = "";
        for (int i = 0; i < LIST.length; i++) {
            Object[] o = LIST[i];
            LocalDate x = LocalDate.of(d.getYear(), (Integer) o[0], (Integer) o[1]);
            if (!x.isAfter(d)) x = x.plusYears(1);
            int n = (int) java.time.temporal.ChronoUnit.DAYS.between(d, x);
            if (n >= 1 && n < bestDays) {
                bestDays = n;
                best = LABEL[i] + " " + daysWord(n);
            }
        }
        for (int n = 1; n < bestDays && n <= 60; n++) {
            String f = Coptic.feast(d.plusDays(n));
            if (!f.isEmpty()) {
                best = f + " " + daysWord(n);
                break;
            }
        }
        return best;
    }

    private static String years(int n) {
        if (n == 1) return "سنة";
        if (n == 2) return "سنتين";
        if (n >= 3 && n <= 10) return Coptic.ar(n) + " سنين";
        return Coptic.ar(n) + " سنة";
    }

    static String today(LocalDate d) {
        for (Object[] o : LIST) {
            if ((Integer) o[0] == d.getMonthValue() && (Integer) o[1] == d.getDayOfMonth()) {
                String text = (String) o[3];
                int n = d.getYear() - (Integer) o[2];
                if ((Boolean) o[4] && n >= 1) return text + years(n);
                return text.trim();
            }
        }
        return "";
    }
}
