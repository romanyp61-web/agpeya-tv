package tv.agpeya.home;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Small custom views: countdown ring, progress bar, saint halo. */
final class Widgets {
    private Widgets() {}

    /** A ring that empties as the next prayer gets closer. */
    static final class Ring extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float value;

        Ring(Context c) {
            super(c);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        void set(float v) {
            float nv = Math.max(0f, Math.min(1f, v));
            if (Math.abs(nv - value) > 0.002f) {
                value = nv;
                invalidate();
            }
        }

        @Override
        protected void onDraw(Canvas cv) {
            float s = Math.min(getWidth(), getHeight());
            float sw = s * 0.07f;
            r.set(sw, sw, s - sw, s - sw);
            p.setStrokeWidth(sw);
            p.setColor(Ui.GOLD);
            p.setAlpha(55);
            cv.drawArc(r, 0, 360, false, p);
            p.setAlpha(255);
            cv.drawArc(r, -90, 360f * value, false, p);
        }
    }

    /** A thin bar, filled from the right (Arabic reading direction). */
    static final class Bar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float value;

        Bar(Context c) {
            super(c);
        }

        void set(float v) {
            value = Math.max(0f, Math.min(1f, v));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            p.setColor(Ui.GOLD);
            p.setAlpha(50);
            r.set(0, 0, w, h);
            cv.drawRoundRect(r, h / 2, h / 2, p);
            p.setAlpha(255);
            r.set(w * (1f - value), 0, w, h);
            cv.drawRoundRect(r, h / 2, h / 2, p);
        }
    }

    /** A glowing halo with a cross: the picture on the saint-of-the-day card. */
    static final class Halo extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Halo(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float s = Math.min(w, h), cx = w / 2f, cy = h / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, s / 2f, 0x99FFD98A, 0x00FFD98A, Shader.TileMode.CLAMP));
            cv.drawCircle(cx, cy, s / 2f, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, s * 0.05f));
            p.setColor(Ui.GOLD);
            cv.drawCircle(cx, cy, s * 0.36f, p);
            float a = s * 0.17f, t = s * 0.05f;
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Math.max(2f, s * 0.06f));
            cv.drawLine(cx, cy - a, cx, cy + a, p);
            cv.drawLine(cx - a, cy, cx + a, cy, p);
            cv.drawLine(cx - t, cy - a, cx + t, cy - a, p);
            cv.drawLine(cx - t, cy + a, cx + t, cy + a, p);
            cv.drawLine(cx - a, cy - t, cx - a, cy + t, p);
            cv.drawLine(cx + a, cy - t, cx + a, cy + t, p);
        }
    }

    /** Simple white pictures for the shortcut tiles. */
    static final class Glyph extends View {
        static final int MOON = 0, BOOK = 1, NOTE = 2, GEAR = 3, GRID = 4;
        private final int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path path = new android.graphics.Path();
        private final RectF r = new RectF();

        Glyph(Context c, int type) {
            super(c);
            this.type = type;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), s = Math.min(w, h), cx = w / 2f, cy = h / 2f;
            p.setColor(0xFFFFFFFF);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            switch (type) {
                case MOON: {
                    p.setStyle(Paint.Style.FILL);
                    path.reset();
                    path.addCircle(cx, cy, s * 0.30f, android.graphics.Path.Direction.CW);
                    android.graphics.Path cut = new android.graphics.Path();
                    cut.addCircle(cx + s * 0.16f, cy - s * 0.08f, s * 0.26f, android.graphics.Path.Direction.CW);
                    path.op(cut, android.graphics.Path.Op.DIFFERENCE);
                    cv.drawPath(path, p);
                    break;
                }
                case BOOK: {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(s * 0.07f);
                    r.set(cx - s * 0.32f, cy - s * 0.24f, cx - s * 0.02f, cy + s * 0.26f);
                    cv.drawRoundRect(r, s * 0.05f, s * 0.05f, p);
                    r.set(cx + s * 0.02f, cy - s * 0.24f, cx + s * 0.32f, cy + s * 0.26f);
                    cv.drawRoundRect(r, s * 0.05f, s * 0.05f, p);
                    cv.drawLine(cx - s * 0.24f, cy - s * 0.08f, cx - s * 0.10f, cy - s * 0.08f, p);
                    cv.drawLine(cx + s * 0.10f, cy - s * 0.08f, cx + s * 0.24f, cy - s * 0.08f, p);
                    break;
                }
                case NOTE: {
                    p.setStyle(Paint.Style.FILL);
                    cv.drawCircle(cx - s * 0.12f, cy + s * 0.20f, s * 0.12f, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(s * 0.08f);
                    cv.drawLine(cx - s * 0.02f, cy + s * 0.18f, cx - s * 0.02f, cy - s * 0.28f, p);
                    cv.drawLine(cx - s * 0.02f, cy - s * 0.28f, cx + s * 0.22f, cy - s * 0.16f, p);
                    break;
                }
                case GEAR: {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(s * 0.09f);
                    cv.drawCircle(cx, cy, s * 0.18f, p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI / 4 * i;
                        cv.drawLine(cx + (float) Math.cos(a) * s * 0.27f, cy + (float) Math.sin(a) * s * 0.27f,
                                cx + (float) Math.cos(a) * s * 0.36f, cy + (float) Math.sin(a) * s * 0.36f, p);
                    }
                    break;
                }
                default: {
                    p.setStyle(Paint.Style.FILL);
                    float g = s * 0.05f, q = s * 0.22f;
                    for (int i = 0; i < 2; i++) {
                        for (int j = 0; j < 2; j++) {
                            float x = cx - q - g + i * (q + 2 * g), y = cy - q - g + j * (q + 2 * g);
                            r.set(x, y, x + q, y + q);
                            cv.drawRoundRect(r, s * 0.04f, s * 0.04f, p);
                        }
                    }
                }
            }
        }
    }
}
