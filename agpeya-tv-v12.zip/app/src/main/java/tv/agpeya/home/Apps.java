package tv.agpeya.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The installed apps (name + real icon, straight from the TV) and the favourites list. */
final class Apps {
    private Apps() {}

    static final class App {
        String pkg;
        String label;
        Drawable icon;
    }

    private static final String[][] PREFERRED = {
            {"com.google.android.youtube.tv", "com.google.android.youtube"},
            {"net.mbc.shahidtv", "net.mbc.shahid"},
            {"com.google.android.youtube.tvmusic", "com.google.android.apps.youtube.music"},
            {"com.android.chrome", "com.google.android.apps.tv.launcherx.browser", "com.android.browser"},
    };

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("agpeya", Context.MODE_PRIVATE);
    }

    static List<App> list(Context c) {
        PackageManager pm = c.getPackageManager();
        Map<String, App> map = new LinkedHashMap<>();
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(c.getPackageName()) || map.containsKey(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.label = String.valueOf(ri.loadLabel(pm));
                a.icon = ri.loadIcon(pm);
                map.put(pkg, a);
            }
        }
        List<App> all = new ArrayList<>(map.values());
        Collections.sort(all, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return all;
    }

    static List<String> favoritePackages(Context c, List<App> all) {
        List<String> favs = new ArrayList<>();
        String saved = prefs(c).getString("fav", null);
        if (saved != null) {
            for (String p : saved.split(",")) if (!p.isEmpty()) favs.add(p);
            return favs;
        }
        for (String[] group : PREFERRED) {
            for (String p : group) {
                if (has(all, p) && !favs.contains(p)) {
                    favs.add(p);
                    break;
                }
            }
        }
        for (App a : all) {
            if (favs.size() >= 4) break;
            if (!favs.contains(a.pkg)) favs.add(a.pkg);
        }
        return favs;
    }

    private static boolean has(List<App> all, String pkg) {
        for (App a : all) if (a.pkg.equals(pkg)) return true;
        return false;
    }

    /** Adds or removes a favourite; returns true when it is now a favourite. */
    static boolean toggleFavorite(Context c, String pkg, List<App> all) {
        List<String> favs = favoritePackages(c, all);
        boolean now;
        if (favs.contains(pkg)) {
            favs.remove(pkg);
            now = false;
        } else {
            favs.add(pkg);
            now = true;
        }
        StringBuilder b = new StringBuilder();
        for (String p : favs) b.append(p).append(',');
        prefs(c).edit().putString("fav", b.toString()).apply();
        return now;
    }

    static void launch(Context c, String pkg) {
        PackageManager pm = c.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) {
            Toast.makeText(c, "تعذّر فتح التطبيق", Toast.LENGTH_SHORT).show();
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }
}
