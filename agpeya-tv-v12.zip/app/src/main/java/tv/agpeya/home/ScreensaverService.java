package tv.agpeya.home;

import android.os.Handler;
import android.os.Looper;
import android.service.dreams.DreamService;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Random;

/** Screen saver: cross, the day's verse, the time, and the blessing. Drifts slowly so no pixel burns in. */
public class ScreensaverService extends DreamService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private FrameLayout root;
    private LinearLayout box;
    private TextView clock, date;
    private int tickCount;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            LocalDateTime now = LocalDateTime.now();
            int h = now.getHour(), m = now.getMinute();
            int h12 = h % 12 == 0 ? 12 : h % 12;
            clock.setText(Coptic.ar(h12 + ":" + (m < 10 ? "0" : "") + m) + (h < 12 ? " ص" : " م"));
            date.setText(Coptic.dateLine(now.toLocalDate()));
            if (tickCount++ % 60 == 0) drift();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        setScreenBright(false);
        build();
        setContentView(root);
    }

    @Override
    public void onDreamingStarted() {
        super.onDreamingStarted();
        tickCount = 0;
        handler.post(tick);
    }

    @Override
    public void onDreamingStopped() {
        handler.removeCallbacks(tick);
        super.onDreamingStopped();
    }

    private void drift() {
        float dx = (rnd.nextFloat() - 0.5f) * root.getWidth() * 0.12f;
        float dy = (rnd.nextFloat() - 0.5f) * root.getHeight() * 0.12f;
        box.animate().translationX(dx).translationY(dy).setDuration(4000).start();
    }

    private void build() {
        android.content.Context c = this;
        Ui.init(c);
        root = new FrameLayout(c);
        root.setBackgroundColor(0xFF000000);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        box.addView(new CrossView(c), Ui.lp(c, 80, 80));
        Ui.gap(c, box, 28);

        String[] v = Verses.today(LocalDate.now());
        TextView verse = Ui.text(c, v[0], 58, Ui.CREAM, Ui.amiri(c));
        verse.setGravity(Gravity.CENTER);
        verse.setLineSpacing(0, 1.25f);
        box.addView(verse, Ui.lp(c, 1400, Ui.WRAP));
        Ui.gap(c, box, 10);
        TextView ref = Ui.text(c, v[1], 26, Ui.MUTED, Ui.alex(c));
        ref.setGravity(Gravity.CENTER);
        box.addView(ref, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        Ui.gap(c, box, 50);

        clock = Ui.text(c, "", 110, Ui.GOLD, Ui.alexBold(c));
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        clock.setGravity(Gravity.CENTER);
        box.addView(clock, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        date = Ui.text(c, "", 30, Ui.MUTED, Ui.alex(c));
        date.setGravity(Gravity.CENTER);
        box.addView(date, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        Ui.gap(c, box, 50);

        TextView bless = Ui.text(c, "بارِك يا رب هذا البيت نهارًا وليلًا", 44, Ui.GOLD, Ui.amiriBold(c));
        bless.setGravity(Gravity.CENTER);
        box.addView(bless, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        TextView names = Ui.text(c, "إيلينا وكيفين", 40, Ui.CREAM, Ui.amiriBold(c));
        names.setGravity(Gravity.CENTER);
        box.addView(names, Ui.lp(c, Ui.WRAP, Ui.WRAP));

        root.addView(box, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
    }
}
