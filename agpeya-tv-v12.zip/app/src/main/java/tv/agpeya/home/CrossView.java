package tv.agpeya.home;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** A small Coptic-style cross drawn in gold. */
final class CrossView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    CrossView(Context c) {
        super(c);
        p.setColor(Ui.GOLD);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    void tint(int color) {
        p.setColor(color);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h);
        float cx = w / 2f, cy = h / 2f, a = s * 0.40f, t = s * 0.10f;
        p.setStrokeWidth(Math.max(2f, s * 0.07f));
        canvas.drawLine(cx, cy - a, cx, cy + a, p);
        canvas.drawLine(cx - a, cy, cx + a, cy, p);
        canvas.drawLine(cx - t, cy - a, cx + t, cy - a, p);
        canvas.drawLine(cx - t, cy + a, cx + t, cy + a, p);
        canvas.drawLine(cx - a, cy - t, cx - a, cy + t, p);
        canvas.drawLine(cx + a, cy - t, cx + a, cy + t, p);
        canvas.drawCircle(cx, cy, s * 0.09f, p);
    }
}
