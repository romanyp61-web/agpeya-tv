# Notices

- Build scaffolding (Gradle wrapper, AGP settings) and the fonts are taken from Afnon,
  https://github.com/egyjs/afnon-android-tv-launcher (MIT licence, (c) its authors).
- Fonts: Amiri (Khaled Hosny) and Alexandria (Mohamed Gaber, Julieta Ulanovsky), SIL Open Font Licence 1.1.
- Readings and synaxarium titles: from the Katameros PDF for the month of Babah (St. Bishoy Church, Canada) and CopticChurch.net.
- Agpeya texts (assets/agpeya/h0-h6.txt): from the St-Takla.org Word files supplied by the user (Arabic Agpeya, St-Takla.org). Please keep this credit.
