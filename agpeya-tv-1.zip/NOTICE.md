# Notices

- Build scaffolding (Gradle wrapper, AGP settings) and the fonts are taken from Afnon,
  https://github.com/egyjs/afnon-android-tv-launcher (MIT licence, (c) its authors).
- Fonts: Amiri (Khaled Hosny) and Alexandria (Mohamed Gaber, Julieta Ulanovsky), SIL Open Font Licence 1.1.
- Readings and synaxarium titles: from the Katameros PDF for the month of Babah (St. Bishoy Church, Canada) and CopticChurch.net.
