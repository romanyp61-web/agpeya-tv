package tv.agpeya.home;

import java.time.DayOfWeek;
import java.time.LocalDate;

/** The Coptic calendar, worked out on the device (no internet), plus the fasts of the Coptic year. */
final class Coptic {
    private Coptic() {}

    static final String[] MONTHS = {"توت", "بابة", "هاتور", "كيهك", "طوبة", "أمشير", "برمهات",
            "برمودة", "بشنس", "بؤونة", "أبيب", "مسرى", "النسيء"};
    static final String[] GREG = {"يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو",
            "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"};
    /** Index 0 = Monday, matching DayOfWeek.getValue() - 1. */
    static final String[] DAYS = {"الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"};

    /** Western digits to Arabic-Indic digits. */
    static String ar(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            b.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        }
        return b.toString();
    }

    static String ar(long n) {
        return ar(Long.toString(n));
    }

    /** Julian day number of a Gregorian date. */
    private static long jdn(LocalDate d) {
        int a = (14 - d.getMonthValue()) / 12;
        long y = d.getYear() + 4800L - a;
        int m = d.getMonthValue() + 12 * a - 3;
        return d.getDayOfMonth() + (153L * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
    }

    /** {year, month 1-13, day} of the Coptic date. */
    static int[] of(LocalDate date) {
        long c = jdn(date) - 1825030L; // 1 Thout, year 1 = day 0
        // A 4-year cycle is 1461 days: years of 365, 365, 366 (the leap year, 6 Nasie days) and 365.
        long r = c % 1461;
        long inCycle = r < 730 ? r / 365 : (r < 1096 ? 2 : 3);
        long year = (c / 1461) * 4 + inCycle + 1;
        long doy = c - (365 * (year - 1) + year / 4);
        return new int[]{(int) year, (int) (doy / 30) + 1, (int) (doy % 30) + 1};
    }

    static String dateLine(LocalDate d) {
        int[] c = of(d);
        return DAYS[d.getDayOfWeek().getValue() - 1] + " " + ar(c[2]) + " " + MONTHS[c[1] - 1]
                + " " + ar(c[0]) + " للشهداء";
    }

    static String gregorianLine(LocalDate d) {
        return ar(d.getDayOfMonth()) + " " + GREG[d.getMonthValue() - 1] + " " + ar(d.getYear());
    }

    /** Easter of the Orthodox churches (the Coptic Church keeps the same date) as a Gregorian date. */
    static LocalDate easter(int year) {
        int a = year % 4, b = year % 7, c = year % 19;
        int d = (19 * c + 15) % 30;
        int e = (2 * a + 4 * b - d + 34) % 7;
        int month = (d + e + 114) / 31;
        int day = (d + e + 114) % 31 + 1;
        return LocalDate.of(year, month, day).plusDays(13); // Julian to Gregorian, 1900-2099
    }

    /** The feast of the day (fixed and moving), or "". */
    static String feast(LocalDate d) {
        int[] c = of(d);
        int m = c[1], day = c[2];
        long off = d.toEpochDay() - easter(d.getYear()).toEpochDay();
        if (off == 0) return "عيد القيامة المجيد";
        if (off == -7) return "أحد الشعانين";
        if (off == -3) return "خميس العهد";
        if (off == -2) return "الجمعة العظيمة";
        if (off == -1) return "سبت النور";
        if (off == 7) return "أحد توما";
        if (off == 39) return "عيد الصعود المجيد";
        if (off == 49) return "عيد العنصرة";
        if (m == 1 && day == 1) return "عيد النيروز (رأس السنة القبطية)";
        if (m == 1 && day == 17) return "عيد الصليب المجيد";
        if (m == 4 && day == 28) return "برمون الميلاد";
        if (m == 4 && day == 29) return "عيد الميلاد المجيد";
        if (m == 5 && day == 6) return "عيد الختان";
        if (m == 5 && day == 10) return "برمون الغطاس";
        if (m == 5 && day == 11) return "عيد الغطاس المجيد";
        if (m == 5 && day == 13) return "عرس قانا الجليل";
        if (m == 6 && day == 8) return "دخول المسيح الهيكل";
        if (m == 7 && day == 29) return "عيد البشارة";
        if (m == 9 && day == 24) return "دخول العائلة المقدسة أرض مصر";
        if (m == 12 && day == 13) return "عيد التجلي";
        if (m == 12 && day == 16) return "صعود جسد السيدة العذراء";
        return "";
    }

    /** The big fasts only, or null. */
    static String majorFast(LocalDate d) {
        LocalDate easter = easter(d.getYear());
        int[] c = of(d);
        int cm = c[1], cd = c[2];
        if (!d.isBefore(easter.minusDays(69)) && !d.isAfter(easter.minusDays(67))) return "صوم يونان";
        if (!d.isBefore(easter.minusDays(55)) && d.isBefore(easter)) return "الصوم الكبير";
        if (!d.isBefore(easter.plusDays(50)) && d.getMonthValue() <= 7 && (cm < 11 || (cm == 11 && cd <= 4)))
            return "صوم الرسل";
        if (cm == 12 && cd <= 15) return "صوم السيدة العذراء";
        if ((cm == 3 && cd >= 16) || (cm == 4 && cd <= 28)) return "صوم الميلاد";
        return null;
    }

    /** What to say about today's fasting; "" for an ordinary day. */
    static String fastToday(LocalDate d) {
        String major = majorFast(d);
        if (major != null) return major;
        LocalDate easter = easter(d.getYear());
        boolean pentecost = !d.isBefore(easter) && !d.isAfter(easter.plusDays(49));
        DayOfWeek w = d.getDayOfWeek();
        if (!pentecost && w == DayOfWeek.WEDNESDAY) return "صوم الأربعاء";
        if (!pentecost && w == DayOfWeek.FRIDAY) return "صوم الجمعة";
        return "";
    }

    /** "صوم الميلاد بعد ٣٢ يومًا", looking for the start of the next big fast. */
    static String nextFast(LocalDate d) {
        for (int i = 1; i <= 400; i++) {
            LocalDate x = d.plusDays(i);
            String f = majorFast(x);
            if (f != null && majorFast(x.minusDays(1)) == null) {
                if (i == 1) return f + " غدًا";
                if (i == 2) return f + " بعد يومين";
                return f + " بعد " + ar(i) + (i <= 10 ? " أيام" : " يومًا");
            }
        }
        return "";
    }
}
