package tv.agpeya.home;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

/** Small helpers so the screens can be written once at 1920x1080 and scale to any TV. */
final class Ui {
    private Ui() {}

    static final int NAVY = 0xFF0C1B33;
    static final int PANEL = 0xFF13264A;
    static final int PANEL2 = 0xFF0F2243;
    static final int LINE = 0xFF243A63;
    static final int GOLD = 0xFFD4AF6A;
    static final int CREAM = 0xFFF3ECDD;
    static final int MUTED = 0xFFA9B8D3;
    static final int SOFT = 0xFFD9E1F0;
    static final int FOCUS = 0xFF1C3763;
    static final int INK = 0xFF0C1B33;

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static Typeface amiri, amiriBold, alex, alexBold;

    private static float fontScale = -1f;

    /** 1.0 normally, 1.15 when "big text" is on in Settings. */
    static float fontScale(Context c) {
        if (fontScale < 0)
            fontScale = c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getBoolean("big", false) ? 1.15f : 1f;
        return fontScale;
    }

    static boolean isBig(Context c) {
        return fontScale(c) > 1f;
    }

    static void setBig(Context c, boolean big) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putBoolean("big", big).apply();
        fontScale = big ? 1.15f : 1f;
    }

    /** 1.0 on a 1920 px wide screen. */
    static float k(Context c) {
        return Math.max(0.5f, c.getResources().getDisplayMetrics().widthPixels / 1920f);
    }

    static int px(Context c, float v) {
        return Math.round(v * k(c));
    }

    /** Design pixels to real pixels, but MATCH/WRAP (negative) pass through. */
    static int d(Context c, float v) {
        return v < 0 ? (int) v : px(c, v);
    }

    static Typeface amiri(Context c) {
        if (amiri == null) amiri = c.getResources().getFont(R.font.amiri_regular);
        return amiri;
    }

    static Typeface amiriBold(Context c) {
        if (amiriBold == null) amiriBold = c.getResources().getFont(R.font.amiri_bold);
        return amiriBold;
    }

    static Typeface alex(Context c) {
        if (alex == null) alex = c.getResources().getFont(R.font.alexandria_regular);
        return alex;
    }

    static Typeface alexBold(Context c) {
        if (alexBold == null) alexBold = c.getResources().getFont(R.font.alexandria_semibold);
        return alexBold;
    }

    static GradientDrawable rect(Context c, int fill, int stroke, float strokeW, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(px(c, radius));
        if (strokeW > 0) g.setStroke(Math.max(1, px(c, strokeW)), stroke);
        return g;
    }

    /** Tile background: plain at rest, bright gold edge when the remote focuses it. */
    static StateListDrawable tile(Context c, int fill, int line, float radius) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, rect(c, FOCUS, GOLD, 4, radius));
        s.addState(new int[]{}, rect(c, fill, line, 1, radius));
        return s;
    }

    static TextView text(Context c, String s, float size, int color, Typeface tf) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTypeface(tf);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * k(c) * fontScale(c));
        return t;
    }

    static LinearLayout.LayoutParams lp(Context c, float w, float h) {
        return new LinearLayout.LayoutParams(d(c, w), d(c, h));
    }

    static LinearLayout.LayoutParams lpw(Context c, float w, float h, float weight) {
        return new LinearLayout.LayoutParams(d(c, w), d(c, h), weight);
    }

    /** A fixed gap between siblings. */
    static void gap(Context c, LinearLayout parent, float size) {
        Space sp = new Space(c);
        boolean horizontal = parent.getOrientation() == LinearLayout.HORIZONTAL;
        parent.addView(sp, horizontal ? lp(c, size, 1) : lp(c, 1, size));
    }

    /** Makes a view a remote-friendly button: focusable, clickable, grows a little when focused. */
    static void button(View v, android.graphics.drawable.Drawable bg) {
        v.setFocusable(true);
        v.setClickable(true);
        v.setBackground(bg);
        v.setOnFocusChangeListener((view, has) ->
                view.animate().scaleX(has ? 1.04f : 1f).scaleY(has ? 1.04f : 1f).setDuration(120).start());
    }

    static void setIfChanged(TextView t, String s) {
        if (!s.contentEquals(t.getText())) t.setText(s);
    }
}
