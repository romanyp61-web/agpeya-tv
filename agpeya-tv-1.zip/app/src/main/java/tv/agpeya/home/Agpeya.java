package tv.agpeya.home;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/** The seven hours of the Agpeya. The times are traditional and fixed; each one can be moved in Settings. */
final class Agpeya {
    private Agpeya() {}

    static final String[] NAMES = {"نصف الليل", "باكر", "الثالثة", "السادسة", "التاسعة", "الغروب", "النوم"};
    /** Minutes after midnight. */
    static final int[] DEFAULT = {0, 6 * 60, 9 * 60, 12 * 60, 15 * 60, 17 * 60, 21 * 60};

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("agpeya", Context.MODE_PRIVATE);
    }

    static int minutes(Context c, int i) {
        return prefs(c).getInt("h" + i, DEFAULT[i]);
    }

    static void set(Context c, int i, int minutes) {
        int m = ((minutes % 1440) + 1440) % 1440;
        prefs(c).edit().putInt("h" + i, m).apply();
    }

    static void reset(Context c) {
        SharedPreferences.Editor e = prefs(c).edit();
        for (int i = 0; i < DEFAULT.length; i++) e.remove("h" + i);
        e.apply();
    }

    /** "٦:٠٠ ص" */
    static String clock(int minutes) {
        int h = minutes / 60, m = minutes % 60;
        String suffix = h < 12 ? "ص" : "م";
        int h12 = h % 12 == 0 ? 12 : h % 12;
        return Coptic.ar(h12 + ":" + (m < 10 ? "0" : "") + m) + " " + suffix;
    }

    /** Index of the next hour after nowSec (seconds after midnight), wrapping to tomorrow. */
    static int next(Context c, int nowSec) {
        int best = 0, bestDelta = Integer.MAX_VALUE;
        for (int i = 0; i < NAMES.length; i++) {
            int delta = minutes(c, i) * 60 - nowSec;
            if (delta <= 0) delta += 86400;
            if (delta < bestDelta) {
                bestDelta = delta;
                best = i;
            }
        }
        return best;
    }

    /** Seconds until hour i, counting from nowSec. */
    static int secondsUntil(Context c, int i, int nowSec) {
        int delta = minutes(c, i) * 60 - nowSec;
        if (delta <= 0) delta += 86400;
        return delta;
    }

    /** "٠٤:٢٥:٠٠" */
    static String countdown(int seconds) {
        int h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        return Coptic.ar(String.format(Locale.ROOT, "%02d:%02d:%02d", h, m, s));
    }
}
