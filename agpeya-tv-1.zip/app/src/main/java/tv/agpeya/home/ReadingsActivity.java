package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.time.DayOfWeek;
import java.time.LocalDate;

/** Today's readings and the synaxarium in full. */
public class ReadingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        View root = build();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);
    }

    private View build() {
        Context c = this;
        LocalDate today = LocalDate.now();
        int[] cd = Coptic.of(today);
        JSONObject day = Readings.day(c, cd[1], cd[2]);
        boolean sunday = today.getDayOfWeek() == DayOfWeek.SUNDAY;

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.NAVY);
        root.setPadding(Ui.px(c, 64), Ui.px(c, 48), Ui.px(c, 64), Ui.px(c, 48));

        // header
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(c);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(Ui.text(c, "قراءات اليوم", 68, Ui.GOLD, Ui.amiriBold(c)));
        titles.addView(Ui.text(c, Coptic.dateLine(today) + " · " + Coptic.gregorianLine(today), 26, Ui.MUTED, Ui.alex(c)));
        head.addView(titles, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        head.addView(new View(c), Ui.lpw(c, 1, 1, 1f));
        TextView back = Ui.text(c, "رجوع", 24, Ui.GOLD, Ui.alexBold(c));
        back.setGravity(Gravity.CENTER);
        back.setPadding(Ui.px(c, 40), 0, Ui.px(c, 40), 0);
        Ui.button(back, Ui.tile(c, 0x00000000, Ui.GOLD, 40));
        back.setOnClickListener(v -> finish());
        head.addView(back, Ui.lp(c, Ui.WRAP, 60));
        root.addView(head, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, root, 26);

        LinearLayout body = new LinearLayout(c);
        body.setOrientation(LinearLayout.HORIZONTAL);

        // readings grid (right side)
        LinearLayout grid = new LinearLayout(c);
        grid.setOrientation(LinearLayout.VERTICAL);
        if (day == null || sunday) {
            String msg = day == null
                    ? "قراءات هذا الشهر غير مضافة في هذه النسخة."
                    : "اليوم أحد: قراءات الأحد غير مضافة في هذه النسخة.";
            TextView t = Ui.text(c, msg, 34, Ui.CREAM, Ui.amiriBold(c));
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.px(c, 30), Ui.px(c, 30), Ui.px(c, 30), Ui.px(c, 30));
            t.setBackground(Ui.rect(c, Ui.PANEL, Ui.LINE, 1, 22));
            grid.addView(t, Ui.lpw(c, Ui.MATCH, 0, 1f));
        } else {
            addRow(grid, card("عشية", Readings.get(day, "vp"), Readings.get(day, "vg")),
                    card("باكر", Readings.get(day, "mp"), Readings.get(day, "mg")));
            Ui.gap(c, grid, 14);
            addRow(grid, card("البولس", Readings.get(day, "pa"), null),
                    card("الكاثوليكون", Readings.get(day, "ca"), null));
            Ui.gap(c, grid, 14);
            addRow(grid, card("الإبركسيس", Readings.get(day, "ac"), null),
                    card("مزمور القدّاس", Readings.get(day, "lp"), null));
        }
        body.addView(grid, Ui.lpw(c, 0, Ui.MATCH, 1.25f));
        Ui.gap(c, body, 22);

        // gospel + synaxarium (left side)
        LinearLayout side = new LinearLayout(c);
        side.setOrientation(LinearLayout.VERTICAL);
        if (day != null && !sunday) {
            LinearLayout gospel = new LinearLayout(c);
            gospel.setOrientation(LinearLayout.VERTICAL);
            gospel.setGravity(Gravity.CENTER_VERTICAL);
            gospel.setPadding(Ui.px(c, 32), Ui.px(c, 20), Ui.px(c, 32), Ui.px(c, 20));
            gospel.setBackground(Ui.rect(c, Ui.CREAM, Ui.GOLD, 2, 24));
            gospel.addView(Ui.text(c, "إنجيل القدّاس", 24, 0xFF7A5A1E, Ui.alexBold(c)));
            TextView g = Ui.text(c, Readings.get(day, "lg"), 56, Ui.INK, Ui.amiriBold(c));
            gospel.addView(g);
            side.addView(gospel, Ui.lpw(c, Ui.MATCH, 0, 1f));
            Ui.gap(c, side, 14);
        }
        LinearLayout syn = new LinearLayout(c);
        syn.setOrientation(LinearLayout.VERTICAL);
        syn.setGravity(Gravity.CENTER_VERTICAL);
        syn.setPadding(Ui.px(c, 32), Ui.px(c, 20), Ui.px(c, 32), Ui.px(c, 20));
        syn.setBackground(Ui.rect(c, Ui.PANEL2, Ui.LINE, 1, 24));
        syn.addView(Ui.text(c, "سنكسار " + Coptic.ar(cd[2]) + " " + Coptic.MONTHS[cd[1] - 1], 22, Ui.GOLD, Ui.alexBold(c)));
        String[] list = Readings.titles(day);
        if (list.length == 0) {
            syn.addView(Ui.text(c, "غير مضاف لهذا الشهر", 30, Ui.CREAM, Ui.amiriBold(c)));
        } else {
            for (String s : list) {
                TextView t = Ui.text(c, "• " + s, list.length > 2 ? 28 : 34, Ui.CREAM, Ui.amiriBold(c));
                t.setPadding(0, Ui.px(c, 6), 0, 0);
                syn.addView(t);
            }
        }
        side.addView(syn, Ui.lpw(c, Ui.MATCH, 0, 1.3f));
        body.addView(side, Ui.lpw(c, 0, Ui.MATCH, 1f));

        root.addView(body, Ui.lpw(c, Ui.MATCH, 0, 1f));
        back.post(back::requestFocus);
        return root;
    }

    private void addRow(LinearLayout grid, View a, View b) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(a, Ui.lpw(this, 0, Ui.MATCH, 1f));
        Ui.gap(this, row, 14);
        row.addView(b, Ui.lpw(this, 0, Ui.MATCH, 1f));
        grid.addView(row, Ui.lpw(this, Ui.MATCH, 0, 1f));
    }

    private View card(String label, String line1, String line2) {
        Context c = this;
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setPadding(Ui.px(c, 26), Ui.px(c, 14), Ui.px(c, 26), Ui.px(c, 14));
        l.setBackground(Ui.rect(c, Ui.PANEL, Ui.LINE, 1, 20));
        l.addView(Ui.text(c, label, 22, Ui.GOLD, Ui.alexBold(c)));
        l.addView(Ui.text(c, line1, line2 == null ? 34 : 30, Ui.CREAM, Ui.alexBold(c)));
        if (line2 != null) l.addView(Ui.text(c, line2, 30, Ui.CREAM, Ui.alexBold(c)));
        return l;
    }
}
