package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** The home screen: next Agpeya hour in the arch, the seven hours, today's fast/saint/readings, apps. */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView clock, ampm, copticLine, gregLine;
    private TextView archName, archCount, archSub;
    private final TextView[] hName = new TextView[7];
    private final TextView[] hTime = new TextView[7];
    private final TextView[] hTag = new TextView[7];
    private final LinearLayout[] hTile = new LinearLayout[7];
    private TextView fastLabel, fast1, fast2, synLabel, syn1, syn2, readLabel, read1, read2;
    private LinearLayout favRow, moreRow, favBlock, moreBlock;

    private int shownNext = -1;
    private String shownDay = "";
    private View firstFocus;
    private View archBtn;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        View root = buildRoot();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshApps();
        shownDay = "";
        shownNext = -1;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home pressed while already here: back to the start.
        if (firstFocus != null) firstFocus.requestFocus();
    }

    @Override
    public void onBackPressed() {
        // This is the home screen; there is nowhere to go back to.
    }

    // ---------------------------------------------------------------- layout

    private View buildRoot() {
        Context c = this;
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Ui.NAVY);
        root.setPadding(Ui.px(c, 64), Ui.px(c, 52), Ui.px(c, 64), Ui.px(c, 52));

        root.addView(buildArch(), Ui.lp(c, 560, Ui.MATCH));
        Ui.gap(c, root, 52);
        root.addView(buildContent(), Ui.lpw(c, 0, Ui.MATCH, 1f));
        return root;
    }

    private View buildArch() {
        Context c = this;
        LinearLayout arch = new LinearLayout(c);
        arch.setOrientation(LinearLayout.VERTICAL);
        arch.setGravity(Gravity.CENTER_HORIZONTAL);
        arch.setPadding(Ui.px(c, 40), Ui.px(c, 54), Ui.px(c, 40), Ui.px(c, 38));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF12264A);
        g.setStroke(Math.max(2, Ui.px(c, 2)), Ui.GOLD);
        float top = Ui.px(c, 280), bottom = Ui.px(c, 28);
        g.setCornerRadii(new float[]{top, top, top, top, bottom, bottom, bottom, bottom});
        arch.setBackground(g);

        CrossView cross = new CrossView(c);
        arch.addView(cross, Ui.lp(c, 60, 60));
        Ui.gap(c, arch, 14);

        TextView verse = Ui.text(c, "سَبْعَ مَرَّاتٍ فِي النَّهَارِ\nسَبَّحْتُكَ عَلَى أَحْكَامِ عَدْلِكَ",
                34, Ui.CREAM, Ui.amiri(c));
        verse.setGravity(Gravity.CENTER);
        verse.setLineSpacing(0, 1.2f);
        arch.addView(verse, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, arch, 8);
        TextView ref = Ui.text(c, "مزمور ١١٨: ١٦٤", 22, Ui.MUTED, Ui.alex(c));
        ref.setGravity(Gravity.CENTER);
        arch.addView(ref, Ui.lp(c, Ui.MATCH, Ui.WRAP));

        arch.addView(new View(c), Ui.lpw(c, 1, 0, 1f));

        TextView label = Ui.text(c, "الصلاة القادمة", 24, Ui.MUTED, Ui.alex(c));
        label.setGravity(Gravity.CENTER);
        arch.addView(label, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        archName = Ui.text(c, "", 76, Ui.GOLD, Ui.amiriBold(c));
        archName.setGravity(Gravity.CENTER);
        arch.addView(archName, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        archCount = Ui.text(c, "", 84, Ui.CREAM, Ui.alexBold(c));
        archCount.setGravity(Gravity.CENTER);
        archCount.setTextDirection(View.TEXT_DIRECTION_LTR);
        arch.addView(archCount, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        archSub = Ui.text(c, "", 24, Ui.MUTED, Ui.alex(c));
        archSub.setGravity(Gravity.CENTER);
        arch.addView(archSub, Ui.lp(c, Ui.MATCH, Ui.WRAP));

        arch.addView(new View(c), Ui.lpw(c, 1, 0, 1f));

        TextView btn = Ui.text(c, "قراءات اليوم والسنكسار", 24, Ui.GOLD, Ui.alexBold(c));
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(Ui.px(c, 36), 0, Ui.px(c, 36), 0);
        Ui.button(btn, Ui.tile(c, 0x00000000, Ui.GOLD, 40));
        btn.setOnClickListener(v -> startActivity(new Intent(this, ReadingsActivity.class)));
        arch.addView(btn, Ui.lp(c, Ui.WRAP, 64));
        archBtn = btn;
        firstFocus = btn;
        return arch;
    }

    private View buildContent() {
        Context c = this;
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);

        // header: time and dates, settings button
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout timeBlock = new LinearLayout(c);
        timeBlock.setOrientation(LinearLayout.VERTICAL);
        LinearLayout timeRow = new LinearLayout(c);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        timeRow.setGravity(Gravity.BOTTOM);
        clock = Ui.text(c, "", 92, Ui.CREAM, Ui.alexBold(c));
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        timeRow.addView(clock, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        Ui.gap(c, timeRow, 14);
        ampm = Ui.text(c, "", 32, Ui.MUTED, Ui.alex(c));
        timeRow.addView(ampm, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        timeBlock.addView(timeRow, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        copticLine = Ui.text(c, "", 28, Ui.GOLD, Ui.alexBold(c));
        timeBlock.addView(copticLine, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        gregLine = Ui.text(c, "", 22, Ui.MUTED, Ui.alex(c));
        timeBlock.addView(gregLine, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        head.addView(timeBlock, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        head.addView(new View(c), Ui.lpw(c, 1, 1, 1f));
        TextView settings = Ui.text(c, "الإعدادات", 22, Ui.CREAM, Ui.alex(c));
        settings.setGravity(Gravity.CENTER);
        settings.setPadding(Ui.px(c, 28), 0, Ui.px(c, 28), 0);
        Ui.button(settings, Ui.tile(c, Ui.PANEL, 0xFF2A4270, 40));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        head.addView(settings, Ui.lp(c, Ui.WRAP, 56));
        col.addView(head, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, col, 18);

        // the seven hours
        LinearLayout hours = new LinearLayout(c);
        hours.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            LinearLayout t = new LinearLayout(c);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setGravity(Gravity.BOTTOM);
            t.setPadding(Ui.px(c, 12), Ui.px(c, 10), Ui.px(c, 12), Ui.px(c, 12));
            hTag[i] = Ui.text(c, "التالية", 18, 0xFF7A5A1E, Ui.alexBold(c));
            hName[i] = Ui.text(c, Agpeya.NAMES[i], 25, Ui.CREAM, Ui.alexBold(c));
            hName[i].setSingleLine(true);
            hTime[i] = Ui.text(c, "", 22, Ui.MUTED, Ui.alex(c));
            t.addView(hTag[i], Ui.lp(c, Ui.WRAP, Ui.WRAP));
            t.addView(hName[i], Ui.lp(c, Ui.WRAP, Ui.WRAP));
            t.addView(hTime[i], Ui.lp(c, Ui.WRAP, Ui.WRAP));
            hTile[i] = t;
            hours.addView(t, Ui.lpw(c, 0, 128, 1f));
            if (i < 6) Ui.gap(c, hours, 10);
        }
        col.addView(hours, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, col, 14);

        // today: fast, saint, readings
        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout fastCard = card();
        fastLabel = Ui.text(c, "الصوم", 20, Ui.GOLD, Ui.alexBold(c));
        fast1 = Ui.text(c, "", 24, Ui.CREAM, Ui.alexBold(c));
        fast2 = Ui.text(c, "", 20, Ui.MUTED, Ui.alex(c));
        fastCard.addView(fastLabel);
        fastCard.addView(fast1);
        fastCard.addView(fast2);
        LinearLayout synCard = card();
        synLabel = Ui.text(c, "السنكسار", 20, Ui.GOLD, Ui.alexBold(c));
        syn1 = Ui.text(c, "", 22, Ui.CREAM, Ui.alexBold(c));
        syn1.setMaxLines(2);
        syn1.setEllipsize(TextUtils.TruncateAt.END);
        syn2 = Ui.text(c, "", 20, Ui.MUTED, Ui.alex(c));
        synCard.addView(synLabel);
        synCard.addView(syn1);
        synCard.addView(syn2);
        LinearLayout readCard = card();
        readLabel = Ui.text(c, "قراءات اليوم", 20, Ui.GOLD, Ui.alexBold(c));
        read1 = Ui.text(c, "", 22, Ui.CREAM, Ui.alexBold(c));
        read1.setSingleLine(true);
        read1.setEllipsize(TextUtils.TruncateAt.END);
        read2 = Ui.text(c, "", 20, Ui.MUTED, Ui.alex(c));
        read2.setSingleLine(true);
        read2.setEllipsize(TextUtils.TruncateAt.END);
        readCard.addView(readLabel);
        readCard.addView(read1);
        readCard.addView(read2);
        for (LinearLayout cd : new LinearLayout[]{synCard, readCard}) {
            Ui.button(cd, Ui.tile(c, Ui.PANEL2, Ui.LINE, 18));
            cd.setOnClickListener(v -> startActivity(new Intent(this, ReadingsActivity.class)));
        }
        info.addView(fastCard, Ui.lpw(c, 0, 128, 1f));
        Ui.gap(c, info, 12);
        info.addView(synCard, Ui.lpw(c, 0, 128, 1f));
        Ui.gap(c, info, 12);
        info.addView(readCard, Ui.lpw(c, 0, 128, 1f));
        col.addView(info, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, col, 14);

        // apps
        favBlock = new LinearLayout(c);
        favBlock.setOrientation(LinearLayout.VERTICAL);
        favBlock.addView(Ui.text(c, "المفضلة", 20, Ui.MUTED, Ui.alex(c)));
        Ui.gap(c, favBlock, 6);
        favRow = new LinearLayout(c);
        favRow.setOrientation(LinearLayout.HORIZONTAL);
        favBlock.addView(favRow, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        col.addView(favBlock, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, col, 10);

        moreBlock = new LinearLayout(c);
        moreBlock.setOrientation(LinearLayout.VERTICAL);
        moreBlock.addView(Ui.text(c, "المزيد", 20, Ui.MUTED, Ui.alex(c)));
        Ui.gap(c, moreBlock, 6);
        moreRow = new LinearLayout(c);
        moreRow.setOrientation(LinearLayout.HORIZONTAL);
        moreBlock.addView(moreRow, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        col.addView(moreBlock, Ui.lp(c, Ui.MATCH, Ui.WRAP));

        col.addView(new View(c), Ui.lpw(c, 1, 0, 1f));
        col.addView(buildFooter(), Ui.lp(c, Ui.MATCH, Ui.WRAP));
        return col;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setPadding(Ui.px(this, 20), Ui.px(this, 10), Ui.px(this, 20), Ui.px(this, 10));
        l.setBackground(Ui.rect(this, Ui.PANEL2, Ui.LINE, 1, 18));
        return l;
    }

    private View buildFooter() {
        Context c = this;
        LinearLayout f = new LinearLayout(c);
        f.setOrientation(LinearLayout.HORIZONTAL);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(Ui.px(c, 32), Ui.px(c, 10), Ui.px(c, 32), Ui.px(c, 10));
        f.setBackground(Ui.rect(c, Ui.PANEL2, Ui.GOLD, 1, 20));

        LinearLayout text = new LinearLayout(c);
        text.setOrientation(LinearLayout.VERTICAL);
        TextView bless = Ui.text(c, "بارِك يا رب هذا البيت نهارًا وليلًا", 38, Ui.GOLD, Ui.amiriBold(c));
        text.addView(bless, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        TextView verse = Ui.text(c, "«لتكن عيناك مفتوحتين على هذا البيت ليلًا ونهارًا» · الملوك الأول ٨: ٢٩",
                21, Ui.SOFT, Ui.alex(c));
        text.addView(verse, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        f.addView(text, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        f.addView(new View(c), Ui.lpw(c, 1, 1, 1f));
        f.addView(new CrossView(c), Ui.lp(c, 44, 44));
        Ui.gap(c, f, 14);
        f.addView(Ui.text(c, "إيلينا وكيفين", 40, Ui.CREAM, Ui.amiriBold(c)), Ui.lp(c, Ui.WRAP, Ui.WRAP));
        return f;
    }

    // ---------------------------------------------------------------- apps

    private void refreshApps() {
        Context c = this;
        final List<Apps.App> all = Apps.list(c);
        favRow.removeAllViews();
        moreRow.removeAllViews();

        List<String> favPkgs = Apps.favoritePackages(c, all);
        List<Apps.App> favs = new ArrayList<>();
        for (String p : favPkgs) for (Apps.App a : all) if (a.pkg.equals(p)) favs.add(a);
        List<Apps.App> rest = new ArrayList<>();
        for (Apps.App a : all) if (!favs.contains(a)) rest.add(a);

        int nFav = Math.min(4, favs.size());
        for (int i = 0; i < nFav; i++) {
            if (i > 0) Ui.gap(c, favRow, 12);
            favRow.addView(appTile(favs.get(i), 96, 44, 22, 22), Ui.lpw(c, 0, 96, 1f));
        }
        favBlock.setVisibility(nFav == 0 ? View.GONE : View.VISIBLE);

        // The "more" row: favourites past the fourth, then the rest, then "all apps".
        List<Apps.App> more = new ArrayList<>();
        for (int i = 4; i < favs.size(); i++) more.add(favs.get(i));
        more.addAll(rest);
        int nMore = Math.min(5, more.size());
        for (int i = 0; i < nMore; i++) {
            moreRow.addView(appTile(more.get(i), 84, 32, 18, 14), Ui.lpw(c, 0, 84, 1f));
            Ui.gap(c, moreRow, 10);
        }
        TextView allBtn = Ui.text(c, "كل التطبيقات " + Coptic.ar(all.size()), 18, Ui.CREAM, Ui.alexBold(c));
        allBtn.setGravity(Gravity.CENTER);
        allBtn.setBackground(null);
        Ui.button(allBtn, dashed());
        allBtn.setOnClickListener(v -> startActivity(new Intent(this, AllAppsActivity.class)));
        moreRow.addView(allBtn, Ui.lpw(c, 0, 84, 1f));

        firstFocus = nFav > 0 ? favRow.getChildAt(0) : archBtn;
        if (firstFocus != null) firstFocus.requestFocus();
    }

    private android.graphics.drawable.Drawable dashed() {
        GradientDrawable g = Ui.rect(this, 0x00000000, 0xFF3A537F, 1, 16);
        g.setStroke(Math.max(1, Ui.px(this, 1)), 0xFF3A537F, Ui.px(this, 6), Ui.px(this, 4));
        android.graphics.drawable.StateListDrawable s = new android.graphics.drawable.StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.FOCUS, Ui.GOLD, 4, 16));
        s.addState(new int[]{}, g);
        return s;
    }

    private View appTile(final Apps.App a, float h, float icon, float labelSize, float pad) {
        Context c = this;
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(Ui.px(c, pad), Ui.px(c, 6), Ui.px(c, pad), Ui.px(c, 6));
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(a.icon);
        iv.setScaleType(ImageView.ScaleType.FIT_START);
        t.addView(iv, Ui.lp(c, icon, icon));
        TextView l = Ui.text(c, a.label, labelSize, Ui.CREAM, Ui.alexBold(c));
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(l, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.button(t, Ui.tile(c, Ui.PANEL, Ui.LINE, 16));
        t.setOnClickListener(v -> Apps.launch(this, a.pkg));
        return t;
    }

    // ---------------------------------------------------------------- ticking

    private void update() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        int sec = now.toLocalTime().toSecondOfDay();

        int h = now.getHour(), m = now.getMinute();
        int h12 = h % 12 == 0 ? 12 : h % 12;
        Ui.setIfChanged(clock, Coptic.ar(h12 + ":" + (m < 10 ? "0" : "") + m));
        Ui.setIfChanged(ampm, h < 12 ? "ص" : "م");

        String dayKey = today.toString();
        if (!dayKey.equals(shownDay)) {
            shownDay = dayKey;
            refreshDay(today);
        }

        int next = Agpeya.next(this, sec);
        Ui.setIfChanged(archName, Agpeya.NAMES[next]);
        Ui.setIfChanged(archCount, Agpeya.countdown(Agpeya.secondsUntil(this, next, sec)));
        Ui.setIfChanged(archSub, "الساعة " + Agpeya.clock(Agpeya.minutes(this, next)));
        if (next != shownNext) {
            shownNext = next;
            styleHours(next);
        }
    }

    private void styleHours(int next) {
        for (int i = 0; i < 7; i++) {
            boolean n = i == next;
            hTile[i].setBackground(n ? Ui.rect(this, Ui.CREAM, Ui.GOLD, 2, 18) : Ui.rect(this, Ui.PANEL, Ui.LINE, 1, 18));
            hName[i].setTextColor(n ? Ui.INK : Ui.CREAM);
            hTime[i].setTextColor(n ? Ui.INK : Ui.MUTED);
            hTag[i].setVisibility(n ? View.VISIBLE : View.INVISIBLE);
            hTime[i].setText(Agpeya.clock(Agpeya.minutes(this, i)));
        }
    }

    private void refreshDay(LocalDate d) {
        int[] c = Coptic.of(d);
        Ui.setIfChanged(copticLine, Coptic.dateLine(d));
        Ui.setIfChanged(gregLine, Coptic.gregorianLine(d));

        String fast = Coptic.fastToday(d);
        fast1.setText(fast.isEmpty() ? "اليوم بدون صوم" : fast);
        fast2.setText(Coptic.nextFast(d));

        JSONObject day = Readings.day(this, c[1], c[2]);
        synLabel.setText("سنكسار " + Coptic.ar(c[2]) + " " + Coptic.MONTHS[c[1] - 1]);
        String[] titles = Readings.titles(day);
        if (titles.length == 0) {
            syn1.setText("غير مضاف لهذا الشهر");
            syn2.setText("");
        } else {
            syn1.setText(titles[0]);
            syn2.setText(titles.length > 1 ? "و" + Coptic.ar(titles.length - 1) + " آخرين" : "");
        }

        if (day == null) {
            read1.setText("قراءات هذا الشهر غير مضافة");
            read2.setText("");
        } else if (d.getDayOfWeek() == DayOfWeek.SUNDAY) {
            read1.setText("اليوم أحد");
            read2.setText("قراءات الأحد غير مضافة في هذه النسخة");
        } else {
            read1.setText("إنجيل القدّاس: " + Readings.get(day, "lg"));
            read2.setText("البولس: " + Readings.get(day, "pa"));
        }
        styleHours(shownNext < 0 ? 0 : shownNext);
    }
}
