package tv.agpeya.home;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.tv.TvContract;
import android.media.tv.TvInputManager;
import android.media.tv.TvView;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Shows one of the TV's physical inputs (HDMI, AV...) full screen inside this app, so it does not depend on a separate
 * "TV" app being installed. Back returns to the list. If the TV refuses, we say why instead of opening Settings.
 */
public class InputViewActivity extends Activity {
    static final String EXTRA_ID = "input_id";
    static final String EXTRA_NAME = "input_name";

    private TvView tv;
    private TextView status;
    private String inputId;
    private boolean fellBack;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        inputId = getIntent().getStringExtra(EXTRA_ID);
        String name = getIntent().getStringExtra(EXTRA_NAME);
        if (inputId == null) {
            finish();
            return;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        tv = new TvView(this);
        root.addView(tv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(30);
        status.setGravity(Gravity.CENTER);
        status.setPadding(60, 40, 60, 40);
        status.setBackgroundColor(0x99000000);
        status.setText("جارٍ فتح " + (name == null ? "المدخل" : name) + "…");
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(status, sp);
        setContentView(root);

        tv.setCallback(new TvView.TvInputCallback() {
            @Override
            public void onConnectionFailed(String id) {
                fallBack("المدخل رفض الاتصال");
            }

            @Override
            public void onDisconnected(String id) {
                fallBack("انقطع الاتصال بالمدخل");
            }

            @Override
            public void onVideoAvailable(String id) {
                status.setVisibility(View.GONE);
            }

            @Override
            public void onVideoUnavailable(String id, int reason) {
                if (reason == TvInputManager.VIDEO_UNAVAILABLE_REASON_TUNING
                        || reason == TvInputManager.VIDEO_UNAVAILABLE_REASON_BUFFERING) {
                    status.setText("جارٍ فتح المدخل…");
                } else {
                    status.setText("لا توجد إشارة من هذا المدخل\nتأكد إن الجهاز شغّال وموصول");
                }
                status.setVisibility(View.VISIBLE);
            }
        });
        tv.tune(inputId, TvContract.buildChannelUriForPassthroughInput(inputId));
    }

    /** Last resort: let the TV's own app (if there is one) show the input. Never opens the TV settings. */
    private void fallBack(String why) {
        if (fellBack) return;
        fellBack = true;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(
                    TvContract.buildChannelUriForPassthroughInput(inputId).toString()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "تعذّر فتح المدخل: " + why, Toast.LENGTH_LONG).show();
        }
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (tv != null) tv.reset();
        if (!isFinishing()) finish();
    }
}
