package tv.agpeya.home;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import java.time.LocalTime;
import java.util.Random;

/**
 * The big banner: a church under a glowing cross. The sky follows the time of day (night, dawn,
 * day, sunset), the stars twinkle, and the cross breathes slowly. mood: 0 normal, 1 feast, 2 fast.
 */
final class HeroView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private final float[] sx = new float[36];
    private final float[] sy = new float[36];
    private final float[] sp = new float[36];
    private int mood;
    private float radius;

    HeroView(Context c) {
        super(c);
        Random r = new Random(11);
        for (int i = 0; i < sx.length; i++) {
            sx[i] = r.nextFloat();
            sy[i] = r.nextFloat() * 0.7f;
            sp[i] = r.nextFloat() * 6.28f;
        }
    }

    void setMood(int m) {
        if (m != mood) {
            mood = m;
            invalidate();
        }
    }

    void setRadius(float r) {
        radius = r;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float u = Ui.k(getContext());
        LocalTime now = LocalTime.now();
        float hr = now.getHour() + now.getMinute() / 60f;
        long t = System.currentTimeMillis();

        int top, bottom;
        float night;
        if (hr < 4.5f || hr >= 19.5f) {
            top = 0xFF050B1E;
            bottom = 0xFF16294F;
            night = 1f;
        } else if (hr < 7f) {
            top = 0xFF2B3A6B;
            bottom = 0xFFF0B27A;
            night = 0.4f;
        } else if (hr < 16.5f) {
            top = 0xFF1F4E8C;
            bottom = 0xFF7DB4DE;
            night = 0f;
        } else {
            top = 0xFF3A2A5C;
            bottom = 0xFFF2A65A;
            night = 0.4f;
        }

        clip.reset();
        rect.set(0, 0, w, h);
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW);
        canvas.save();
        canvas.clipPath(clip);

        // sky
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, p);
        p.setShader(null);

        // stars (gold sparkles on a feast day)
        boolean feast = mood == 1;
        if (night > 0f || feast) {
            for (int i = 0; i < sx.length; i++) {
                float tw = 0.55f + 0.45f * (float) Math.sin(t / 700.0 + sp[i]);
                float a = Math.min(1f, (feast ? 1f : night) * tw);
                p.setColor(feast ? 0xFFF5D98A : 0xFFFFFFFF);
                p.setAlpha(Math.round(255 * a));
                canvas.drawCircle(sx[i] * w, sy[i] * h, (feast ? 3.4f : 2.2f) * u, p);
            }
            p.setAlpha(255);
        }

        // sun or moon
        float ox = w * 0.33f, oy, orad = h * 0.07f;
        int oc, glow;
        if (night >= 1f) {
            oy = h * 0.22f;
            oc = 0xFFEFE9D2;
            glow = 0x66EFE9D2;
        } else if (hr < 7f || hr >= 16.5f) {
            oy = h * 0.58f;
            oc = 0xFFFFE2A8;
            glow = 0x66FFE2A8;
        } else {
            oy = h * 0.20f;
            oc = 0xFFFFF0B0;
            glow = 0x66FFF0B0;
        }
        p.setShader(new RadialGradient(ox, oy, orad * 4f, glow, glow & 0x00FFFFFF, Shader.TileMode.CLAMP));
        canvas.drawCircle(ox, oy, orad * 4f, p);
        p.setShader(null);
        p.setColor(oc);
        canvas.drawCircle(ox, oy, orad, p);

        // darker sides so the writing stays readable on any sky
        p.setShader(new LinearGradient(0, 0, w * 0.42f, 0, 0xB3081020, 0x00081020, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w * 0.42f, h, p);
        p.setShader(new LinearGradient(w, 0, w * 0.58f, 0, 0xB3081020, 0x00081020, Shader.TileMode.CLAMP));
        canvas.drawRect(w * 0.58f, 0, w, h, p);
        p.setShader(null);

        // the church
        float s = h * 0.62f, cx = w * 0.5f, base = h * 0.93f;
        float pulse = 0.75f + 0.25f * (float) Math.sin(t / 900.0);
        p.setColor(0xFF0A1424);
        rect.set(cx - w * 0.34f, base - h * 0.05f, cx + w * 0.34f, base + h * 0.25f);
        canvas.drawOval(rect, p);
        canvas.drawRect(cx - 0.55f * s, base - 0.35f * s, cx + 0.55f * s, base, p);
        canvas.drawRect(cx - 0.20f * s, base - 0.62f * s, cx + 0.20f * s, base, p);
        canvas.drawCircle(cx, base - 0.62f * s, 0.20f * s, p);
        canvas.drawCircle(cx - 0.38f * s, base - 0.35f * s, 0.15f * s, p);
        canvas.drawCircle(cx + 0.38f * s, base - 0.35f * s, 0.15f * s, p);

        // lit windows and door
        int wa = Math.round(255 * (0.35f + 0.65f * night));
        p.setColor((wa << 24) | 0xF0C777);
        rect.set(cx - 0.045f * s, base - 0.52f * s, cx + 0.045f * s, base - 0.38f * s);
        canvas.drawRoundRect(rect, 0.045f * s, 0.045f * s, p);
        float[] wx = {-0.45f, -0.30f, 0.30f, 0.45f};
        for (float f : wx) {
            rect.set(cx + (f - 0.025f) * s, base - 0.27f * s, cx + (f + 0.025f) * s, base - 0.14f * s);
            canvas.drawRoundRect(rect, 0.025f * s, 0.025f * s, p);
        }
        rect.set(cx - 0.06f * s, base - 0.17f * s, cx + 0.06f * s, base + 0.02f * s);
        canvas.drawRoundRect(rect, 0.06f * s, 0.06f * s, p);

        // glowing crosses
        cross(canvas, cx, base - 0.82f * s, s * 0.22f, pulse);
        cross(canvas, cx - 0.38f * s, base - 0.50f * s, s * 0.11f, pulse);
        cross(canvas, cx + 0.38f * s, base - 0.50f * s, s * 0.11f, pulse);

        if (mood == 2) {
            p.setColor(0x33000000);
            canvas.drawRect(0, 0, w, h, p);
        }
        canvas.restore();

        // thin gold edge
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2f, 2f * u));
        p.setColor(0x66D4AF6A);
        rect.set(1, 1, w - 1, h - 1);
        canvas.drawRoundRect(rect, radius, radius, p);
        p.setStyle(Paint.Style.FILL);

        postInvalidateDelayed(100);
    }

    private void cross(Canvas canvas, float x, float yBase, float len, float pulse) {
        float gy = yBase - len * 0.6f;
        int a = Math.round(0x70 * pulse);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(x, gy, len * 2.2f, (a << 24) | 0xF0C777, 0x00F0C777, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, gy, len * 2.2f, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(Math.max(2f, len * 0.14f));
        p.setColor(Ui.GOLD);
        canvas.drawLine(x, yBase - len, x, yBase, p);
        canvas.drawLine(x - len * 0.34f, yBase - len * 0.7f, x + len * 0.34f, yBase - len * 0.7f, p);
        p.setStyle(Paint.Style.FILL);
    }
}
