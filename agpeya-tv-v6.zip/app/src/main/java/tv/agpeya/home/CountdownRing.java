package tv.agpeya.home;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** A gold ring that fills up as the next Agpeya hour gets closer. */
final class CountdownRing extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float progress;

    CountdownRing(Context c) {
        super(c);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    void setProgress(float f) {
        float v = Math.max(0f, Math.min(1f, f));
        if (Math.abs(v - progress) > 0.002f) {
            progress = v;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h);
        float stroke = s * 0.055f;
        float cx = w / 2f, cy = h / 2f, rad = s / 2f - stroke;
        r.set(cx - rad, cy - rad, cx + rad, cy + rad);
        p.setStrokeWidth(stroke);
        p.setColor(0x66081020);
        p.setStyle(Paint.Style.FILL);
        canvas.drawCircle(cx, cy, rad + stroke / 2f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0x44D4AF6A);
        canvas.drawCircle(cx, cy, rad, p);
        p.setColor(Ui.GOLD);
        canvas.drawArc(r, -90f, 360f * progress, false, p);
    }
}
