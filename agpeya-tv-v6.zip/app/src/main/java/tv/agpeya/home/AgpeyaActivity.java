package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;

/** The seven hours: mark each one as prayed (OK), or hold OK to hear it chanted on YouTube. */
public class AgpeyaActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final View[] rows = new View[7];
    private final TextView[] marks = new TextView[7];
    private final TextView[] times = new TextView[7];
    private final TextView[] states = new TextView[7];
    private TextView summary, saint, dateLine, fastLine;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 20000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.applyTheme(this);
        View root = build();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    private View build() {
        final Context c = this;
        LinearLayout page = new LinearLayout(c);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(Ui.px(c, 90), Ui.px(c, 36), Ui.px(c, 90), Ui.px(c, 36));

        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(new CrossView(c), Ui.lp(c, 64, 64));
        Ui.gap(c, head, 16);
        head.addView(Ui.text(c, "الأجبية", 68, Ui.GOLD, Ui.amiriBold(c)), Ui.lp(c, Ui.WRAP, Ui.WRAP));
        head.addView(new View(c), Ui.lpw(c, 1, 1, 1f));
        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        dateLine = Ui.text(c, "", 28, Ui.CREAM, Ui.alexBold(c));
        fastLine = Ui.text(c, "", 22, Ui.MUTED, Ui.alex(c));
        info.addView(dateLine, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        info.addView(fastLine, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        head.addView(info, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        page.addView(head, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, page, 20);

        LinearLayout body = new LinearLayout(c);
        body.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < 7; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.px(c, 24), 0, Ui.px(c, 28), 0);
            Ui.button(row, Ui.tile(c, Ui.PANEL, Ui.LINE, 22));

            marks[i] = Ui.text(c, "", 32, Ui.INK, Ui.alexBold(c));
            marks[i].setGravity(Gravity.CENTER);
            row.addView(marks[i], Ui.lp(c, 52, 52));
            Ui.gap(c, row, 22);
            TextView name = Ui.text(c, Agpeya.NAMES[i], 36, Ui.CREAM, Ui.alexBold(c));
            row.addView(name, Ui.lpw(c, 0, Ui.WRAP, 1f));
            states[i] = Ui.text(c, "", 22, Ui.MUTED, Ui.alex(c));
            row.addView(states[i], Ui.lp(c, Ui.WRAP, Ui.WRAP));
            Ui.gap(c, row, 24);
            times[i] = Ui.text(c, "", 30, Ui.GOLD, Ui.alexBold(c));
            times[i].setTextDirection(View.TEXT_DIRECTION_LTR);
            row.addView(times[i], Ui.lp(c, Ui.WRAP, Ui.WRAP));

            row.setOnClickListener(v -> {
                Agpeya.toggleDone(c, idx);
                refresh();
            });
            row.setOnLongClickListener(v -> {
                Media.search(c, "الأجبية ساعة " + Agpeya.NAMES[idx] + " مرتلة");
                return true;
            });
            rows[i] = row;
            list.addView(row, Ui.lp(c, Ui.MATCH, 80));
            if (i < 6) Ui.gap(c, list, 10);
        }
        Ui.gap(c, list, 14);
        list.addView(Ui.text(c, "اضغط OK بعد ما تصلّي لتعليم الساعة  ·  اضغط مطوّلًا لسماعها مرتّلة", 21, Ui.MUTED, Ui.alex(c)),
                Ui.lp(c, Ui.MATCH, Ui.WRAP));
        body.addView(list, Ui.lpw(c, 0, Ui.WRAP, 1f));
        Ui.gap(c, body, 36);

        // side panel: cross, today's verse, count, saint of the day
        LinearLayout side = new LinearLayout(c);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setGravity(Gravity.CENTER_HORIZONTAL);
        side.setPadding(Ui.px(c, 32), Ui.px(c, 28), Ui.px(c, 32), Ui.px(c, 28));
        side.setBackground(Ui.rect(c, Ui.PANEL2, Ui.GOLD, 1, 28));
        side.addView(new CrossView(c), Ui.lp(c, 130, 130));
        Ui.gap(c, side, 12);
        String[] v = Verses.today(LocalDate.now());
        TextView vt = Ui.text(c, "«" + v[0] + "»", 28, Ui.CREAM, Ui.amiri(c));
        vt.setGravity(Gravity.CENTER);
        vt.setMaxLines(4);
        vt.setEllipsize(TextUtils.TruncateAt.END);
        side.addView(vt, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        TextView vr = Ui.text(c, v[1], 20, Ui.MUTED, Ui.alex(c));
        vr.setGravity(Gravity.CENTER);
        side.addView(vr, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, side, 22);
        summary = Ui.text(c, "", 34, Ui.GOLD, Ui.alexBold(c));
        summary.setGravity(Gravity.CENTER);
        side.addView(summary, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, side, 22);
        saint = Ui.text(c, "", 22, Ui.SOFT, Ui.alex(c));
        saint.setGravity(Gravity.CENTER);
        saint.setMaxLines(3);
        saint.setEllipsize(TextUtils.TruncateAt.END);
        side.addView(saint, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        body.addView(side, Ui.lp(c, 560, Ui.WRAP));

        page.addView(body, Ui.lp(c, Ui.MATCH, Ui.WRAP));

        ScrollView sv = new ScrollView(c);
        sv.setBackgroundColor(Ui.NAVY);
        sv.setFillViewport(true);
        sv.addView(page, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        return sv;
    }

    private void refresh() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate d = now.toLocalDate();
        int next = Agpeya.next(this, now.toLocalTime().toSecondOfDay());
        int mask = Agpeya.doneMask(this);

        for (int i = 0; i < 7; i++) {
            boolean done = (mask & (1 << i)) != 0;
            times[i].setText(Agpeya.clock(Agpeya.minutes(this, i)));
            marks[i].setText(done ? "✓" : "");
            marks[i].setBackground(done
                    ? Ui.rect(this, Ui.GOLD, Ui.GOLD, 0, 26)
                    : Ui.rect(this, 0x00000000, i == next ? Ui.GOLD : 0xFF5A7099, i == next ? 3 : 2, 26));
            states[i].setText(done ? "صلّيت" : (i == next ? "التالية" : ""));
            states[i].setTextColor(done ? Ui.GOLD : Ui.MUTED);
        }
        Ui.setIfChanged(summary, "صلّيت " + Coptic.ar(Integer.bitCount(mask)) + " من ٧");
        Ui.setIfChanged(dateLine, Coptic.dateLine(d));
        String feast = Coptic.feast(d);
        String fast = Coptic.fastToday(d);
        String line = !feast.isEmpty() ? feast : (fast.isEmpty() ? "اليوم بدون صوم" : fast);
        Ui.setIfChanged(fastLine, line);

        int[] cd = Coptic.of(d);
        JSONObject day = Readings.day(this, cd[1], cd[2]);
        String[] titles = Readings.titles(day);
        Ui.setIfChanged(saint, titles.length > 0 ? "سنكسار اليوم: " + titles[0] : "");
    }
}
