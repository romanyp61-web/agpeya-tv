package tv.agpeya.home;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

/** Small helpers so the screens can be written once at 1920x1080 and scale to any TV. */
final class Ui {
    private Ui() {}

    static int NAVY = 0xFF0C1B33;
    static int PANEL = 0xFF13264A;
    static int PANEL2 = 0xFF0F2243;
    static int LINE = 0xFF243A63;
    static final int GOLD = 0xFFD4AF6A;
    static final int CREAM = 0xFFF3ECDD;
    static final int MUTED = 0xFFA9B8D3;
    static final int SOFT = 0xFFD9E1F0;
    static int FOCUS = 0xFF1C3763;
    static final int INK = 0xFF0C1B33;

    /** NAVY, PANEL, PANEL2, LINE, FOCUS for each colour theme. */
    private static final int[][] THEMES = {
            {0xFF0C1B33, 0xFF13264A, 0xFF0F2243, 0xFF243A63, 0xFF1C3763},
            {0xFF2A0D14, 0xFF45171F, 0xFF37121A, 0xFF6A2A36, 0xFF5C2230},
            {0xFF0B2219, 0xFF12382A, 0xFF0E2D22, 0xFF24604A, 0xFF1A4D3B},
    };
    static final String[] THEME_NAMES = {"أزرق ملكي", "بوردو", "أخضر"};

    static int theme(Context c) {
        int t = c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getInt("theme", 0);
        return Math.max(0, Math.min(THEMES.length - 1, t));
    }

    /** Call at the start of every screen so the chosen colours are in place before it is built. */
    static void applyTheme(Context c) {
        int[] t = THEMES[theme(c)];
        NAVY = t[0];
        PANEL = t[1];
        PANEL2 = t[2];
        LINE = t[3];
        FOCUS = t[4];
    }

    static void setTheme(Context c, int i) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putInt("theme", i).apply();
        applyTheme(c);
    }

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static Typeface amiri, amiriBold, alex, alexBold;

    private static float fontScale = -1f;

    /** 1.0 normally, 1.15 when "big text" is on in Settings. */
    static float fontScale(Context c) {
        if (fontScale < 0)
            fontScale = c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getBoolean("big", false) ? 1.15f : 1f;
        return fontScale;
    }

    static boolean isBig(Context c) {
        return fontScale(c) > 1f;
    }

    static void setBig(Context c, boolean big) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putBoolean("big", big).apply();
        fontScale = big ? 1.15f : 1f;
    }

    /** 1.0 on a 1920x1080 screen; the tighter of width and height, so nothing falls off the bottom. */
    static float k(Context c) {
        android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
        return Math.max(0.5f, Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f));
    }

    static int px(Context c, float v) {
        return Math.round(v * k(c));
    }

    /** Design pixels to real pixels, but MATCH/WRAP (negative) pass through. */
    static int d(Context c, float v) {
        return v < 0 ? (int) v : px(c, v);
    }

    static Typeface amiri(Context c) {
        if (amiri == null) amiri = c.getResources().getFont(R.font.amiri_regular);
        return amiri;
    }

    static Typeface amiriBold(Context c) {
        if (amiriBold == null) amiriBold = c.getResources().getFont(R.font.amiri_bold);
        return amiriBold;
    }

    static Typeface alex(Context c) {
        if (alex == null) alex = c.getResources().getFont(R.font.alexandria_regular);
        return alex;
    }

    static Typeface alexBold(Context c) {
        if (alexBold == null) alexBold = c.getResources().getFont(R.font.alexandria_semibold);
        return alexBold;
    }

    static GradientDrawable rect(Context c, int fill, int stroke, float strokeW, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(px(c, radius));
        if (strokeW > 0) g.setStroke(Math.max(1, px(c, strokeW)), stroke);
        return g;
    }

    /** Tile background: plain at rest, bright gold edge when the remote focuses it. */
    static StateListDrawable tile(Context c, int fill, int line, float radius) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, rect(c, FOCUS, GOLD, 4, radius));
        s.addState(new int[]{}, rect(c, fill, line, 1, radius));
        return s;
    }

    static TextView text(Context c, String s, float size, int color, Typeface tf) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTypeface(tf);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * k(c) * fontScale(c));
        t.setIncludeFontPadding(false);
        return t;
    }

    static LinearLayout.LayoutParams lp(Context c, float w, float h) {
        return new LinearLayout.LayoutParams(d(c, w), d(c, h));
    }

    static LinearLayout.LayoutParams lpw(Context c, float w, float h, float weight) {
        return new LinearLayout.LayoutParams(d(c, w), d(c, h), weight);
    }

    /** A fixed gap between siblings. */
    static void gap(Context c, LinearLayout parent, float size) {
        Space sp = new Space(c);
        boolean horizontal = parent.getOrientation() == LinearLayout.HORIZONTAL;
        parent.addView(sp, horizontal ? lp(c, size, 1) : lp(c, 1, size));
    }

    /** Makes a view a remote-friendly button: focusable, clickable, grows a little when focused. */
    static void button(View v, android.graphics.drawable.Drawable bg) {
        v.setFocusable(true);
        v.setClickable(true);
        v.setBackground(bg);
        v.setOnFocusChangeListener((view, has) ->
                view.animate().scaleX(has ? 1.04f : 1f).scaleY(has ? 1.04f : 1f).setDuration(120).start());
    }

    static void setIfChanged(TextView t, String s) {
        if (!s.contentEquals(t.getText())) t.setText(s);
    }
}
