package tv.agpeya.home;

import java.time.LocalDate;

/** Family occasions, shown as a gold ribbon on that day. {month, day, year, text, add the number of years?} */
final class Occasions {
    private Occasions() {}

    private static final Object[][] LIST = {
            {10, 20, 2025, "كل سنة وكيفين طيب · عمره ", true},
            {11, 23, 2022, "كل سنة وإيلينا طيبة · عمرها ", true},
            {1, 29, 2022, "كل سنة وإنتم طيبين · ذكرى زواجنا ", true},
            {3, 10, 1996, "كل سنة وتينا طيبة", false},
            {10, 1, 1997, "كل سنة وإنت طيب", false},
    };

    private static String years(int n) {
        if (n == 1) return "سنة";
        if (n == 2) return "سنتين";
        if (n >= 3 && n <= 10) return Coptic.ar(n) + " سنين";
        return Coptic.ar(n) + " سنة";
    }

    static String today(LocalDate d) {
        for (Object[] o : LIST) {
            if ((Integer) o[0] == d.getMonthValue() && (Integer) o[1] == d.getDayOfMonth()) {
                String text = (String) o[3];
                int n = d.getYear() - (Integer) o[2];
                if ((Boolean) o[4] && n >= 1) return text + years(n);
                return text.trim();
            }
        }
        return "";
    }
}
