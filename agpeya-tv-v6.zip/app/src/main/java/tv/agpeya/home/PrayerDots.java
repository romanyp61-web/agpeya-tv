package tv.agpeya.home;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Seven circles, one per Agpeya hour: gold with a tick when prayed, ringed when it is the next one. */
final class PrayerDots extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int mask, next = -1;

    PrayerDots(Context c) {
        super(c);
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    void set(int mask, int next) {
        if (mask != this.mask || next != this.next) {
            this.mask = mask;
            this.next = next;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float cell = w / 7f;
        float r = Math.min(cell, h) * 0.38f;
        float cy = h / 2f;
        for (int i = 0; i < 7; i++) {
            float x = w - (i + 0.5f) * cell; // first hour on the right (RTL)
            boolean done = (mask & (1 << i)) != 0;
            if (done) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(Ui.GOLD);
                canvas.drawCircle(x, cy, r, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(2f, r * 0.2f));
                p.setColor(Ui.INK);
                canvas.drawLine(x - r * 0.45f, cy, x - r * 0.1f, cy + r * 0.4f, p);
                canvas.drawLine(x - r * 0.1f, cy + r * 0.4f, x + r * 0.5f, cy - r * 0.35f, p);
            } else {
                p.setStyle(Paint.Style.STROKE);
                boolean isNext = i == next;
                p.setStrokeWidth(Math.max(2f, r * (isNext ? 0.22f : 0.12f)));
                p.setColor(isNext ? Ui.GOLD : 0xFF5A7099);
                canvas.drawCircle(x, cy, r, p);
            }
        }
    }
}
