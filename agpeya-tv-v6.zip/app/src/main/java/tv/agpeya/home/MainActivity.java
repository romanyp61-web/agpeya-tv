package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** The home screen: tabs, a banner with the next prayer, today's cards, and the apps. */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final String HOUSE_VERSE = "«لتكن عيناك مفتوحتين على هذا البيت ليلًا ونهارًا» · الملوك الأول ٨: ٢٩";

    private FrameLayout stage;
    private TextView clock, ampm, copticLine;
    private HeroView hero;
    private TextView ribbon, greet;
    private CountdownRing ring;
    private TextView ringLabel, ringName, ringCount, ringSub;
    private TextView fastLabel, fast1, fast2, fast3, verseText, verseRef, prayCount;
    private PrayerDots dots;
    private LinearLayout appsRow;

    private float builtScale;
    private int builtTheme;
    private int shownNext = -1;
    private int lastChime = -1;
    private boolean dimmed;
    private String shownDay = "";
    private String occasion = "";
    private View firstFocus;
    private View tabAgpeya;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.applyTheme(this);
        builtScale = Ui.fontScale(this);
        builtTheme = Ui.theme(this);
        View root = buildRoot();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Ui.fontScale(this) != builtScale || Ui.theme(this) != builtTheme) {
            recreate();
            return;
        }
        refreshApps();
        shownDay = "";
        shownNext = -1;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home pressed while already here: back to the start.
        if (firstFocus != null) firstFocus.requestFocus();
    }

    @Override
    public void onBackPressed() {
        // This is the home screen; there is nowhere to go back to.
    }

    // ---------------------------------------------------------------- layout

    private View buildRoot() {
        Context c = this;
        boolean big = Ui.isBig(c);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.px(c, 56), Ui.px(c, 32), Ui.px(c, 56), Ui.px(c, 32));
        col.addView(buildTopBar(), Ui.lp(c, Ui.MATCH, 110));
        Ui.gap(c, col, 14);
        col.addView(buildHero(), Ui.lp(c, Ui.MATCH, big ? 420 : 380));
        Ui.gap(c, col, 16);
        col.addView(buildCards(), Ui.lp(c, Ui.MATCH, big ? 200 : 180));
        Ui.gap(c, col, 16);
        col.addView(buildApps(), Ui.lpw(c, Ui.MATCH, 0, 1f));

        stage = new FrameLayout(c);
        stage.setBackgroundColor(Ui.NAVY);
        stage.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        // Safety net: if a TV is shorter than expected the page scrolls instead of being cut off.
        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(stage, new ScrollView.LayoutParams(Ui.MATCH, Ui.MATCH));
        return sv;
    }

    private View buildTopBar() {
        Context c = this;
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        String[] names = {"الرئيسية", "الأجبية", "القراءات", "تطبيقاتي", "الإعدادات"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = Ui.text(c, names[i], 26, i == 0 ? Ui.INK : Ui.CREAM, Ui.alexBold(c));
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.px(c, 30), 0, Ui.px(c, 30), 0);
            Ui.button(t, i == 0 ? selectedTab() : Ui.tile(c, Ui.PANEL, 0xFF2A4270, 30));
            t.setOnClickListener(v -> {
                if (idx == 1) startActivity(new Intent(this, AgpeyaActivity.class));
                else if (idx == 2) startActivity(new Intent(this, ReadingsActivity.class));
                else if (idx == 3) startActivity(new Intent(this, AllAppsActivity.class));
                else if (idx == 4) startActivity(new Intent(this, SettingsActivity.class));
            });
            if (i == 1) tabAgpeya = t;
            bar.addView(t, Ui.lp(c, Ui.WRAP, 60));
            if (i < names.length - 1) Ui.gap(c, bar, 12);
        }
        bar.addView(new View(c), Ui.lpw(c, 1, 1, 1f));

        LinearLayout timeBlock = new LinearLayout(c);
        timeBlock.setOrientation(LinearLayout.VERTICAL);
        timeBlock.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout timeRow = new LinearLayout(c);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        timeRow.setGravity(Gravity.BOTTOM);
        clock = Ui.text(c, "", 60, Ui.CREAM, Ui.alexBold(c));
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        timeRow.addView(clock, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        Ui.gap(c, timeRow, 10);
        ampm = Ui.text(c, "", 26, Ui.MUTED, Ui.alex(c));
        timeRow.addView(ampm, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        timeBlock.addView(timeRow, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        copticLine = Ui.text(c, "", 24, Ui.GOLD, Ui.alexBold(c));
        timeBlock.addView(copticLine, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        bar.addView(timeBlock, Ui.lp(c, Ui.WRAP, Ui.MATCH));
        return bar;
    }

    private StateListDrawable selectedTab() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.GOLD, Ui.CREAM, 4, 30));
        s.addState(new int[]{}, Ui.rect(this, Ui.GOLD, Ui.GOLD, 0, 30));
        return s;
    }

    private View buildHero() {
        Context c = this;
        FrameLayout f = new FrameLayout(c);

        hero = new HeroView(c);
        hero.setRadius(Ui.px(c, 30));
        f.addView(hero, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        // writing, on the start (right) side
        LinearLayout txt = new LinearLayout(c);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setGravity(Gravity.CENTER_VERTICAL);
        txt.setPadding(Ui.px(c, 52), Ui.px(c, 64), Ui.px(c, 20), Ui.px(c, 20));
        greet = Ui.text(c, "", 26, Ui.GOLD, Ui.alexBold(c));
        txt.addView(greet, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        Ui.gap(c, txt, 6);
        TextView bless = Ui.text(c, "بارِك يا رب هذا البيت نهارًا وليلًا", 44, Ui.CREAM, Ui.amiriBold(c));
        txt.addView(bless, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, txt, 6);
        TextView verse = Ui.text(c, HOUSE_VERSE, 21, Ui.SOFT, Ui.alex(c));
        verse.setMaxLines(2);
        verse.setEllipsize(TextUtils.TruncateAt.END);
        txt.addView(verse, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, txt, 12);
        LinearLayout names = new LinearLayout(c);
        names.setOrientation(LinearLayout.HORIZONTAL);
        names.setGravity(Gravity.CENTER_VERTICAL);
        names.addView(new CrossView(c), Ui.lp(c, 44, 44));
        Ui.gap(c, names, 12);
        names.addView(Ui.text(c, "إيلينا وكيفين", 44, Ui.GOLD, Ui.amiriBold(c)), Ui.lp(c, Ui.WRAP, Ui.WRAP));
        txt.addView(names, Ui.lp(c, Ui.WRAP, Ui.WRAP));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(Ui.px(c, 800), Ui.MATCH);
        tl.gravity = Gravity.START;
        f.addView(txt, tl);

        // the next prayer, in a ring, on the end (left) side
        FrameLayout rw = new FrameLayout(c);
        ring = new CountdownRing(c);
        rw.addView(ring, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        LinearLayout rt = new LinearLayout(c);
        rt.setOrientation(LinearLayout.VERTICAL);
        rt.setGravity(Gravity.CENTER);
        rt.setPadding(Ui.px(c, 30), Ui.px(c, 30), Ui.px(c, 30), Ui.px(c, 30));
        ringLabel = Ui.text(c, "الصلاة القادمة", 20, Ui.MUTED, Ui.alex(c));
        ringLabel.setGravity(Gravity.CENTER);
        rt.addView(ringLabel, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        ringName = Ui.text(c, "", 38, Ui.GOLD, Ui.amiriBold(c));
        ringName.setGravity(Gravity.CENTER);
        rt.addView(ringName, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        ringCount = Ui.text(c, "", 36, Ui.CREAM, Ui.alexBold(c));
        ringCount.setGravity(Gravity.CENTER);
        ringCount.setTextDirection(View.TEXT_DIRECTION_LTR);
        rt.addView(ringCount, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        ringSub = Ui.text(c, "", 20, Ui.MUTED, Ui.alex(c));
        ringSub.setGravity(Gravity.CENTER);
        rt.addView(ringSub, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        rw.addView(rt, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        FrameLayout.LayoutParams rl = new FrameLayout.LayoutParams(Ui.px(c, 330), Ui.px(c, 330));
        rl.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        rl.setMarginEnd(Ui.px(c, 56));
        f.addView(rw, rl);

        // gold ribbon: reminder before/at prayer time, or a family occasion
        ribbon = Ui.text(c, "", 26, Ui.INK, Ui.alexBold(c));
        ribbon.setGravity(Gravity.CENTER);
        ribbon.setPadding(Ui.px(c, 36), 0, Ui.px(c, 36), 0);
        ribbon.setBackground(Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 24));
        ribbon.setVisibility(View.GONE);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.px(c, 48));
        bl.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        bl.topMargin = Ui.px(c, 16);
        f.addView(ribbon, bl);
        return f;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setPadding(Ui.px(this, 24), Ui.px(this, 12), Ui.px(this, 24), Ui.px(this, 12));
        Ui.button(l, Ui.tile(this, Ui.PANEL2, Ui.LINE, 22));
        return l;
    }

    private View buildCards() {
        Context c = this;
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout fastCard = card();
        fastLabel = Ui.text(c, "الصوم", 20, Ui.GOLD, Ui.alexBold(c));
        fast1 = Ui.text(c, "", 28, Ui.CREAM, Ui.alexBold(c));
        fast1.setSingleLine(true);
        fast1.setEllipsize(TextUtils.TruncateAt.END);
        fast2 = Ui.text(c, "", 22, Ui.SOFT, Ui.alex(c));
        fast2.setSingleLine(true);
        fast2.setEllipsize(TextUtils.TruncateAt.END);
        fast3 = Ui.text(c, "", 20, Ui.MUTED, Ui.alex(c));
        fast3.setSingleLine(true);
        fast3.setEllipsize(TextUtils.TruncateAt.END);
        fastCard.addView(fastLabel, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        fastCard.addView(fast1, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        fastCard.addView(fast2, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        fastCard.addView(fast3, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        fastCard.setOnClickListener(v -> startActivity(new Intent(this, ReadingsActivity.class)));

        LinearLayout verseCard = card();
        TextView vl = Ui.text(c, "آية اليوم", 20, Ui.GOLD, Ui.alexBold(c));
        verseText = Ui.text(c, "", 26, Ui.CREAM, Ui.amiri(c));
        verseText.setMaxLines(3);
        verseText.setEllipsize(TextUtils.TruncateAt.END);
        verseRef = Ui.text(c, "", 20, Ui.MUTED, Ui.alex(c));
        verseCard.addView(vl, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        verseCard.addView(verseText, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        verseCard.addView(verseRef, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        verseCard.setOnClickListener(v -> startActivity(new Intent(this, ReadingsActivity.class)));

        LinearLayout prayCard = card();
        TextView pl = Ui.text(c, "صلواتي اليوم", 20, Ui.GOLD, Ui.alexBold(c));
        dots = new PrayerDots(c);
        prayCount = Ui.text(c, "", 26, Ui.CREAM, Ui.alexBold(c));
        prayCard.addView(pl, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.gap(c, prayCard, 6);
        prayCard.addView(dots, Ui.lp(c, Ui.MATCH, 46));
        Ui.gap(c, prayCard, 6);
        prayCard.addView(prayCount, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        prayCard.setOnClickListener(v -> startActivity(new Intent(this, AgpeyaActivity.class)));

        row.addView(fastCard, Ui.lpw(c, 0, Ui.MATCH, 1f));
        Ui.gap(c, row, 16);
        row.addView(verseCard, Ui.lpw(c, 0, Ui.MATCH, 1f));
        Ui.gap(c, row, 16);
        row.addView(prayCard, Ui.lpw(c, 0, Ui.MATCH, 1f));
        return row;
    }

    private View buildApps() {
        Context c = this;
        LinearLayout block = new LinearLayout(c);
        block.setOrientation(LinearLayout.VERTICAL);
        block.addView(Ui.text(c, "تطبيقاتي", 22, Ui.MUTED, Ui.alex(c)), Ui.lp(c, Ui.WRAP, Ui.WRAP));
        Ui.gap(c, block, 8);
        appsRow = new LinearLayout(c);
        appsRow.setOrientation(LinearLayout.HORIZONTAL);
        block.addView(appsRow, Ui.lp(c, Ui.MATCH, 150));
        return block;
    }

    // ---------------------------------------------------------------- apps

    private void refreshApps() {
        Context c = this;
        final List<Apps.App> all = Apps.list(c);
        appsRow.removeAllViews();

        List<String> favPkgs = Apps.favoritePackages(c, all);
        List<Apps.App> shown = new ArrayList<>();
        for (String p : favPkgs) for (Apps.App a : all) if (a.pkg.equals(p)) shown.add(a);
        for (Apps.App a : all) {
            if (shown.size() >= 5) break;
            if (!shown.contains(a)) shown.add(a);
        }
        int n = Math.min(5, shown.size());
        for (int i = 0; i < n; i++) {
            appsRow.addView(appTile(shown.get(i)), Ui.lpw(c, 0, 150, 1f));
            Ui.gap(c, appsRow, 14);
        }
        TextView allBtn = Ui.text(c, "كل التطبيقات\n" + Coptic.ar(all.size()), 22, Ui.CREAM, Ui.alexBold(c));
        allBtn.setGravity(Gravity.CENTER);
        Ui.button(allBtn, dashed());
        allBtn.setOnClickListener(v -> startActivity(new Intent(this, AllAppsActivity.class)));
        appsRow.addView(allBtn, Ui.lpw(c, 0, 150, 1f));

        firstFocus = n > 0 ? appsRow.getChildAt(0) : tabAgpeya;
        if (firstFocus != null) firstFocus.requestFocus();
    }

    private android.graphics.drawable.Drawable dashed() {
        GradientDrawable g = Ui.rect(this, 0x00000000, 0xFF3A537F, 1, 22);
        g.setStroke(Math.max(1, Ui.px(this, 2)), 0xFF3A537F, Ui.px(this, 8), Ui.px(this, 5));
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.FOCUS, Ui.GOLD, 4, 22));
        s.addState(new int[]{}, g);
        return s;
    }

    private View appTile(final Apps.App a) {
        Context c = this;
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.px(c, 12), Ui.px(c, 8), Ui.px(c, 12), Ui.px(c, 8));
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(a.icon);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        t.addView(iv, Ui.lp(c, 80, 80));
        Ui.gap(c, t, 6);
        TextView l = Ui.text(c, a.label, 22, Ui.CREAM, Ui.alexBold(c));
        l.setGravity(Gravity.CENTER);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(l, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.button(t, Ui.tile(c, Ui.PANEL, Ui.LINE, 22));
        t.setOnClickListener(v -> Apps.launch(this, a.pkg));
        return t;
    }

    // ---------------------------------------------------------------- ticking

    private void update() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        int sec = now.toLocalTime().toSecondOfDay();
        int h = now.getHour(), m = now.getMinute();

        int h12 = h % 12 == 0 ? 12 : h % 12;
        Ui.setIfChanged(clock, Coptic.ar(h12 + ":" + (m < 10 ? "0" : "") + m));
        Ui.setIfChanged(ampm, h < 12 ? "ص" : "م");

        String dayKey = today.toString();
        if (!dayKey.equals(shownDay)) {
            shownDay = dayKey;
            refreshDay(today);
        }

        // greeting
        String hello = h >= 21 || h < 5 ? "تصبحوا على خير" : h < 12 ? "صباح الخير" : h < 18 ? "نهاركم سعيد" : "مساء الخير";
        Ui.setIfChanged(greet, hello + " يا إيلينا وكيفين");

        // next prayer
        int next = Agpeya.next(this, sec);
        int untilSec = Agpeya.secondsUntil(this, next, sec);
        Ui.setIfChanged(ringName, Agpeya.NAMES[next]);
        Ui.setIfChanged(ringCount, Agpeya.countdown(untilSec));
        Ui.setIfChanged(ringSub, "الساعة " + Agpeya.clock(Agpeya.minutes(this, next)));

        int prev = 0, since = Integer.MAX_VALUE;
        for (int i = 0; i < 7; i++) {
            int s = sec - Agpeya.minutes(this, i) * 60;
            if (s < 0) s += 86400;
            if (s < since) {
                since = s;
                prev = i;
            }
        }
        ring.setProgress(since / (float) (since + untilSec));

        // ribbon: a family occasion wins, then the prayer reminder
        if (!occasion.isEmpty()) {
            Ui.setIfChanged(ribbon, occasion);
            ribbon.setVisibility(View.VISIBLE);
        } else if (untilSec <= 600) {
            Ui.setIfChanged(ribbon, "اقترب وقت صلاة " + Agpeya.NAMES[next] + " — بعد " + minutesWord((untilSec + 59) / 60));
            ribbon.setVisibility(View.VISIBLE);
        } else if (since <= 900) {
            Ui.setIfChanged(ribbon, "حان وقت صلاة " + Agpeya.NAMES[prev] + " — صلِّ الآن");
            ribbon.setVisibility(View.VISIBLE);
        } else {
            ribbon.setVisibility(View.GONE);
        }

        // prayed today
        int mask = Agpeya.doneMask(this);
        dots.set(mask, next);
        Ui.setIfChanged(prayCount, "صلّيت " + Coptic.ar(Integer.bitCount(mask)) + " من ٧");

        // bell at the start of an hour (daytime only)
        int minuteOfDay = h * 60 + m;
        if (now.getSecond() < 3 && minuteOfDay != lastChime && h >= 5 && h <= 21 && Chime.enabled(this)) {
            for (int i = 0; i < 7; i++) {
                if (Agpeya.minutes(this, i) == minuteOfDay) {
                    lastChime = minuteOfDay;
                    Chime.play(this);
                    break;
                }
            }
        }

        // quiet, dimmer screen at night
        boolean night = h >= 21 || h < 5;
        if (night != dimmed) {
            dimmed = night;
            stage.setForeground(night ? new ColorDrawable(0x59000000) : null);
        }
        shownNext = next;
    }

    private static String minutesWord(int n) {
        if (n <= 1) return "دقيقة واحدة";
        if (n == 2) return "دقيقتين";
        return Coptic.ar(n) + " دقائق";
    }

    private void refreshDay(LocalDate d) {
        Ui.setIfChanged(copticLine, Coptic.dateLine(d));
        occasion = Occasions.today(d);

        String[] v = Verses.today(d);
        verseText.setText("«" + v[0] + "»");
        verseRef.setText(v[1]);

        String fast = Coptic.fastToday(d);
        String feast = Coptic.feast(d);
        LocalDate tm = d.plusDays(1);
        String tf = Coptic.feast(tm);
        if (tf.isEmpty()) tf = Coptic.fastToday(tm);
        String tomorrow = "غدًا: " + (tf.isEmpty() ? "بدون صوم" : tf);

        if (!feast.isEmpty()) {
            fastLabel.setText("مناسبة اليوم");
            fast1.setText(feast);
            fast2.setText(fast.isEmpty() ? tomorrow : fast);
            fast3.setText(fast.isEmpty() ? Coptic.nextFast(d) : tomorrow);
        } else {
            fastLabel.setText("الصوم");
            fast1.setText(fast.isEmpty() ? "اليوم بدون صوم" : fast);
            fast2.setText(tomorrow);
            fast3.setText(Coptic.nextFast(d));
        }

        // the banner's mood: gold sparkles on a feast, a quieter tone in a fast
        hero.setMood(!feast.isEmpty() ? 1 : (Coptic.majorFast(d) != null ? 2 : 0));
    }
}
