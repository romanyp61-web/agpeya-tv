package tv.agpeya.home;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Move each Agpeya hour (Left / Right = 15 minutes), reset them, or open the TV's own settings. */
public class SettingsActivity extends Activity {
    private final TextView[] values = new TextView[7];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.applyTheme(this);
        View root = build();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);
    }

    private View build() {
        final Context c = this;
        LinearLayout page = new LinearLayout(c);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(Ui.px(c, 200), Ui.px(c, 48), Ui.px(c, 200), Ui.px(c, 48));

        page.addView(Ui.text(c, "الإعدادات", 64, Ui.GOLD, Ui.amiriBold(c)));
        page.addView(Ui.text(c, "مواقيت الأجبية — حرّك السهم يمينًا أو يسارًا لتغيير الوقت (١٥ دقيقة)", 24, Ui.MUTED, Ui.alex(c)));
        Ui.gap(c, page, 22);

        for (int i = 0; i < 7; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.px(c, 30), 0, Ui.px(c, 30), 0);
            TextView name = Ui.text(c, Agpeya.NAMES[i], 30, Ui.CREAM, Ui.alexBold(c));
            row.addView(name, Ui.lpw(c, 0, Ui.WRAP, 1f));
            values[i] = Ui.text(c, "", 30, Ui.GOLD, Ui.alexBold(c));
            values[i].setTextDirection(View.TEXT_DIRECTION_LTR);
            row.addView(values[i], Ui.lp(c, Ui.WRAP, Ui.WRAP));
            Ui.button(row, Ui.tile(c, Ui.PANEL, Ui.LINE, 18));
            row.setOnKeyListener((v, keyCode, ev) -> {
                if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
                int step = keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ? 15
                        : keyCode == KeyEvent.KEYCODE_DPAD_LEFT ? -15 : 0;
                if (step == 0) return false;
                Agpeya.set(c, idx, Agpeya.minutes(c, idx) + step);
                show(idx);
                return true;
            });
            page.addView(row, Ui.lp(c, Ui.MATCH, 72));
            Ui.gap(c, page, 10);
            show(i);
        }
        Ui.gap(c, page, 16);

        page.addView(action("إعادة المواقيت الافتراضية", v -> {
            Agpeya.reset(c);
            for (int i = 0; i < 7; i++) show(i);
            Toast.makeText(c, "تمت إعادة الضبط", Toast.LENGTH_SHORT).show();
        }), Ui.lp(c, Ui.MATCH, 72));
        Ui.gap(c, page, 10);
        final TextView big = action(bigLabel(), null);
        big.setOnClickListener(v -> {
            Ui.setBig(c, !Ui.isBig(c));
            big.setText(bigLabel());
            Toast.makeText(c, "سيظهر التغيير عند الرجوع للشاشة الرئيسية", Toast.LENGTH_SHORT).show();
        });
        page.addView(big, Ui.lp(c, Ui.MATCH, 72));
        Ui.gap(c, page, 10);
        final TextView theme = action(themeLabel(), null);
        theme.setOnClickListener(v -> {
            Ui.setTheme(c, (Ui.theme(c) + 1) % Ui.THEME_NAMES.length);
            recreate();
        });
        page.addView(theme, Ui.lp(c, Ui.MATCH, 72));
        Ui.gap(c, page, 10);
        final TextView chime = action(chimeLabel(), null);
        chime.setOnClickListener(v -> {
            Chime.setEnabled(c, !Chime.enabled(c));
            chime.setText(chimeLabel());
            if (Chime.enabled(c)) Chime.play(c);
        });
        page.addView(chime, Ui.lp(c, Ui.MATCH, 72));
        Ui.gap(c, page, 10);
        page.addView(action("اختيار شاشة التوقف (أجبية TV)", v ->
                open(new Intent(Settings.ACTION_DREAM_SETTINGS))), Ui.lp(c, Ui.MATCH, 72));
        Ui.gap(c, page, 10);
        page.addView(action("اختيار الشاشة الرئيسية للتلفزيون", v ->
                open(new Intent(Settings.ACTION_HOME_SETTINGS))), Ui.lp(c, Ui.MATCH, 72));
        Ui.gap(c, page, 10);
        page.addView(action("إعدادات التلفزيون", v ->
                open(new Intent(Settings.ACTION_SETTINGS))), Ui.lp(c, Ui.MATCH, 72));

        ScrollView sv = new ScrollView(c);
        sv.setBackgroundColor(Ui.NAVY);
        sv.setFillViewport(true);
        sv.addView(page, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        return sv;
    }

    private String themeLabel() {
        return "اللون: " + Ui.THEME_NAMES[Ui.theme(this)] + " (اضغط للتغيير)";
    }

    private String chimeLabel() {
        return "جرس بداية الساعة: " + (Chime.enabled(this) ? "يعمل" : "متوقف") + " (اضغط للتبديل)";
    }

    private String bigLabel() {
        return "حجم الخط: " + (Ui.isBig(this) ? "كبير (اضغط للعودة للعادي)" : "عادي (اضغط للتكبير)");
    }

    private TextView action(String label, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 28, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(Ui.px(this, 30), 0, Ui.px(this, 30), 0);
        Ui.button(t, Ui.tile(this, Ui.PANEL2, Ui.LINE, 18));
        t.setOnClickListener(l);
        return t;
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "غير متاح على هذا التلفزيون", Toast.LENGTH_SHORT).show();
        }
    }

    private void show(int i) {
        values[i].setText("‹  " + Agpeya.clock(Agpeya.minutes(this, i)) + "  ›");
    }
}
