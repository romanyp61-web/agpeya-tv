package tv.agpeya.home;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;

/** Wi-Fi / Bluetooth state for the home screen icons: 0 = off, 1 = on but not connected, 2 = connected. */
final class Status {
    private Status() {}

    static int wifi(Context c) {
        try {
            Context app = c.getApplicationContext();
            WifiManager wm = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) return 0;
            ConnectivityManager cm = (ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                    if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return 2;
                }
            }
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    static int bluetooth(Context c) {
        try {
            BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
            if (a == null || !a.isEnabled()) return 0;
            try {
                if (a.getProfileConnectionState(BluetoothProfile.A2DP) == BluetoothProfile.STATE_CONNECTED
                        || a.getProfileConnectionState(BluetoothProfile.HEADSET) == BluetoothProfile.STATE_CONNECTED)
                    return 2;
            } catch (Exception ignored) {
                // no permission or not supported: just say "on"
            }
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }
}
