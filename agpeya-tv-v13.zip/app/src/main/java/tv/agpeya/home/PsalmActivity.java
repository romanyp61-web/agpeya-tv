package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.time.LocalDate;

/** Today's psalm in full (text from the Agpeya files only). */
public class PsalmActivity extends Activity {
    private ScrollView scroll;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        setContentView(build());
    }

    private View build() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));
        View dim = new View(c);
        dim.setBackgroundColor(0x80000000);
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        FrameLayout stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);

        String[] ps = Psalms.today(c, LocalDate.now());
        stage.addView(Ui.box(c, "مزمور اليوم", 56, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), Ui.at(c, 1000, 36, 850, 80));
        stage.addView(Ui.box(c, ps == null ? "" : ps[0], 28, Ui.MUTED, Ui.alex(c), Ui.GR, 1), Ui.at(c, 700, 112, 1150, 36));

        TextView back = Ui.text(c, "رجوع", 24, Ui.CREAM, Ui.alexBold(c));
        back.setGravity(Gravity.CENTER);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, Ui.FOCUS, Ui.GOLD, 4, 29));
        bg.addState(new int[]{}, Ui.rect(c, Ui.glass(0xB8), Ui.GOLD, 1.5f, 29));
        Ui.button(back, bg);
        back.setOnClickListener(v -> finish());
        stage.addView(back, Ui.at(c, 70, 44, 150, 58));

        View card = new View(c);
        card.setBackground(Ui.rect(c, Ui.glass(0xD9), 0x59D4AF6A, 1.5f, 28));
        stage.addView(card, Ui.at(c, 70, 160, 1780, 860));

        TextView body = Ui.text(c, ps == null ? "تعذّر فتح نص المزمور." : ps[1], Ui.readerBig(c) ? 54 : 44, Ui.CREAM, Ui.amiri(c));
        body.setTextDirection(View.TEXT_DIRECTION_RTL);
        body.setGravity(Gravity.RIGHT);
        body.setLineSpacing(0, 1.1f);
        body.setPadding(Ui.px(c, 50), Ui.px(c, 30), Ui.px(c, 50), Ui.px(c, 60));
        scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFocusable(true);
        scroll.setFocusableInTouchMode(true);
        scroll.addView(body, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        scroll.setOnKeyListener((v, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            int page = Ui.px(c, 560);
            if (code == KeyEvent.KEYCODE_DPAD_DOWN || code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) {
                scroll.smoothScrollBy(0, page);
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_UP && scroll.getScrollY() > 0) {
                scroll.smoothScrollBy(0, -page);
                return true;
            }
            return false;
        });
        stage.addView(scroll, Ui.at(c, 100, 180, 1720, 820));
        scroll.post(() -> scroll.requestFocus());
        return root;
    }
}
