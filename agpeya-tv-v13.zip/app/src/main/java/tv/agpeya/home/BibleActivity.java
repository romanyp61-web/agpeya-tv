package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * The Bible: books, then chapters, then the text. Also used for "the Bible in a year" (EXTRA_PLAN: steps through
 * today's chapters) and to open one chapter directly (EXTRA_BOOK + EXTRA_CHAPTER).
 */
public class BibleActivity extends Activity {
    static final String EXTRA_BOOK = "book", EXTRA_CHAPTER = "chapter", EXTRA_PLAN = "plan";

    private FrameLayout stage;
    private int mode;        // 0 books, 1 chapters, 2 reading
    private int book = 1, chapter = 1;
    private int[][] planRefs;
    private int planIdx;
    private ScrollView scroll;
    private TextView body;
    private int loadToken;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.background(this));
        View dim = new View(this);
        dim.setBackgroundColor(0x80000000);
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        stage = new FrameLayout(this);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(this, 1920), Ui.px(this, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);
        setContentView(root);

        if (getIntent().getBooleanExtra(EXTRA_PLAN, false)) {
            planRefs = Plan.today(this).refs;
            planIdx = 0;
            book = planRefs[0][0];
            chapter = planRefs[0][1];
            mode = 2;
        } else if (getIntent().getIntExtra(EXTRA_BOOK, 0) > 0) {
            book = getIntent().getIntExtra(EXTRA_BOOK, 1);
            chapter = getIntent().getIntExtra(EXTRA_CHAPTER, 1);
            mode = 2;
        }
        show();
    }

    @Override
    public void onBackPressed() {
        if (mode == 2 && planRefs == null && getIntent().getIntExtra(EXTRA_BOOK, 0) == 0) {
            mode = 1;
            show();
        } else if (mode == 1) {
            mode = 0;
            show();
        } else {
            finish();
        }
    }

    private void show() {
        stage.removeAllViews();
        loadToken++;
        if (mode == 0) showBooks();
        else if (mode == 1) showChapters();
        else showReading();
    }

    // ------------------------------------------------------------ pieces

    private TextView button(String label, float w, float h, float size) {
        TextView t = Ui.text(this, label, size, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.FOCUS, Ui.GOLD, 4, h / 2));
        bg.addState(new int[]{}, Ui.rect(this, Ui.glass(0xB8), Ui.GOLD, 1.5f, h / 2));
        Ui.button(t, bg);
        return t;
    }

    private TextView small(String label) {
        TextView t = Ui.text(this, label, 26, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setMaxLines(1);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        Ui.button(t, Ui.tile(this, Ui.glass(0xB8), 0x66D4AF6A, 18));
        return t;
    }

    private void header(String title, String sub) {
        stage.addView(Ui.box(this, title, 60, Ui.GOLD, Ui.amiriBold(this), Ui.GR, 1), Ui.at(this, 1000, 30, 850, 84));
        stage.addView(Ui.box(this, sub, 24, Ui.MUTED, Ui.alex(this), Ui.GR, 1), Ui.at(this, 600, 112, 1250, 34));
    }

    private TextView backButton() {
        TextView back = button("رجوع", 150, 58, 24);
        back.setOnClickListener(v -> onBackPressed());
        stage.addView(back, Ui.at(this, 70, 44, 150, 58));
        return back;
    }

    // ------------------------------------------------------------ books

    private void showBooks() {
        final Context c = this;
        header("الكتاب المقدس", "ترجمة سميث وفان دايك · تُحمَّل الفصول من الإنترنت أول مرة ثم تُحفظ على التليفزيون");
        backButton();
        LinearLayout page = new LinearLayout(c);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.setPadding(0, 0, 0, Ui.px(c, 30));
        TextView first = null;
        for (int sec = 0; sec < 2; sec++) {
            int from = sec == 0 ? 1 : Bible.OT + 1, to = sec == 0 ? Bible.OT : 66;
            TextView h = Ui.text(c, sec == 0 ? "العهد القديم" : "العهد الجديد", 34, Ui.GOLD, Ui.amiriBold(c));
            h.setGravity(Gravity.RIGHT);
            page.addView(h, Ui.lp(c, Ui.MATCH, 56));
            LinearLayout row = null;
            int col = 0;
            for (int b = from; b <= to; b++) {
                if (col % 6 == 0) {
                    row = new LinearLayout(c);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    page.addView(row, Ui.lp(c, Ui.MATCH, 66));
                    Ui.gap(c, page, 10);
                }
                final int bk = b;
                TextView t = small(Bible.name(b));
                t.setOnClickListener(v -> {
                    book = bk;
                    mode = 1;
                    show();
                });
                row.addView(t, Ui.lpw(c, 0, 66, 1f));
                if (col % 6 != 5) Ui.gap(c, row, 10);
                if (first == null) first = t;
                col++;
            }
            int missing = (6 - col % 6) % 6;
            for (int i = 0; i < missing; i++) {
                Ui.gap(c, row, 10);
                row.addView(new View(c), Ui.lpw(c, 0, 66, 1f));
            }
            Ui.gap(c, page, 14);
        }
        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(page, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        stage.addView(sv, Ui.at(c, 70, 170, 1780, 880));
        final TextView f = first;
        sv.post(() -> {
            if (f != null) f.requestFocus();
        });
    }

    // ------------------------------------------------------------ chapters

    private void showChapters() {
        final Context c = this;
        header(Bible.name(book), "اختر الفصل (" + Coptic.ar(Bible.chapters(book)) + " فصل)");
        backButton();
        LinearLayout page = new LinearLayout(c);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int n = Bible.chapters(book);
        final int cols = 10;
        LinearLayout row = null;
        TextView first = null;
        for (int ch = 1; ch <= n; ch++) {
            if ((ch - 1) % cols == 0) {
                row = new LinearLayout(c);
                row.setOrientation(LinearLayout.HORIZONTAL);
                page.addView(row, Ui.lp(c, Ui.MATCH, 78));
                Ui.gap(c, page, 10);
            }
            final int cc = ch;
            TextView t = small(Coptic.ar(ch));
            t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, 32 * Ui.k(c));
            t.setOnClickListener(v -> {
                chapter = cc;
                mode = 2;
                show();
            });
            row.addView(t, Ui.lpw(c, 0, 78, 1f));
            if ((ch - 1) % cols != cols - 1) Ui.gap(c, row, 10);
            if (first == null) first = t;
        }
        int missing = (cols - n % cols) % cols;
        for (int i = 0; i < missing; i++) {
            Ui.gap(c, row, 10);
            row.addView(new View(c), Ui.lpw(c, 0, 78, 1f));
        }
        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(page, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        stage.addView(sv, Ui.at(c, 70, 170, 1780, 880));
        final TextView f = first;
        sv.post(() -> {
            if (f != null) f.requestFocus();
        });
    }

    // ------------------------------------------------------------ reading

    private void showReading() {
        final Context c = this;
        String sub = planRefs != null
                ? "خطة الكتاب المقدس في سنة · الفصل " + Coptic.ar(planIdx + 1) + " من " + Coptic.ar(planRefs.length) + " لليوم"
                : "(↑↓ تمرير)";
        header(Bible.name(book) + " " + Coptic.ar(chapter), sub);
        backButton();

        boolean hasPrev = planRefs != null ? planIdx > 0 : prevExists();
        boolean hasNext = planRefs != null ? planIdx < planRefs.length - 1 : nextExists();
        float x = 236;
        if (hasPrev) {
            TextView prev = button("الفصل السابق", 220, 58, 24);
            prev.setOnClickListener(v -> step(-1));
            stage.addView(prev, Ui.at(c, x, 44, 220, 58));
            x += 236;
        }
        if (hasNext) {
            TextView next = button("الفصل التالي", 220, 58, 24);
            next.setOnClickListener(v -> step(1));
            stage.addView(next, Ui.at(c, x, 44, 220, 58));
            x += 236;
        }
        if (planRefs != null && !hasNext) {
            TextView done = button(Plan.today(c).doneToday ? "تمّت القراءة ✓" : "تمّت القراءة اليوم ✓", 300, 58, 24);
            done.setOnClickListener(v -> {
                Plan.markDone(c);
                Toast.makeText(c, "ربنا يبارك في قراءتك. أحسنت!", Toast.LENGTH_SHORT).show();
                finish();
            });
            stage.addView(done, Ui.at(c, x, 44, 300, 58));
        }

        View card = new View(c);
        card.setBackground(Ui.rect(c, Ui.glass(0xD9), 0x59D4AF6A, 1.5f, 28));
        stage.addView(card, Ui.at(c, 70, 160, 1780, 860));
        body = Ui.text(c, "جاري تحميل الفصل...", Ui.readerBig(c) ? 52 : 42, Ui.CREAM, Ui.amiri(c));
        body.setTextDirection(View.TEXT_DIRECTION_RTL);
        body.setGravity(Gravity.RIGHT);
        body.setLineSpacing(0, 1.12f);
        body.setPadding(Ui.px(c, 50), Ui.px(c, 30), Ui.px(c, 50), Ui.px(c, 60));
        scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFocusable(true);
        scroll.setFocusableInTouchMode(true);
        scroll.addView(body, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        scroll.setOnKeyListener((v, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            int page = Ui.px(c, 560);
            if (code == KeyEvent.KEYCODE_DPAD_DOWN || code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) {
                scroll.smoothScrollBy(0, page);
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_UP && scroll.getScrollY() > 0) {
                scroll.smoothScrollBy(0, -page);
                return true;
            }
            return false;
        });
        stage.addView(scroll, Ui.at(c, 100, 180, 1720, 820));
        scroll.post(() -> scroll.requestFocus());

        final int token = loadToken;
        Bible.load(c, book, chapter, (verses, error) -> {
            if (token != loadToken || isDestroyed()) return;
            if (verses == null) {
                body.setText(error);
                return;
            }
            SpannableStringBuilder sb = new SpannableStringBuilder();
            for (String[] v : verses) {
                int s = sb.length();
                sb.append(Coptic.ar(Integer.parseInt(v[0]))).append(' ');
                sb.setSpan(new ForegroundColorSpan(Ui.GOLD), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.setSpan(new RelativeSizeSpan(0.62f), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.append(v[1].replace('\n', ' ')).append("  ");
            }
            body.setText(sb);
            scroll.scrollTo(0, 0);
        });
    }

    private boolean prevExists() {
        return !(book == 1 && chapter == 1);
    }

    private boolean nextExists() {
        return !(book == 66 && chapter == Bible.chapters(66));
    }

    private void step(int d) {
        if (planRefs != null) {
            planIdx = Math.max(0, Math.min(planRefs.length - 1, planIdx + d));
            book = planRefs[planIdx][0];
            chapter = planRefs[planIdx][1];
        } else if (d > 0) {
            if (chapter < Bible.chapters(book)) chapter++;
            else if (book < 66) {
                book++;
                chapter = 1;
            }
        } else {
            if (chapter > 1) chapter--;
            else if (book > 1) {
                book--;
                chapter = Bible.chapters(book);
            }
        }
        show();
    }
}
