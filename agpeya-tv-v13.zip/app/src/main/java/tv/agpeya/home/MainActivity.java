package tv.agpeya.home;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * The home screen, laid out on a fixed 1920x1080 stage (scaled to the TV, always fully visible):
 * top bar, shortcuts, the arch banner with the blessing and the next prayer, today's cards, and the favourite apps.
 */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout stage;
    private HeroView hero;
    private TextView clock, ampm, copticLine, gregLine, fastLine, kicker, banner;
    private TextView nextLabel, nextName, nextCount, nextSub;
    private View nextCard;
    private Widgets.Ring ring;
    private Widgets.StatusIcon wifiIcon, btIcon;
    private Widgets.WxGlyph wxGlyph;
    private TextView wxText;
    private View wxChip;
    private TextView psalmText, psalmRef, verseText, verseRef;
    private TextView planDay, planRead, planStreak, planDone;
    private Widgets.Bar planBar;
    private View quietShade;
    private final List<View> dock = new ArrayList<>();
    private View firstFocus, heroBtn;
    private StateListDrawable nextNormal, nextGlow;

    private float builtScale;
    private int builtTheme;
    private boolean builtPhoto;
    private String shownDay = "";
    private int lastChime = -1;
    private int openHour = 0;
    private int lastSec = -1;
    private boolean glowing;
    private TextView soon;
    private String occasion = "";
    private String shownGreeting = "";

    private static final String HOUSE_VERSE = "«لتكن عيناك مفتوحتين على هذا البيت ليلًا ونهارًا»";

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        builtScale = Ui.fontScale(this);
        builtTheme = Ui.theme(this);
        builtPhoto = Ui.usePhoto(this);
        setContentView(build());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Ui.fontScale(this) != builtScale || Ui.theme(this) != builtTheme || Ui.usePhoto(this) != builtPhoto) {
            recreate();
            return;
        }
        refreshApps();
        shownDay = "";
        lastSec = -1;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (firstFocus != null) firstFocus.requestFocus();
    }

    @Override
    public void onBackPressed() {
        // This is the home screen; there is nowhere to go back to.
    }

    // ---------------------------------------------------------------- helpers

    private <T extends View> T put(T v, float x, float y, float w, float h) {
        stage.addView(v, Ui.at(this, x, y, w, h));
        return v;
    }

    private void go(Class<?> cls) {
        startActivity(new Intent(this, cls));
    }

    private void openSystem(String action) {
        try {
            startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "غير متاح على هذا التلفزيون", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private TextView pill(String label, float x, float y, float w, float h, boolean on, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 24, on ? Ui.INK : Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused},
                Ui.rect(this, on ? 0xFFF3D698 : Ui.FOCUS, Ui.GOLD, 4, h / 2));
        bg.addState(new int[]{}, on ? Ui.rect(this, Ui.GOLD, Ui.GOLD, 0, h / 2)
                : Ui.rect(this, Ui.glass(0xB8), 0x66D4AF6A, 1.5f, h / 2));
        Ui.button(t, bg);
        t.setOnClickListener(l);
        return put(t, x, y, w, h);
    }

    private void shortcut(int i, String label, int glyph, int color, View.OnClickListener l) {
        float x = 1750, y = 170 + 92 * i;
        FrameLayout f = new FrameLayout(this);
        Ui.button(f, Ui.tile(this, Ui.glass(0xB8), 0x59D4AF6A, 22));
        f.setOnClickListener(l);
        View back = new View(this);
        back.setBackground(Ui.rect(this, color, color, 0, 12));
        f.addView(back, Ui.at(this, 35, 8, 40, 40));
        f.addView(new Widgets.Glyph(this, glyph), Ui.at(this, 35, 8, 40, 40));
        f.addView(Ui.box(this, label, 17, Ui.CREAM, Ui.alexBold(this), Gravity.CENTER_HORIZONTAL, 1), Ui.at(this, 3, 52, 104, 28));
        put(f, x, y, 110, 84);
    }

    /** A card with an arch top; focusable when it opens something. */
    private View card(float x, float y, float w, float h, View.OnClickListener l) {
        View v = new View(this);
        Ui.button(v, Ui.archTile(this, Ui.glass(0xB8), 0x66D4AF6A, 70, 54, 24));
        if (l != null) v.setOnClickListener(l);
        return put(v, x, y, w, h);
    }

    // ---------------------------------------------------------------- layout

    private View build() {
        Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));

        stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        stage.setClipChildren(false);
        root.addView(stage, new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080), Gravity.CENTER));

        buildTopBar();
        buildShortcuts();
        buildHero();
        buildCards();

        quietShade = new View(c);
        quietShade.setBackgroundColor(0x4D000000);
        quietShade.setVisibility(View.GONE);
        root.addView(quietShade, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        return root;
    }

    private void buildTopBar() {
        Context c = this;
        View logo = new View(c);
        logo.setBackground(Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 16));
        put(logo, 1802, 39, 58, 58);
        CrossView cv = new CrossView(c);
        cv.tint(Ui.INK);
        put(cv, 1810, 47, 42, 42);
        put(Ui.box(c, "أجبية TV", 38, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 1), 1590, 36, 200, 62);

        pill("الرئيسية", 1450, 38, 130, 60, true, v -> { });
        pill("تطبيقاتي", 1298, 38, 140, 60, false, v -> go(AllAppsActivity.class));
        pill("الأجبية", 1166, 38, 120, 60, false, v -> go(AgpeyaActivity.class));
        pill("الكتاب المقدس", 964, 38, 190, 60, false, v -> go(BibleActivity.class));
        pill("الإعدادات", 812, 38, 140, 60, false, v -> go(SettingsActivity.class));

        clock = Ui.text(c, "", 66, Ui.CREAM, Ui.alexBold(c));
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        clock.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        clock.setSingleLine(true);
        put(clock, 60, 26, 210, 80);
        ampm = Ui.text(c, "", 26, Ui.MUTED, Ui.alex(c));
        ampm.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        put(ampm, 276, 60, 50, 40);
        copticLine = Ui.box(c, "", 26, Ui.GOLD, Ui.alexBold(c), Gravity.LEFT, 1);
        put(copticLine, 340, 30, 450, 40);
        gregLine = Ui.box(c, "", 20, Ui.MUTED, Ui.alex(c), Gravity.LEFT, 1);
        put(gregLine, 340, 70, 450, 32);
        fastLine = Ui.box(c, "", 20, 0xFF7FD6A0, Ui.alexBold(c), Gravity.LEFT, 1);
        put(fastLine, 340, 104, 450, 32);

        // Wi-Fi and Bluetooth: tap to open the TV's own screens for them
        wifiIcon = new Widgets.StatusIcon(c, Widgets.StatusIcon.WIFI);
        Ui.button(wifiIcon, Ui.tile(c, Ui.glass(0x99), 0x59D4AF6A, 16));
        wifiIcon.setOnClickListener(v -> openSystem(Settings.ACTION_WIFI_SETTINGS));
        put(wifiIcon, 60, 112, 52, 52);
        btIcon = new Widgets.StatusIcon(c, Widgets.StatusIcon.BT);
        Ui.button(btIcon, Ui.tile(c, Ui.glass(0x99), 0x59D4AF6A, 16));
        btIcon.setOnClickListener(v -> openSystem(Settings.ACTION_BLUETOOTH_SETTINGS));
        put(btIcon, 124, 112, 52, 52);

        FrameLayout chip = new FrameLayout(c);
        chip.setBackground(Ui.rect(c, Ui.glass(0x99), 0x59D4AF6A, 1, 16));
        wxGlyph = new Widgets.WxGlyph(c);
        chip.addView(wxGlyph, Ui.at(c, 8, 6, 40, 40));
        wxText = Ui.text(c, "", 24, Ui.CREAM, Ui.alexBold(c));
        wxText.setGravity(Gravity.CENTER_VERTICAL);
        wxText.setSingleLine(true);
        chip.addView(wxText, Ui.at(c, 54, 0, 150, 52));
        chip.setVisibility(View.GONE);
        wxChip = chip;
        put(chip, 190, 112, 200, 52);
    }

    private void buildShortcuts() {
        shortcut(0, "الأجبية", Widgets.Glyph.MOON, 0xFF3BA58D, v -> go(AgpeyaActivity.class));
        shortcut(1, "القراءات", Widgets.Glyph.BOOK, 0xFF8B6CD9, v -> go(ReadingsActivity.class));
        shortcut(2, "الألحان", Widgets.Glyph.NOTE, 0xFFE0709A, v -> Media.search(this, "ألحان وتسبحة قبطية أرثوذكسية"));
        shortcut(3, "إعدادات الشاشة", Widgets.Glyph.SCREEN, 0xFF4A90D9, v -> openSystem(Settings.ACTION_DISPLAY_SETTINGS));
        shortcut(4, "المداخل", Widgets.Glyph.HDMI, 0xFFE8A23C, v -> go(InputsActivity.class));
    }

    private void buildHero() {
        Context c = this;
        hero = new HeroView(c);
        put(hero, 60, 170, 1650, 462);

        kicker = Ui.box(c, "", 24, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1);
        put(kicker, 1180, 190, 474, 36);
        banner = Ui.text(c, "", 22, Ui.INK, Ui.alexBold(c));
        banner.setGravity(Gravity.CENTER);
        banner.setSingleLine(true);
        banner.setBackground(Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 18));
        banner.setVisibility(View.GONE);
        put(banner, 1130, 190, 524, 36);

        TextView bless = Ui.box(c, "بارِك يا رب هذا البيت نهارًا وليلًا", 60, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 2);
        bless.setLineSpacing(0, 0.9f);
        put(bless, 1180, 230, 474, 124);
        TextView hv = Ui.box(c, HOUSE_VERSE, 30, 0xFFE6DCC4, Ui.amiri(c), Ui.GR, 2);
        hv.setLineSpacing(0, 0.9f);
        put(hv, 1180, 358, 474, 84);
        put(Ui.box(c, "الملوك الأول ٨: ٢٩", 20, Ui.MUTED, Ui.alex(c), Ui.GR, 1), 1180, 446, 474, 26);
        put(Ui.box(c, "إيلينا وكيفين", 44, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), 1180, 474, 474, 52);

        soon = Ui.box(c, "", 22, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1);
        put(soon, 1180, 530, 474, 30);

        TextView btn = Ui.text(c, "قراءات اليوم والسنكسار", 22, Ui.INK, Ui.alexBold(c));
        btn.setGravity(Gravity.CENTER);
        btn.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, Ui.CREAM, Ui.GOLD, 5, 28));
        bg.addState(new int[]{}, Ui.rect(c, Ui.CREAM, Ui.CREAM, 0, 28));
        Ui.button(btn, bg);
        btn.setOnClickListener(v -> go(ReadingsActivity.class));
        put(btn, 1346, 566, 308, 56);
        heroBtn = btn;

        // next prayer: an arch with a ring that empties; it glows during the first minutes of the hour
        nextNormal = Ui.archTile(c, 0xA0000000 | (Ui.NAVY & 0xFFFFFF), 0x73D4AF6A, 0, 120, 24);
        nextGlow = new StateListDrawable();
        nextGlow.addState(new int[]{android.R.attr.state_focused}, Ui.arch(c, Ui.FOCUS, 0xFFF3D698, 5, 0, 120, 24));
        nextGlow.addState(new int[]{}, Ui.arch(c, 0xB0553018, 0xFFF3D698, 4, 0, 120, 24));
        nextCard = new View(c);
        Ui.button(nextCard, nextNormal);
        nextCard.setOnClickListener(v -> startActivity(new Intent(this, ReaderActivity.class)
                .putExtra(ReaderActivity.EXTRA_HOUR, openHour)));
        put(nextCard, 100, 396, 230, 226);
        nextLabel = Ui.box(c, "الصلاة القادمة", 17, Ui.MUTED, Ui.alex(c), Ui.GC, 1);
        put(nextLabel, 112, 424, 206, 24);
        nextName = Ui.box(c, "", 32, Ui.GOLD, Ui.amiriBold(c), Ui.GC, 1);
        put(nextName, 112, 448, 206, 42);
        ring = new Widgets.Ring(c);
        put(ring, 166, 494, 98, 98);
        nextCount = Ui.text(c, "", 20, Ui.CREAM, Ui.alexBold(c));
        nextCount.setGravity(Gravity.CENTER);
        nextCount.setSingleLine(true);
        nextCount.setTextDirection(View.TEXT_DIRECTION_LTR);
        put(nextCount, 166, 494, 98, 98);
        nextSub = Ui.box(c, "", 16, Ui.MUTED, Ui.alex(c), Ui.GC, 1);
        put(nextSub, 112, 594, 206, 22);
    }

    private void buildCards() {
        Context c = this;
        final float y = 656, h = 158;

        // psalm of the day
        card(84, y, 560, h, v -> go(PsalmActivity.class));
        put(Ui.box(c, "مزمور اليوم", 21, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 106, y + 22, 516, 28);
        psalmText = Ui.box(c, "", 30, Ui.CREAM, Ui.amiri(c), Ui.GR, 3);
        psalmText.setLineSpacing(0, 0.85f);
        put(psalmText, 106, y + 52, 516, 76);
        psalmRef = Ui.box(c, "", 18, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        put(psalmRef, 106, y + 128, 516, 24);

        // verse of the day, with its reflection one tap away
        card(666, y, 590, h, v -> go(MeditationActivity.class));
        put(Ui.box(c, "آية اليوم وتأمّلها", 21, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 688, y + 22, 546, 28);
        verseText = Ui.box(c, "", 34, Ui.CREAM, Ui.amiri(c), Ui.GR, 3);
        verseText.setLineSpacing(0, 0.85f);
        put(verseText, 688, y + 50, 546, 78);
        verseRef = Ui.box(c, "", 18, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        put(verseRef, 688, y + 128, 546, 24);

        // the Bible in a year
        card(1278, y, 558, h, v -> startActivity(new Intent(this, BibleActivity.class)
                .putExtra(BibleActivity.EXTRA_PLAN, true)));
        put(Ui.box(c, "الكتاب المقدس في سنة", 21, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 1300, y + 20, 514, 28);
        planDay = Ui.box(c, "", 26, Ui.CREAM, Ui.alexBold(c), Ui.GR, 1);
        put(planDay, 1300, y + 48, 514, 34);
        planRead = Ui.box(c, "", 22, Ui.SOFT, Ui.alex(c), Ui.GR, 1);
        put(planRead, 1300, y + 82, 514, 30);
        planBar = new Widgets.Bar(c);
        put(planBar, 1300, y + 116, 514, 7);
        planDone = Ui.text(c, "تمّت القراءة ✓", 20, Ui.INK, Ui.alexBold(c));
        planDone.setGravity(Gravity.CENTER);
        planDone.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, Ui.CREAM, Ui.GOLD, 4, 18));
        bg.addState(new int[]{}, Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 18));
        Ui.button(planDone, bg);
        planDone.setOnClickListener(v -> {
            Plan.markDone(this);
            Toast.makeText(this, "ربنا يبارك في قراءتك", Toast.LENGTH_SHORT).show();
            bindPlan();
        });
        put(planDone, 1300, y + 124, 180, 30);
        planStreak = Ui.box(c, "", 18, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        put(planStreak, 1500, y + 126, 292, 26);
    }

    // ---------------------------------------------------------------- apps

    private void refreshApps() {
        Context c = this;
        for (View v : dock) stage.removeView(v);
        dock.clear();

        final List<Apps.App> all = Apps.list(c);
        List<Apps.App> shown = new ArrayList<>();
        for (String p : Apps.favoritePackages(c, all))
            for (Apps.App a : all) if (a.pkg.equals(p) && !shown.contains(a)) shown.add(a);
        int n = Math.min(9, shown.size());
        int count = n + 1; // + "all apps"
        float gap = 18, total = 1752;
        float w = Math.min(190, (total - gap * (count - 1)) / count);
        float startX = 84 + (total - (w * count + gap * (count - 1))) / 2f;
        for (int i = 0; i < n; i++) {
            final Apps.App a = shown.get(i);
            View t = dockTile(a.icon, null, a.label, w);
            t.setOnClickListener(v -> Apps.launch(this, a.pkg));
            put(t, startX + i * (w + gap), 826, w, 170);
            dock.add(t);
        }
        View allTile = dockTile(null, new Widgets.Glyph(c, Widgets.Glyph.GRID), "كل التطبيقات", w);
        allTile.setOnClickListener(v -> go(AllAppsActivity.class));
        put(allTile, startX + n * (w + gap), 826, w, 170);
        dock.add(allTile);

        firstFocus = n > 0 ? dock.get(0) : heroBtn;
        firstFocus.requestFocus();
    }

    private View dockTile(android.graphics.drawable.Drawable icon, View glyph, String label, float w) {
        Context c = this;
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, Ui.px(c, 30), 0, 0);
        Ui.button(t, Ui.archTile(c, Ui.glass(0x99), 0x66D4AF6A, 0, 70, 26));
        if (icon != null) {
            ImageView iv = new ImageView(c);
            iv.setImageDrawable(icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            t.addView(iv, Ui.lp(c, 88, 88));
        } else {
            FrameLayout f = new FrameLayout(c);
            View back = new View(c);
            back.setBackground(Ui.rect(c, 0xFF8A4A5C, 0xFF8A4A5C, 0, 22));
            f.addView(back, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            f.addView(glyph, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            t.addView(f, Ui.lp(c, 88, 88));
        }
        Ui.gap(c, t, 8);
        t.addView(Ui.box(c, label, 21, Ui.CREAM, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 2), Ui.lp(c, w - 16, 44));
        return t;
    }

    // ---------------------------------------------------------------- ticking

    private static String greeting(int hour) {
        if (hour >= 5 && hour < 12) return "صباح الخير يا إيلينا وكيفين";
        if (hour >= 12 && hour < 17) return "نهارك سعيد يا إيلينا وكيفين";
        if (hour >= 17 && hour < 21) return "مساء الخير يا إيلينا وكيفين";
        return "ليلة هادئة يا إيلينا وكيفين";
    }

    private static String minutesWord(int n) {
        if (n <= 1) return "دقيقة واحدة";
        if (n == 2) return "دقيقتين";
        return Coptic.ar(n) + " دقائق";
    }

    private void bindPlan() {
        Plan.Today t = Plan.today(this);
        Ui.setIfChanged(planDay, "اليوم " + Coptic.ar(t.day) + " من " + Coptic.ar(Plan.DAYS));
        Ui.setIfChanged(planRead, t.label);
        planBar.set(t.day / (float) Plan.DAYS);
        Ui.setIfChanged(planStreak, t.streak > 0 ? "متتالية: " + Coptic.ar(t.streak) + " يوم" : "");
        planDone.setText(t.doneToday ? "تمّت اليوم ✓" : "تمّت القراءة ✓");
        planDone.setAlpha(t.doneToday ? 0.55f : 1f);
    }

    private void bindWeather() {
        String[] w = Weather.cached(this);
        if (w == null) {
            wxChip.setVisibility(View.GONE);
            return;
        }
        wxGlyph.setCode(Integer.parseInt(w[1]));
        Ui.setIfChanged(wxText, "القاهرة " + Coptic.ar(Integer.parseInt(w[0])) + "°");
        wxChip.setVisibility(View.VISIBLE);
    }

    private void update() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        int sec = now.toLocalTime().toSecondOfDay();

        int h = now.getHour(), m = now.getMinute();
        int h12 = h % 12 == 0 ? 12 : h % 12;
        Ui.setIfChanged(clock, Coptic.ar(h12 + ":" + (m < 10 ? "0" : "") + m));
        Ui.setIfChanged(ampm, h < 12 ? "ص" : "م");

        String dayKey = today.toString();
        if (!dayKey.equals(shownDay)) {
            shownDay = dayKey;
            refreshDay(today);
        }

        // Wi-Fi / Bluetooth every few seconds, weather checked once a minute
        if (lastSec < 0 || sec % 5 == 0) {
            wifiIcon.setState(Status.wifi(this));
            btIcon.setState(Status.bluetooth(this));
        }
        if (lastSec < 0 || sec % 60 == 0) {
            Weather.refresh(this, this::bindWeather);
            bindWeather();
        }
        lastSec = sec;

        // next prayer
        int next = Agpeya.next(this, sec);
        int until = Agpeya.secondsUntil(this, next, sec);
        int since = Agpeya.secondsSince(this, sec);

        // reminder: 10 minutes before an hour, and 15 minutes after it starts
        int prev = 0, best = Integer.MAX_VALUE;
        for (int i = 0; i < 7; i++) {
            int s = sec - Agpeya.minutes(this, i) * 60;
            if (s < 0) s += 86400;
            if (s < best) {
                best = s;
                prev = i;
            }
        }
        boolean prayNow = until > 600 && best <= 900;
        openHour = until <= 600 ? next : (prayNow ? prev : next);

        if (prayNow != glowing) {
            glowing = prayNow;
            Ui.button(nextCard, glowing ? nextGlow : nextNormal);
        }
        if (prayNow) {
            Ui.setIfChanged(nextLabel, "حان وقت الصلاة الآن");
            Ui.setIfChanged(nextName, Agpeya.NAMES[prev]);
            Ui.setIfChanged(nextSub, best < 60 ? "بدأت الآن" : "بدأت من " + minutesWord(best / 60));
        } else {
            Ui.setIfChanged(nextLabel, "الصلاة القادمة");
            Ui.setIfChanged(nextName, Agpeya.NAMES[next]);
            Ui.setIfChanged(nextSub, "الساعة " + Agpeya.clock(Agpeya.minutes(this, next)));
        }
        Ui.setIfChanged(nextCount, Agpeya.countdown(until));
        ring.set(since / (float) Math.max(1, since + until));

        if (until <= 600) {
            Ui.setIfChanged(banner, "اقترب وقت صلاة " + Agpeya.NAMES[next] + " — بعد " + minutesWord((until + 59) / 60));
            banner.setVisibility(View.VISIBLE);
            kicker.setVisibility(View.INVISIBLE);
        } else if (prayNow) {
            Ui.setIfChanged(banner, "حان وقت صلاة " + Agpeya.NAMES[prev] + " — صلِّ الآن");
            banner.setVisibility(View.VISIBLE);
            kicker.setVisibility(View.INVISIBLE);
        } else {
            banner.setVisibility(View.GONE);
            kicker.setVisibility(View.VISIBLE);
        }

        String g = greeting(h);
        if (!g.equals(shownGreeting)) {
            shownGreeting = g;
            applyKicker(today);
        }

        // soft bell at the start of an hour (daytime only)
        int minuteOfDay = h * 60 + m;
        if (now.getSecond() < 3 && minuteOfDay != lastChime && h >= 5 && h <= 21 && Chime.enabled(this)) {
            for (int i = 0; i < 7; i++) {
                if (Agpeya.minutes(this, i) == minuteOfDay) {
                    lastChime = minuteOfDay;
                    Chime.play(this);
                    break;
                }
            }
        }

        // quiet mode after 9 pm until 5 am
        boolean quiet = Ui.quiet(this) && (h >= 21 || h < 5);
        quietShade.setVisibility(quiet ? View.VISIBLE : View.GONE);
    }

    private void applyKicker(LocalDate d) {
        String feast = Coptic.feast(d);
        kicker.setText(!occasion.isEmpty() ? occasion
                : feast.isEmpty() ? shownGreeting : "كل سنة وإنتم طيبين · " + feast);
    }

    private void refreshDay(LocalDate d) {
        Ui.setIfChanged(copticLine, Coptic.dateLine(d));
        Ui.setIfChanged(gregLine, Coptic.gregorianLine(d));

        String feast = Coptic.feast(d);
        String fast = Coptic.fastToday(d);
        LocalDate tm = d.plusDays(1);
        String tomorrow = Coptic.feast(tm);
        if (tomorrow.isEmpty()) {
            String f = Coptic.fastToday(tm);
            tomorrow = f.isEmpty() ? "بدون صوم" : f;
        }

        // the fast is only a small green line under the date
        if (fast.isEmpty()) {
            fastLine.setVisibility(View.INVISIBLE);
        } else {
            int[] fp = Coptic.fastProgress(d);
            fastLine.setText("● " + fast + (fp[0] == 1 ? " · اليوم " + Coptic.ar(fp[1]) + " من " + Coptic.ar(fp[2]) : ""));
            fastLine.setVisibility(View.VISIBLE);
        }

        occasion = Occasions.today(d);

        String[] ps = Psalms.today(this, d);
        psalmText.setText(ps == null ? "المزامير في الأجبية" : Psalms.preview(ps[1]));
        psalmRef.setText(ps == null ? "" : ps[0]);

        String[] v = Verses.today(d);
        verseText.setText(v[0]);
        verseRef.setText(v[1] + "  ·  اضغط لقراءة التأمل");

        bindPlan();

        hero.setFasting(Coptic.majorFast(d) != null);
        int type = 0;
        if (!feast.isEmpty()) {
            if (feast.contains("الميلاد")) type = 1;
            else if (feast.contains("القيامة") || feast.contains("العنصرة") || feast.contains("الصعود")) type = 2;
            else type = 3;
        }
        hero.setFeast(type);
        String up = Occasions.upcoming(d);
        soon.setText(up);
        soon.setVisibility(up.isEmpty() ? View.INVISIBLE : View.VISIBLE);
        applyKicker(d);
    }
}
