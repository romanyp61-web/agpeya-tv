package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.time.LocalDate;

/** The daily verse with a short reflection, and a button to read the whole chapter. */
public class MeditationActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        setContentView(build());
    }

    private View build() {
        final Context c = this;
        LocalDate d = LocalDate.now();
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));
        View dim = new View(c);
        dim.setBackgroundColor(0x80000000);
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        FrameLayout stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);

        stage.addView(Ui.box(c, "تأمّل اليوم", 64, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), Ui.at(c, 1000, 40, 850, 90));
        String[] v = Verses.today(d);
        View card = new View(c);
        card.setBackground(Ui.rect(c, Ui.glass(0xD9), 0x59D4AF6A, 1.5f, 28));
        stage.addView(card, Ui.at(c, 160, 160, 1600, 700));
        stage.addView(Ui.box(c, v[0], 60, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 3), Ui.at(c, 220, 190, 1480, 230));
        stage.addView(Ui.box(c, v[1], 28, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), Ui.at(c, 220, 424, 1480, 44));
        stage.addView(Ui.box(c, Meditations.text(d), 42, 0xFFE6DCC4, Ui.amiri(c), Ui.GR, 5), Ui.at(c, 220, 490, 1480, 340));

        final int[] w = Meditations.where(d);
        TextView read = button("اقرأ الفصل كاملًا: " + Bible.name(w[0]) + " " + Coptic.ar(w[1]), 560, 70);
        read.setOnClickListener(x -> startActivity(new Intent(this, BibleActivity.class)
                .putExtra(BibleActivity.EXTRA_BOOK, w[0]).putExtra(BibleActivity.EXTRA_CHAPTER, w[1])));
        stage.addView(read, Ui.at(c, 1200, 900, 560, 70));
        TextView back = button("رجوع", 200, 70);
        back.setOnClickListener(x -> finish());
        stage.addView(back, Ui.at(c, 160, 900, 200, 70));
        read.post(read::requestFocus);
        return root;
    }

    private TextView button(String label, float w, float h) {
        TextView t = Ui.text(this, label, 28, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.FOCUS, Ui.GOLD, 4, h / 2));
        bg.addState(new int[]{}, Ui.rect(this, Ui.glass(0xB8), Ui.GOLD, 1.5f, h / 2));
        Ui.button(t, bg);
        return t;
    }
}
