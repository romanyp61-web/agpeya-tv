package tv.agpeya.home;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * The TV's physical inputs (HDMI 1, HDMI 2, AV...). OK opens the input; press and hold OK to give it a name
 * (receiver, computer, PlayStation...).
 */
public class InputsActivity extends Activity {
    private static final String[] PRESETS = {"", "الرسيفر", "الكمبيوتر", "بلاي ستيشن", "كاميرا", "جهاز آخر"};

    private FrameLayout stage;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        setContentView(build());
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("agpeya", Context.MODE_PRIVATE);
    }

    private View build() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));
        View dim = new View(c);
        dim.setBackgroundColor(0x80000000);
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);

        stage.addView(Ui.box(c, "المداخل", 64, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), Ui.at(c, 1000, 40, 850, 90));
        stage.addView(Ui.box(c, "اضغط OK لفتح المدخل · اضغط مطولًا لتسميته (الرسيفر، الكمبيوتر...)", 26, Ui.MUTED,
                Ui.alex(c), Ui.GR, 1), Ui.at(c, 500, 128, 1350, 40));
        TextView back = tile("رجوع", 150, 58, 24);
        back.setOnClickListener(v -> finish());
        stage.addView(back, Ui.at(c, 70, 50, 150, 58));

        final List<TvInputInfo> inputs = new ArrayList<>();
        try {
            TvInputManager tm = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
            if (tm != null) {
                for (TvInputInfo i : tm.getTvInputList()) if (i.isPassthroughInput()) inputs.add(i);
            }
        } catch (Exception ignored) {
            // some TVs do not allow apps to list the inputs
        }

        if (inputs.isEmpty()) {
            stage.addView(Ui.box(c, "ما قدرناش نعرض مداخل التليفزيون من هنا. افتح قائمة المداخل من إعدادات التليفزيون.", 36,
                    Ui.CREAM, Ui.alexBold(c), Ui.GC, 3), Ui.at(c, 360, 300, 1200, 200));
            TextView open = tile("فتح إعدادات التليفزيون", 420, 80, 30);
            open.setOnClickListener(v -> openSettings());
            stage.addView(open, Ui.at(c, 750, 540, 420, 80));
            open.post(open::requestFocus);
            return root;
        }

        for (int i = 0; i < inputs.size(); i++) {
            final TvInputInfo info = inputs.get(i);
            int col = i % 4, row = i / 4;
            float x = 1920 - 70 - 410 - col * 440, y = 220 + row * 230;
            final TextView t = tile("", 410, 200, 36);
            t.setSingleLine(false);
            t.setMaxLines(3);
            stage.addView(t, Ui.at(c, x, y, 410, 200));
            bindName(t, info);
            t.setOnClickListener(v -> launch(info));
            t.setOnLongClickListener(v -> {
                String key = "inp_" + info.getId();
                String cur = prefs().getString(key, "");
                int idx = 0;
                for (int k = 0; k < PRESETS.length; k++) if (PRESETS[k].equals(cur)) idx = k;
                prefs().edit().putString(key, PRESETS[(idx + 1) % PRESETS.length]).apply();
                bindName(t, info);
                return true;
            });
            if (i == 0) t.post(t::requestFocus);
        }
        return root;
    }

    private String original(TvInputInfo info) {
        try {
            CharSequence l = info.loadLabel(this);
            if (l != null && l.length() > 0) return l.toString();
        } catch (Exception ignored) {
            // fall through
        }
        return "مدخل";
    }

    private void bindName(TextView t, TvInputInfo info) {
        String custom = prefs().getString("inp_" + info.getId(), "");
        String orig = original(info);
        t.setText(custom.isEmpty() ? orig : custom + "\n" + orig);
    }

    private void launch(TvInputInfo info) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.getId()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "تعذّر فتح هذا المدخل من هنا. غيّره من زر المداخل في الريموت", Toast.LENGTH_LONG).show();
            openSettings();
        }
    }

    private void openSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "غير متاح على هذا التلفزيون", Toast.LENGTH_SHORT).show();
        }
    }

    private TextView tile(String label, float w, float h, float size) {
        TextView t = Ui.text(this, label, size, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        Ui.button(t, Ui.archTile(this, Ui.glass(0xC0), 0x80D4AF6A, 60, 50, 26));
        return t;
    }
}
