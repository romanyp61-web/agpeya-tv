package tv.agpeya.home;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** A panel shape with big rounded (dome-like) top corners: the church-arch look. All sizes in real pixels. */
final class ArchDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float topRx, topRy, bottomR, strokeW;

    /** topRx below zero means "half of the width". */
    ArchDrawable(int fillColor, int strokeColor, float strokeW, float topRx, float topRy, float bottomR) {
        this.topRx = topRx;
        this.topRy = topRy;
        this.bottomR = bottomR;
        this.strokeW = strokeW;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(fillColor);
        line.setStyle(Paint.Style.STROKE);
        line.setColor(strokeColor);
        line.setStrokeWidth(strokeW);
    }

    @Override
    protected void onBoundsChange(Rect b) {
        super.onBoundsChange(b);
        path.reset();
        float w = b.width(), h = b.height();
        if (w <= 0 || h <= 0) return;
        float inset = strokeW / 2f;
        float rx = topRx < 0 ? w / 2f : Math.min(topRx, w / 2f);
        float ry = Math.min(topRy, h * 0.9f);
        float br = Math.min(bottomR, Math.min(w, h) / 2f);
        RectF r = new RectF(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset);
        float[] radii = {rx, ry, rx, ry, br, br, br, br};
        path.addRoundRect(r, radii, Path.Direction.CW);
    }

    @Override
    public void draw(Canvas canvas) {
        canvas.drawPath(path, fill);
        if (strokeW > 0) canvas.drawPath(path, line);
    }

    @Override
    public void setAlpha(int alpha) {
        fill.setAlpha(alpha);
        line.setAlpha(alpha);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        fill.setColorFilter(cf);
        line.setColorFilter(cf);
        invalidateSelf();
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
