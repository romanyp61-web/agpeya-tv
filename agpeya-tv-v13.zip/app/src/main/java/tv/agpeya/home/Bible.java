package tv.agpeya.home;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** The 66 books (Arabic names, chapter counts) and chapter text, downloaded once from getBible (Smith & Van Dyck) and kept on the TV. */
final class Bible {
    private Bible() {}

    static final String[] NAMES = {
            "التكوين", "الخروج", "اللاويين", "العدد", "التثنية", "يشوع", "القضاة", "راعوث",
            "صموئيل الأول", "صموئيل الثاني", "الملوك الأول", "الملوك الثاني", "أخبار الأيام الأول", "أخبار الأيام الثاني",
            "عزرا", "نحميا", "أستير", "أيوب", "المزامير", "الأمثال", "الجامعة", "نشيد الأنشاد",
            "إشعياء", "إرميا", "مراثي إرميا", "حزقيال", "دانيال", "هوشع", "يوئيل", "عاموس", "عوبديا", "يونان",
            "ميخا", "ناحوم", "حبقوق", "صفنيا", "حجي", "زكريا", "ملاخي",
            "متى", "مرقس", "لوقا", "يوحنا", "أعمال الرسل", "رومية", "كورنثوس الأولى", "كورنثوس الثانية",
            "غلاطية", "أفسس", "فيلبي", "كولوسي", "تسالونيكي الأولى", "تسالونيكي الثانية",
            "تيموثاوس الأولى", "تيموثاوس الثانية", "تيطس", "فليمون", "العبرانيين", "يعقوب",
            "بطرس الأولى", "بطرس الثانية", "يوحنا الأولى", "يوحنا الثانية", "يوحنا الثالثة", "يهوذا", "رؤيا يوحنا"
    };

    static final int[] CH = {
            50, 40, 27, 36, 34, 24, 21, 4, 31, 24, 22, 25, 29, 36, 10, 13, 10, 42, 150, 31, 12, 8,
            66, 52, 5, 48, 12, 14, 3, 9, 1, 4, 7, 3, 3, 3, 2, 14, 4,
            28, 16, 24, 21, 28, 16, 16, 13, 6, 6, 4, 4, 5, 3, 6, 4, 3, 1, 13, 5, 5, 3, 5, 1, 1, 1, 22
    };

    /** Books 1..39 are the Old Testament, 40..66 the New. */
    static final int OT = 39;

    static int total() {
        int t = 0;
        for (int n : CH) t += n;
        return t;
    }

    static String name(int book) {
        return NAMES[Math.max(1, Math.min(66, book)) - 1];
    }

    static int chapters(int book) {
        return CH[Math.max(1, Math.min(66, book)) - 1];
    }

    interface Callback {
        void done(List<String[]> verses, String error);
    }

    private static final class Result {
        List<String[]> verses;
        String error;
    }

    /** Loads one chapter (from the TV's own copy when it has one, else from the internet) and calls back on the main thread. */
    static void load(Context c, final int book, final int chapter, final Callback cb) {
        final Context app = c.getApplicationContext();
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Result r = new Result();
                try {
                    File dir = new File(app.getFilesDir(), "bible");
                    dir.mkdirs();
                    File f = new File(dir, book + "_" + chapter + ".json");
                    String body = null;
                    if (f.exists()) {
                        try {
                            body = new String(readAll(new FileInputStream(f)), "UTF-8");
                            parse(body);
                        } catch (Exception bad) {
                            body = null;
                            f.delete();
                        }
                    }
                    if (body == null) {
                        body = http("https://api.getbible.net/v2/arabicsv/" + book + "/" + chapter + ".json");
                        parse(body); // throws when the format is not what we expect, so a bad answer is never saved
                        FileOutputStream out = new FileOutputStream(f);
                        try {
                            out.write(body.getBytes("UTF-8"));
                        } finally {
                            out.close();
                        }
                    }
                    r.verses = parse(body);
                } catch (Exception e) {
                    r.error = "تعذّر تحميل الفصل. تأكد أن التليفزيون متصل بالإنترنت ثم حاول مرة أخرى.";
                }
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(r.verses, r.error);
                    }
                });
            }
        }).start();
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    private static String http(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(15000);
        conn.setRequestProperty("Accept", "application/json");
        try {
            if (conn.getResponseCode() != 200) throw new Exception("http " + conn.getResponseCode());
            return new String(readAll(conn.getInputStream()), "UTF-8");
        } finally {
            conn.disconnect();
        }
    }

    static List<String[]> parse(String body) throws Exception {
        if (body.length() > 0 && body.charAt(0) == '﻿') body = body.substring(1);
        JSONObject o = new JSONObject(body);
        JSONArray vs = o.optJSONArray("verses");
        if (vs == null || vs.length() == 0) throw new Exception("format");
        List<String[]> out = new ArrayList<>();
        for (int i = 0; i < vs.length(); i++) {
            JSONObject v = vs.getJSONObject(i);
            String text = v.optString("text", "").trim();
            if (text.isEmpty()) continue;
            out.add(new String[]{String.valueOf(v.optInt("verse", i + 1)), text});
        }
        if (out.isEmpty()) throw new Exception("empty");
        return out;
    }
}
