package tv.agpeya.home;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * "The Bible in a year": all 1189 chapters in order, spread over 365 days (3 or 4 chapters a day).
 * Progress-based: day N is the next day you have not finished, so missing a day never leaves you "behind".
 */
final class Plan {
    private Plan() {}

    static final int DAYS = 365;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("agpeya", Context.MODE_PRIVATE);
    }

    static final class Today {
        int day;            // 1..365
        boolean doneToday;
        int streak;
        String label;       // e.g. "التكوين ١–٣" or "التكوين ٥٠ ثم الخروج ١–٢"
        int[][] refs;       // {book, chapter} in reading order
    }

    static Today today(Context c) {
        SharedPreferences p = prefs(c);
        int done = p.getInt("plan_done", 0);
        String last = p.getString("plan_last", "");
        LocalDate now = LocalDate.now();
        Today t = new Today();
        t.doneToday = now.toString().equals(last);
        int streak = p.getInt("plan_streak", 0);
        boolean alive = t.doneToday || now.minusDays(1).toString().equals(last);
        t.streak = alive ? streak : 0;
        int dayIdx = t.doneToday ? done - 1 : done;      // 0-based day being shown
        dayIdx = ((dayIdx % DAYS) + DAYS) % DAYS;
        t.day = dayIdx + 1;
        int total = Bible.total();
        int from = (int) ((long) dayIdx * total / DAYS);
        int to = (int) ((long) (dayIdx + 1) * total / DAYS); // exclusive
        List<int[]> list = new ArrayList<>();
        for (int g = from; g < to; g++) list.add(locate(g));
        t.refs = list.toArray(new int[0][]);
        t.label = label(t.refs);
        return t;
    }

    /** Global chapter index (0-based, canonical order) to {book, chapter}. */
    private static int[] locate(int g) {
        int left = g;
        for (int b = 1; b <= 66; b++) {
            int n = Bible.chapters(b);
            if (left < n) return new int[]{b, left + 1};
            left -= n;
        }
        return new int[]{66, Bible.chapters(66)};
    }

    private static String label(int[][] refs) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < refs.length) {
            int j = i;
            while (j + 1 < refs.length && refs[j + 1][0] == refs[i][0]) j++;
            if (sb.length() > 0) sb.append(" ثم ");
            sb.append(Bible.name(refs[i][0])).append(' ').append(Coptic.ar(refs[i][1]));
            if (j > i) sb.append('–').append(Coptic.ar(refs[j][1]));
            i = j + 1;
        }
        return sb.toString();
    }

    static void markDone(Context c) {
        SharedPreferences p = prefs(c);
        LocalDate now = LocalDate.now();
        if (now.toString().equals(p.getString("plan_last", ""))) return;
        int streak = p.getInt("plan_streak", 0);
        streak = now.minusDays(1).toString().equals(p.getString("plan_last", "")) ? streak + 1 : 1;
        p.edit().putInt("plan_done", p.getInt("plan_done", 0) + 1)
                .putString("plan_last", now.toString())
                .putInt("plan_streak", streak).apply();
    }
}
