package tv.agpeya.home;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** The home banner: a wine-coloured Coptic arch with a warm glow, church domes and a gold cross (no animation, light on old TVs). */
final class HeroView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path shape = new Path();
    private final RectF r = new RectF();
    private int feast;
    private boolean fasting;
    private final float k;

    HeroView(Context c) {
        super(c);
        k = Ui.k(c);
    }

    void setFeast(int f) {
        if (f != feast) {
            feast = f;
            invalidate();
        }
    }

    void setFasting(boolean f) {
        if (f != fasting) {
            fasting = f;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float inset = 1.5f * k;
        r.set(inset, inset, w - inset, h - inset);
        shape.reset();
        float tr = 150 * k, ty = 110 * k, br = 34 * k;
        shape.addRoundRect(r, new float[]{tr, ty, tr, ty, br, br, br, br}, Path.Direction.CW);

        // see-through on the left and in the middle (so the photo shows), dark on the right where the text sits
        int rgb = (fasting ? 0x201014 : (Ui.ARCH & 0xFFFFFF));
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, w, 0,
                new int[]{0x00000000 | rgb, 0x1A000000 | rgb, 0xB8000000 | rgb, 0xE0000000 | rgb},
                new float[]{0f, 0.45f, 0.68f, 1f}, Shader.TileMode.CLAMP));
        cv.drawPath(shape, p);
        p.setShader(null);
        if (feast != 0) {
            cv.save();
            cv.clipPath(shape);
            p.setShader(new RadialGradient(w * 0.5f, h * 0.4f, 380 * k, feast == 2 ? 0x40FFE9A8 : 0x30FFD27A,
                    0x00000000, Shader.TileMode.CLAMP));
            cv.drawCircle(w * 0.5f, h * 0.4f, 380 * k, p);
            p.setShader(null);
            cv.restore();
        }

        // gold outline
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * k);
        p.setColor(0x80D4AF6A);
        cv.drawPath(shape, p);
    }

    /** A dome: a half-ellipse sitting on the bottom edge with a small cross on top. */
    private void dome(Canvas cv, float cx, float bottom, float rx, float ry) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x73000000);
        r.set(cx - rx, bottom - ry, cx + rx, bottom + ry);
        cv.drawArc(r, 180, 180, true, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0x99D4AF6A);
        p.setStrokeWidth(3 * k);
        p.setStrokeCap(Paint.Cap.ROUND);
        float ty = bottom - ry;
        cv.drawLine(cx, ty - 26 * k, cx, ty, p);
        cv.drawLine(cx - 9 * k, ty - 17 * k, cx + 9 * k, ty - 17 * k, p);
    }
}
