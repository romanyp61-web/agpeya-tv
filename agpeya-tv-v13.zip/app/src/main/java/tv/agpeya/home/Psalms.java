package tv.agpeya.home;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** A psalm a day, taken only from the Agpeya texts inside the app (assets/psalms.txt: "title TAB text" per line). */
final class Psalms {
    private Psalms() {}

    private static List<String[]> list;

    private static synchronized List<String[]> load(Context c) {
        if (list != null) return list;
        List<String[]> out = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getAssets().open("psalms.txt"), "UTF-8"))) {
            String l;
            while ((l = r.readLine()) != null) {
                int t = l.indexOf('\t');
                if (t > 0 && t < l.length() - 1) out.add(new String[]{l.substring(0, t).trim(), l.substring(t + 1).trim()});
            }
        } catch (Exception ignored) {
            // empty list: the card shows a fallback
        }
        list = out;
        return out;
    }

    /** {title, full text} or null when the file is missing. */
    static String[] today(Context c, LocalDate d) {
        List<String[]> l = load(c);
        if (l.isEmpty()) return null;
        return l.get((int) (d.toEpochDay() % l.size()));
    }

    /** First sentence(s) of the text, at most about 90 characters. */
    static String preview(String text) {
        String t = text.replace('\n', ' ').trim();
        if (t.length() <= 90) return t;
        int cut = -1;
        for (int i = 40; i < Math.min(t.length(), 95); i++) {
            char ch = t.charAt(i);
            if (ch == '.' || ch == '،' || ch == ':' || ch == '؟') cut = i;
        }
        if (cut > 0) return t.substring(0, cut + 1);
        int sp = t.lastIndexOf(' ', 88);
        return t.substring(0, sp > 0 ? sp : 88) + "…";
    }
}
