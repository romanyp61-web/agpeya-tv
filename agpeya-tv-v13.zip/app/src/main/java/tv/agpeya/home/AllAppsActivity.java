package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Every installed app. Press and hold OK on one to add it to (or remove it from) the favourites. */
public class AllAppsActivity extends Activity {
    private static final int COLUMNS = 6;
    private boolean edit;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        View root = build();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);
    }

    private View build() {
        final Context c = this;
        final List<Apps.App> all = Apps.list(c);

        LinearLayout page = new LinearLayout(c);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(Ui.px(c, 64), Ui.px(c, 48), Ui.px(c, 64), Ui.px(c, 48));

        page.addView(Ui.text(c, "كل التطبيقات (" + Coptic.ar(all.size()) + ")", 64, Ui.GOLD, Ui.amiriBold(c)));
        page.addView(Ui.text(c, "المفضلة هي اللي بتظهر تحت في الشاشة الرئيسية. فعّل وضع التعديل ثم اضغط OK على أي تطبيق لإضافته أو إزالته", 24, Ui.MUTED, Ui.alex(c)));
        Ui.gap(c, page, 14);
        final TextView editBtn = Ui.text(c, "وضع تعديل المفضلة: متوقف (اضغط للتفعيل)", 26, Ui.INK, Ui.alexBold(c));
        editBtn.setGravity(Gravity.CENTER);
        editBtn.setSingleLine(true);
        android.graphics.drawable.StateListDrawable ebg = new android.graphics.drawable.StateListDrawable();
        ebg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, Ui.CREAM, Ui.GOLD, 4, 30));
        ebg.addState(new int[]{}, Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 30));
        Ui.button(editBtn, ebg);
        editBtn.setOnClickListener(v -> {
            edit = !edit;
            editBtn.setText(edit ? "وضع التعديل شغّال: اضغط OK على التطبيق لإضافته أو إزالته (اضغط هنا للإيقاف)"
                    : "وضع تعديل المفضلة: متوقف (اضغط للتفعيل)");
        });
        page.addView(editBtn, Ui.lp(c, Ui.MATCH, 60));
        Ui.gap(c, page, 20);

        final List<String> favs = Apps.favoritePackages(c, all);
        LinearLayout row = null;
        for (int i = 0; i < all.size(); i++) {
            if (i % COLUMNS == 0) {
                row = new LinearLayout(c);
                row.setOrientation(LinearLayout.HORIZONTAL);
                page.addView(row, Ui.lp(c, Ui.MATCH, Ui.WRAP));
                Ui.gap(c, page, 14);
            }
            row.addView(tile(all.get(i), all, favs), Ui.lpw(c, 0, 170, 1f));
            if (i % COLUMNS != COLUMNS - 1) Ui.gap(c, row, 14);
        }
        // Pad the last row so the tiles keep their width.
        if (row != null) {
            int missing = (COLUMNS - all.size() % COLUMNS) % COLUMNS;
            for (int i = 0; i < missing; i++) {
                Ui.gap(c, row, 14);
                row.addView(new View(c), Ui.lpw(c, 0, 170, 1f));
            }
        }

        ScrollView sv = new ScrollView(c);
        sv.setBackground(Ui.background(this));
        sv.setFillViewport(true);
        sv.addView(page, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        return sv;
    }

    private View tile(final Apps.App a, final List<Apps.App> all, final List<String> favs) {
        final Context c = this;
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.px(c, 10), Ui.px(c, 10), Ui.px(c, 10), Ui.px(c, 10));
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(a.icon);
        t.addView(iv, Ui.lp(c, 76, 76));
        final TextView l = Ui.text(c, label(a, favs), 22, Ui.CREAM, Ui.alexBold(c));
        l.setGravity(Gravity.CENTER);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        l.setPadding(0, Ui.px(c, 8), 0, 0);
        t.addView(l, Ui.lp(c, Ui.MATCH, Ui.WRAP));
        Ui.button(t, Ui.tile(c, Ui.PANEL, Ui.LINE, 18));
        t.setOnClickListener(v -> {
            if (edit) toggle(a, all, favs, l);
            else Apps.launch(c, a.pkg);
        });
        t.setOnLongClickListener(v -> {
            toggle(a, all, favs, l);
            return true;
        });
        return t;
    }

    private void toggle(final Apps.App a, final List<Apps.App> all, final List<String> favs, final TextView l) {
        final Context c = this;
        {
            boolean now = Apps.toggleFavorite(c, a.pkg, all);
            if (now) favs.add(a.pkg); else favs.remove(a.pkg);
            l.setText(label(a, favs));
            Toast.makeText(c, now ? "أُضيف إلى المفضلة" : "أُزيل من المفضلة", Toast.LENGTH_SHORT).show();
        }
    }

    private static String label(Apps.App a, List<String> favs) {
        return (favs.contains(a.pkg) ? "★ " : "") + a.label;
    }
}
