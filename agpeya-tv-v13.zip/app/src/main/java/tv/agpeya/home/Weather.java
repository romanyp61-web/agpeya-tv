package tv.agpeya.home;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Cairo weather from Open-Meteo (free, no key). Cached; the chip is hidden when the last reading is older than 3 hours. */
final class Weather {
    private Weather() {}

    private static final long FRESH_MS = 3L * 3600 * 1000, RETRY_MS = 20L * 60 * 1000;
    private static volatile boolean busy;
    private static volatile long lastTry;

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("agpeya", Context.MODE_PRIVATE);
    }

    /** {temperature text, weather code} or null when there is no fresh reading. */
    static String[] cached(Context c) {
        SharedPreferences p = prefs(c);
        long at = p.getLong("wx_at", 0);
        if (at == 0 || System.currentTimeMillis() - at > FRESH_MS) return null;
        return new String[]{String.valueOf(p.getInt("wx_t", 0)), String.valueOf(p.getInt("wx_c", 0))};
    }

    /** Asks the internet for a new reading when the cached one is older than 30 minutes. Safe to call often. */
    static void refresh(Context c, final Runnable onDone) {
        final Context app = c.getApplicationContext();
        long now = System.currentTimeMillis();
        if (busy || now - lastTry < RETRY_MS) return;
        if (now - prefs(app).getLong("wx_at", 0) < 30L * 60 * 1000) return;
        busy = true;
        lastTry = now;
        new Thread(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(
                        "https://api.open-meteo.com/v1/forecast?latitude=30.0444&longitude=31.2357"
                                + "&current=temperature_2m,weather_code&timezone=auto").openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                try {
                    if (conn.getResponseCode() != 200) throw new Exception("http");
                    InputStream in = conn.getInputStream();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    JSONObject cur = new JSONObject(out.toString("UTF-8")).getJSONObject("current");
                    int t = (int) Math.round(cur.getDouble("temperature_2m"));
                    int code = cur.getInt("weather_code");
                    prefs(app).edit().putInt("wx_t", t).putInt("wx_c", code)
                            .putLong("wx_at", System.currentTimeMillis()).apply();
                } finally {
                    conn.disconnect();
                }
            } catch (Exception ignored) {
                // offline or a different answer: the chip simply stays as it was (or hidden when stale)
            }
            busy = false;
            if (onDone != null) new android.os.Handler(android.os.Looper.getMainLooper()).post(onDone);
        }).start();
    }
}
