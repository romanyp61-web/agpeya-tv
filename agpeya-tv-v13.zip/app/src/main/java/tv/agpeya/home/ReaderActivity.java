package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

/** Reads one Agpeya hour in full. Up/Down scroll, Left = next section, Right = previous section. */
public class ReaderActivity extends Activity {
    static final String EXTRA_HOUR = "hour";

    private int hour;
    private ScrollView scroll;
    private final List<View> heads = new ArrayList<>();
    private TextView where;
    private TextView autoBtn, speakBtn;
    private List<String> lines = new ArrayList<>();
    private final List<Integer> headLine = new ArrayList<>();
    private TextToSpeech tts;
    private boolean ttsReady, speaking;
    private int pendingFrom = -1;
    private int autoMode = 0; // 0 off, 1 slow, 2 medium, 3 fast
    private float autoCarry;
    private static final float[] AUTO_SPEED = {0f, 28f, 50f, 84f}; // design px per second
    private final android.os.Handler autoHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable autoTick = new Runnable() {
        @Override
        public void run() {
            if (autoMode == 0) return;
            autoCarry += AUTO_SPEED[autoMode] * Ui.k(ReaderActivity.this) * 0.04f;
            int step = (int) autoCarry;
            if (step > 0) {
                autoCarry -= step;
                int before = scroll.getScrollY();
                scroll.scrollBy(0, step);
                if (scroll.getScrollY() == before) {
                    setAuto(0);
                    return;
                }
            }
            autoHandler.postDelayed(this, 40);
        }
    };

    private static final String[] AUTO_LABEL = {"تمرير تلقائي", "تمرير: بطيء", "تمرير: متوسط", "تمرير: سريع"};

    private void setAuto(int mode) {
        autoMode = mode;
        autoHandler.removeCallbacks(autoTick);
        if (autoBtn != null) autoBtn.setText(AUTO_LABEL[mode]);
        if (mode != 0) autoHandler.postDelayed(autoTick, 40);
    }

    @Override
    protected void onPause() {
        super.onPause();
        setAuto(0);
        stopSpeak();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
    }

    private void toggleSpeak() {
        if (speaking) {
            stopSpeak();
            return;
        }
        int from = 0;
        if (!heads.isEmpty()) {
            int y = scroll.getScrollY() + Ui.px(this, 40);
            int cur = 0;
            for (int i = 0; i < heads.size(); i++) if (heads.get(i).getTop() <= y) cur = i;
            from = headLine.get(cur);
        }
        if (tts == null) {
            pendingFrom = from;
            try {
                tts = new TextToSpeech(getApplicationContext(), st -> runOnUiThread(() -> onTtsInit(st)));
            } catch (Exception e) {
                tts = null;
                Toast.makeText(this, "القراءة الصوتية غير متاحة على هذا التليفزيون", Toast.LENGTH_LONG).show();
            }
        } else if (ttsReady) {
            speakFrom(from);
        }
    }

    private void onTtsInit(int st) {
        if (isDestroyed() || tts == null) return;
        if (st != TextToSpeech.SUCCESS) {
            Toast.makeText(this, "القراءة الصوتية غير متاحة على هذا التليفزيون", Toast.LENGTH_LONG).show();
            tts.shutdown();
            tts = null;
            return;
        }
        int res = tts.setLanguage(new Locale("ar"));
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "الصوت العربي غير مثبّت في التليفزيون", Toast.LENGTH_LONG).show();
            tts.shutdown();
            tts = null;
            return;
        }
        ttsReady = true;
        speakFrom(pendingFrom);
    }

    private void speakFrom(int from) {
        speaking = true;
        speakBtn.setText("إيقاف القراءة");
        tts.setSpeechRate(0.85f);
        final int last = lines.size() - 1;
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) {
                if ("last".equals(id)) runOnUiThread(() -> stopSpeak());
            }
            @Override public void onError(String id) {
                runOnUiThread(() -> stopSpeak());
            }
        });
        for (int i = Math.max(0, from); i <= last; i++) {
            tts.speak(lines.get(i), i == from ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, i == last ? "last" : "l" + i);
        }
    }

    private void stopSpeak() {
        if (tts != null && speaking) tts.stop();
        speaking = false;
        if (speakBtn != null) speakBtn.setText("استمع");
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        hour = Math.max(0, Math.min(6, getIntent().getIntExtra(EXTRA_HOUR, 0)));
        setContentView(build());
    }

    private List<String> load() {
        List<String> out = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                getAssets().open("agpeya/h" + hour + ".txt"), "UTF-8"))) {
            String l;
            while ((l = r.readLine()) != null) {
                l = l.trim();
                if (!l.isEmpty()) out.add(l);
            }
        } catch (Exception e) {
            out.add("تعذّر فتح نص هذه الصلاة.");
        }
        return out;
    }

    private static boolean isHeading(String l) {
        return l.length() < 60 && !l.endsWith(".") && !l.endsWith(":") && !l.endsWith("،");
    }

    private View build() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));
        root.addView(new Scene(c, Scene.PAGE), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        View dim = new View(c);
        dim.setBackgroundColor(0x99000000);
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        FrameLayout stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);

        TextView title = Ui.box(c, "صلاة " + Agpeya.NAMES[hour], 56, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1);
        stage.addView(title, Ui.at(c, 1000, 36, 850, 80));
        where = Ui.box(c, "", 24, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        stage.addView(where, Ui.at(c, 700, 112, 1150, 32));

        stage.addView(button("تمّت الصلاة ✓", 70, 44, 230, v -> {
            LocalDate d = LocalDate.now();
            if ((Agpeya.mask(c, d) & (1 << hour)) == 0) Agpeya.toggle(c, d, hour);
            Toast.makeText(c, "تم تعليم الصلاة. ربنا يقبل", Toast.LENGTH_SHORT).show();
            finish();
        }), Ui.at(c, 70, 44, 230, 58));
        stage.addView(button("ترتيلها على يوتيوب", 316, 44, 290, v ->
                Media.search(c, "أجبية " + Agpeya.NAMES[hour] + " صلاة قبطية أرثوذكسية")), Ui.at(c, 316, 44, 290, 58));
        stage.addView(button("رجوع", 622, 44, 130, v -> finish()), Ui.at(c, 622, 44, 130, 58));
        autoBtn = button(AUTO_LABEL[0], 768, 44, 220, v -> {
            setAuto((autoMode + 1) % 4);
            if (autoMode != 0) scroll.requestFocus(); // so the remote keys control the speed
        });
        stage.addView(autoBtn, Ui.at(c, 768, 44, 220, 58));
        speakBtn = button("استمع", 1004, 44, 200, v -> toggleSpeak());
        stage.addView(speakBtn, Ui.at(c, 1004, 44, 200, 58));

        View card = new View(c);
        card.setBackground(Ui.rect(c, Ui.glass(0xD9), 0x59D4AF6A, 1.5f, 28));
        stage.addView(card, Ui.at(c, 70, 160, 1780, 860));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(Ui.px(c, 50), Ui.px(c, 30), Ui.px(c, 50), Ui.px(c, 60));
        lines = load();
        boolean first = true;
        int li = -1;
        for (String l : lines) {
            li++;
            boolean h = isHeading(l);
            boolean big = Ui.readerBig(c);
            TextView t = Ui.text(c, l, h ? (big ? 40 : 32) : (big ? 54 : 42), h ? Ui.GOLD : Ui.CREAM, h ? Ui.alexBold(c) : Ui.amiri(c));
            t.setTextDirection(View.TEXT_DIRECTION_RTL);
            t.setGravity(Gravity.RIGHT);
            if (!h) t.setLineSpacing(0, 1.05f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
            lp.topMargin = Ui.px(c, h ? (first ? 0 : 34) : 10);
            col.addView(t, lp);
            if (h) {
                heads.add(t);
                headLine.add(li);
                first = false;
            }
        }
        scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFocusable(true);
        scroll.setFocusableInTouchMode(true);
        scroll.addView(col, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        scroll.setOnKeyListener((v, code, ev) -> onScrollKey(code, ev));
        scroll.setOnScrollChangeListener((v, x, y, ox, oy) -> showWhere());
        stage.addView(scroll, Ui.at(c, 100, 180, 1720, 820));
        scroll.post(() -> {
            scroll.requestFocus();
            showWhere();
        });
        return root;
    }

    private boolean onScrollKey(int code, KeyEvent ev) {
        if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
        if (autoMode != 0) {
            // while it scrolls by itself: Up = slower, Down = faster, anything else stops it
            if (code == KeyEvent.KEYCODE_DPAD_UP && autoMode > 1) { setAuto(autoMode - 1); return true; }
            if (code == KeyEvent.KEYCODE_DPAD_DOWN && autoMode < 3) { setAuto(autoMode + 1); return true; }
            setAuto(0);
            return true;
        }
        int page = Ui.px(this, 560);
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                scroll.smoothScrollBy(0, page);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_PAGE_UP:
                if (scroll.getScrollY() <= 0) return false; // let the focus go up to the buttons
                scroll.smoothScrollBy(0, -page);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT: {
                int y = scroll.getScrollY();
                for (View h : heads) {
                    if (h.getTop() > y + Ui.px(this, 20)) {
                        scroll.smoothScrollTo(0, h.getTop() - Ui.px(this, 10));
                        break;
                    }
                }
                return true;
            }
            case KeyEvent.KEYCODE_DPAD_RIGHT: {
                int y = scroll.getScrollY();
                for (int i = heads.size() - 1; i >= 0; i--) {
                    if (heads.get(i).getTop() < y - Ui.px(this, 20)) {
                        scroll.smoothScrollTo(0, Math.max(0, heads.get(i).getTop() - Ui.px(this, 10)));
                        break;
                    }
                }
                return true;
            }
            default:
                return false;
        }
    }

    private void showWhere() {
        if (where == null || heads.isEmpty()) return;
        int y = scroll.getScrollY() + Ui.px(this, 40);
        int cur = 0;
        for (int i = 0; i < heads.size(); i++) if (heads.get(i).getTop() <= y) cur = i;
        String name = ((TextView) heads.get(cur)).getText().toString();
        Ui.setIfChanged(where, name + "  ·  " + Coptic.ar(cur + 1) + " من " + Coptic.ar(heads.size())
                + "   (↑↓ تمرير · ◄ القسم التالي · ► السابق)");
    }

    private TextView button(String label, float x, float y, float w, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 24, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.FOCUS, Ui.GOLD, 4, 29));
        bg.addState(new int[]{}, Ui.rect(this, Ui.glass(0xB8), Ui.GOLD, 1.5f, 29));
        Ui.button(t, bg);
        t.setOnClickListener(l);
        return t;
    }
}
